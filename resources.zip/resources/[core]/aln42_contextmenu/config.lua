Config = {}

Config.Enabled = true

Config.HoldKey = 249          -- N
Config.HoldMs = 350           -- hold threshold
Config.Range = 2.0
Config.ScanEveryMs = 150

-- Which location types count as “vendors” (placeholder now)
Config.VendorTypes = {
  shop = true,
  burgershot = true,
  liquor = true,
  hotdog_stand = true,
  pawn = true,
  fence = true
}
