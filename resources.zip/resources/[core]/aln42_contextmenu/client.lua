local locations = {}
local props = {}
local holdStart = nil
local menu = { open=false, items={}, idx=1, title='' }

-- External “dynamic actions” registry (lockpick targets etc.)
local dynamicActions = {} -- { {id=, label=, can=fn, run=fn} }

exports('RegisterAction', function(action)
  -- action = { id, label, can=function()->bool, run=function() }
  if type(action) ~= 'table' or type(action.id) ~= 'string' then return end
  dynamicActions[action.id] = action
end)

exports('UnregisterAction', function(id)
  dynamicActions[id] = nil
end)

local function notify(msg)
  print(('[ALN42 Context] %s'):format(msg))
  TriggerEvent('chat:addMessage', { args = { '^6ALN42', msg } })
end

local function readJson(res, path)
  local raw = LoadResourceFile(res, path)
  if not raw or raw == '' then return {} end
  local ok, parsed = pcall(json.decode, raw)
  return (ok and type(parsed) == 'table') and parsed or {}
end

local function dist3(a,b)
  local dx=a.x-b.x; local dy=a.y-b.y; local dz=a.z-b.z
  return math.sqrt(dx*dx+dy*dy+dz*dz)
end

local function pos()
  local p = GetEntityCoords(PlayerPedId())
  return { x=p.x, y=p.y, z=p.z }
end

-- --- Minimal draw menu (no NUI) ---
local function drawTxt(x,y,txt,scale)
  SetTextFont(0)
  SetTextScale(scale or 0.35, scale or 0.35)
  SetTextOutline()
  BeginTextCommandDisplayText('STRING')
  AddTextComponentString(txt)
  EndTextCommandDisplayText(x, y)
end

local function openMenu(title, items)
  menu.open = true
  menu.title = title or 'Context'
  menu.items = items or {}
  menu.idx = 1
end

local function closeMenu()
  menu.open = false
  menu.items = {}
  menu.idx = 1
end

local function runSelected()
  local it = menu.items[menu.idx]
  if it and it.run then
    it.run()
  end
  closeMenu()
end

CreateThread(function()
  while true do
    if menu.open then
      DisableControlAction(0, 24, true) -- attack
      DisableControlAction(0, 25, true) -- aim
      DisableControlAction(0, 44, true) -- cover

      -- navigation: up/down, enter, backspace
      if IsControlJustPressed(0, 172) then menu.idx = math.max(1, menu.idx - 1) end -- up
      if IsControlJustPressed(0, 173) then menu.idx = math.min(#menu.items, menu.idx + 1) end -- down
      if IsControlJustPressed(0, 191) then runSelected() end -- enter
      if IsControlJustPressed(0, 177) then closeMenu() end -- backspace

      drawTxt(0.05, 0.20, ('~y~%s~s~'):format(menu.title), 0.45)

      local y = 0.24
      for i, it in ipairs(menu.items) do
        local prefix = (i == menu.idx) and '~g~>~s~ ' or '  '
        drawTxt(0.05, y, prefix .. (it.label or '???'), 0.38)
        y = y + 0.028
      end
    end
    Wait(0)
  end
end)

-- --- Find nearby systems ---
local function nearestLocationType()
  local p = pos()
  local best, bestD = nil, 999999.0
  for _, loc in ipairs(locations) do
    if loc and loc.coords and loc.type then
      local d = dist3(p, loc.coords)
      if d < bestD then bestD = d; best = loc end
    end
  end
  if best and bestD <= (Config.Range or 2.0) then return best end
  return nil
end

local function nearestPropertyDoor()
  local p = pos()
  local best, bestD = nil, 999999.0
  for _, pr in ipairs(props) do
    if pr and pr.entry and pr.entry.x then
      local d = dist3(p, pr.entry)
      if d < bestD then bestD = d; best = pr end
    end
  end
  if best and bestD <= (Config.Range or 2.0) then return best end
  return nil
end

local function vendorsStarted()
  return GetResourceState('aln42_vendors') == 'started'
end

local function vendorEligibleType(t)
  return t == 'shop' or t == 'gas' or t == 'pawn' or t == 'fence'
end

-- --- Build menu items by context ---
local function buildItems()
  local items = {}

  -- 1) property doors (home/garage doors)
  local pr = nearestPropertyDoor()
  if pr then
    table.insert(items, { label = ('Enter/Exit: %s'):format(pr.name or pr.id), run = function()
      ExecuteCommand(('door enter %s'):format(pr.id))
    end })

    if pr.price and tonumber(pr.price) and tonumber(pr.price) > 0 then
      table.insert(items, { label = ('Buy (%d)'):format(tonumber(pr.price)), run = function()
        ExecuteCommand(('door buy %s'):format(pr.id))
      end })
    end

    table.insert(items, { label = 'Lock/Unlock', run = function()
      ExecuteCommand(('door lock %s'):format(pr.id))
    end })

    if pr.kind == 'home' then
      table.insert(items, { label = 'Set as Home', run = function()
        ExecuteCommand(('door sethome %s'):format(pr.id))
      end })
    end
  end

  -- 2) location-based interactions
  local loc = nearestLocationType()
  if loc then
    if loc.type == 'gas' then
      table.insert(items, { label = 'Fuel: Fill tank', run = function() ExecuteCommand('fuel fill') end })
      table.insert(items, { label = 'Fuel: Use jerry can', run = function() ExecuteCommand('fuel usecan') end })
      table.insert(items, { label = 'Fuel: Status', run = function() ExecuteCommand('fuel status') end })
    end

    if loc.type == 'autoshop' then
      table.insert(items, { label = 'Auto: Title vehicle', run = function() ExecuteCommand('auto title') end })
      table.insert(items, { label = 'Auto: Repair', run = function() ExecuteCommand('auto repair') end })
      table.insert(items, { label = 'Auto: Mods list', run = function() ExecuteCommand('auto mod list') end })
    end

    if loc.type == 'parking_public' or (type(loc.type)=='string' and loc.type:find('garage_')) then
      table.insert(items, { label = 'Garage: List owned vehicles', run = function() ExecuteCommand('garage vehicles') end })
      table.insert(items, { label = 'Garage: Store current vehicle', run = function() ExecuteCommand('garage store') end })
      table.insert(items, { label = 'Garage: Spawn (by plate)', run = function()
        notify('Use: /garage spawn <PLATE>')
      end })
    end

    -- ✅ Vendors wired (shop/gas/pawn/fence)
    if vendorEligibleType(loc.type) then
      if not vendorsStarted() then
        table.insert(items, { label = ('%s: vendors offline'):format(loc.type), run = function()
          notify('aln42_vendors is not started.')
        end })
      else
        table.insert(items, { label = ('%s: Browse (list)'):format(loc.type), run = function()
          TriggerServerEvent('aln42:vendor:list', loc.id, loc.type)
        end })

        table.insert(items, { label = ('%s: Buy (chat input for now)'):format(loc.type), run = function()
          notify('Type: /shop buy <itemId> <qty>  (example: /shop buy water 1)')
        end })

        table.insert(items, { label = ('%s: Sell (chat input for now)'):format(loc.type), run = function()
          notify('Type: /shop sell <itemId> <qty>')
        end })
      end
    end
  end

  -- 3) dynamic actions (lockpick/robbery/etc.)
  for _, act in pairs(dynamicActions) do
    local ok = true
    if type(act.can) == 'function' then
      ok = act.can()
    end
    if ok then
      table.insert(items, { label = act.label or act.id, run = act.run })
    end
  end

  return items
end

-- --- Hold N to open ---
CreateThread(function()
  if not Config.Enabled then return end

  locations = readJson('aln42_locations', 'data/locations.json')

  -- properties are optional
  if GetResourceState('aln42_properties') == 'started' then
    TriggerServerEvent('aln42:props:request')
  end

  RegisterNetEvent('aln42:props:sync', function(list)
    props = list or {}
  end)

  while true do
    if not menu.open then
      if IsControlPressed(0, Config.HoldKey) then
        if not holdStart then holdStart = GetGameTimer() end
        if (GetGameTimer() - holdStart) >= (Config.HoldMs or 350) then
          local items = buildItems()
          if #items > 0 then
            openMenu('Context', items)
          else
            notify('No actions nearby.')
          end
          holdStart = nil
        end
      else
        holdStart = nil
      end
    end

    Wait(Config.ScanEveryMs or 150)
  end
end)

-- --- Burner phone keybind: M (keyboard) + DPAD UP (controller) opens same context menu instantly ---
local function openPhoneMenu()
  if menu.open then return end
  local items = buildItems()
  if #items > 0 then
    openMenu('NOKIA', items)
  else
    notify('No actions nearby.')
  end
end

RegisterCommand('burner', function()
  openPhoneMenu()
end, false)

RegisterKeyMapping('burner', 'Burner Phone (Nokia): Open', 'keyboard', 'M')
RegisterKeyMapping('burner', 'Burner Phone (Nokia): Open', 'PAD_DIGITALBUTTON', 'PAD_UP')
