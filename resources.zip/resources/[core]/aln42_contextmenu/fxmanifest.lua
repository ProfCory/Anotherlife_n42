fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'ALN42 Context Menu (hold N) - routes interactions by nearby tags/types'

shared_script 'config.lua'
client_script 'client.lua'
