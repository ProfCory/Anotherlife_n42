local locations = {}
local activeVendor = nil
local lastListAt = 0

local function notify(msg)
  print(('[ALN42 Vendors] %s'):format(msg))
  TriggerEvent('chat:addMessage', { args = { '^2ALN42-Shop', msg } })
end

RegisterNetEvent('aln42:vendor:toast', function(msg) notify(msg) end)

local function readLocations()
  local raw = LoadResourceFile('aln42_locations', 'data/locations.json')
  if not raw or raw == '' then return {} end
  local ok, parsed = pcall(json.decode, raw)
  return (ok and type(parsed) == 'table') and parsed or {}
end

local function dist(a, b)
  local dx = a.x - b.x
  local dy = a.y - b.y
  local dz = a.z - b.z
  return math.sqrt(dx*dx + dy*dy + dz*dz)
end

local function showHelp(text)
  BeginTextCommandDisplayHelp('STRING')
  AddTextComponentString(text)
  EndTextCommandDisplayHelp(0, false, false, 1)
end

RegisterNetEvent('aln42:vendor:list', function(payload)
  if not payload then return end

  notify(('Vendor: %s (%s)'):format(payload.id, payload.type))
  notify('--- Sells ---')
  local n = 0
  for _, it in ipairs(payload.sell or {}) do
    n = n + 1
    if n > (Config.ListLimit or 25) then break end
    notify(('%s  ($%d)   id=%s'):format(it.label, it.price, it.name))
  end

  notify('--- Buys ---')
  n = 0
  for _, it in ipairs(payload.buy or {}) do
    n = n + 1
    if n > (Config.ListLimit or 25) then break end
    notify(('%s  ($%d)   id=%s'):format(it.label, it.price, it.name))
  end

  notify('Commands: /shop buy <itemId> <qty>  |  /shop sell <itemId> <qty>')
end)

local function vendorEligibleType(t)
  return t == 'shop' or t == 'gas' or t == 'pawn' or t == 'fence'
end

CreateThread(function()
  locations = readLocations()

  while true do
    activeVendor = nil

    local p = GetEntityCoords(PlayerPedId())
    for i = 1, #locations do
      local loc = locations[i]
      if loc and loc.coords and vendorEligibleType(loc.type) then
        local d = dist({x=p.x,y=p.y,z=p.z}, loc.coords)
        if d <= (Config.Range or 3.0) then
          activeVendor = loc
          break
        end
      end
    end

    Wait(250)
  end
end)

-- Chat fallback still works
RegisterCommand('shop', function(_, args)
  if not activeVendor then
    notify('No vendor nearby.')
    return
  end

  local sub = (args[1] or 'list'):lower()
  if sub == 'list' then
    TriggerServerEvent('aln42:vendor:list', activeVendor.id, activeVendor.type)
  elseif sub == 'buy' then
    local item = args[2]
    local qty = tonumber(args[3] or '1') or 1
    if not item then notify('Usage: /shop buy <itemId> <qty>'); return end
    TriggerServerEvent('aln42:vendor:buy', activeVendor.id, activeVendor.type, item, qty)
  elseif sub == 'sell' then
    local item = args[2]
    local qty = tonumber(args[3] or '1') or 1
    if not item then notify('Usage: /shop sell <itemId> <qty>'); return end
    TriggerServerEvent('aln42:vendor:sell', activeVendor.id, activeVendor.type, item, qty)
  else
    notify('Usage: /shop list | /shop buy <itemId> <qty> | /shop sell <itemId> <qty>')
  end
end, false)

-- THIS is the “NPCs do something” part: E triggers the list immediately
CreateThread(function()
  while true do
    if activeVendor then
      showHelp('Press ~INPUT_CONTEXT~ to browse this vendor')

      if IsControlJustReleased(0, Config.InteractKey or 38) then
        local now = GetGameTimer()
        if (now - lastListAt) > 500 then
          lastListAt = now
          TriggerServerEvent('aln42:vendor:list', activeVendor.id, activeVendor.type)
        end
      end
    end
    Wait(0)
  end
end)
