Config = {}

Config.Enabled = true

Config.InteractKey = 38 -- E
Config.Range = 3.0

-- Use cash item from aln42_items
Config.CashItem = 'cash'

-- Markups by vendor type (near-2025 “ouch” economy)
Config.TypePricing = {
  shop  = { buyMult = 1.05, sellMult = 0.35 },
  gas   = { buyMult = 1.10, sellMult = 0.25 },
  pawn  = { buyMult = 1.25, sellMult = 0.55 },
  fence = { buyMult = 1.40, sellMult = 0.65 }
}

-- Show only first N items in list (chat UI)
Config.ListLimit = 25
