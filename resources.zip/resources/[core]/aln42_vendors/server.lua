local vendorCfg = nil

local function loadVendorCfg()
  local raw = LoadResourceFile(GetCurrentResourceName(), 'data/vendors.json')
  if not raw or raw == '' then vendorCfg = { defaults = {}, locationOverrides = {} } return end
  local ok, parsed = pcall(json.decode, raw)
  vendorCfg = (ok and type(parsed) == 'table') and parsed or { defaults = {}, locationOverrides = {} }
end

local function getItems()
  if GetResourceState('aln42_items') ~= 'started' then return nil end
  return exports['aln42_items']
end

local function getItemDefs()
  local raw = LoadResourceFile('aln42_items', 'data/items.json')
  if not raw or raw == '' then return {} end
  local ok, parsed = pcall(json.decode, raw)
  return (ok and type(parsed) == 'table') and parsed or {}
end

local function hasTag(def, tag)
  if not def or type(def.tags) ~= 'table' then return false end
  for _, t in ipairs(def.tags) do
    if t == tag then return true end
  end
  return false
end

local function anyTag(def, tags)
  if type(tags) ~= 'table' then return false end
  for _, t in ipairs(tags) do
    if hasTag(def, t) then return true end
  end
  return false
end

local function getVendorProfile(locationId, locationType)
  vendorCfg = vendorCfg or { defaults = {}, locationOverrides = {} }
  local o = vendorCfg.locationOverrides and vendorCfg.locationOverrides[locationId]
  if o then return o end
  local d = vendorCfg.defaults and vendorCfg.defaults[locationType]
  return d or { sellTags = {}, buyTags = {} }
end

local function priceFor(def, mult)
  local base = tonumber(def.basePrice) or 0
  return math.max(0, math.floor(base * (mult or 1.0)))
end

RegisterNetEvent('aln42:vendor:list', function(locationId, locationType)
  local src = source
  local it = getItems()
  if not it then return end

  local defs = getItemDefs()
  local profile = getVendorProfile(locationId, locationType)

  local pricing = Config.TypePricing[locationType] or { buyMult = 1.0, sellMult = 0.5 }

  local sell = {}
  local buy = {}

  for name, def in pairs(defs) do
    if name ~= Config.CashItem and name ~= 'dirty_money' then
      if anyTag(def, profile.sellTags) then
        table.insert(sell, { name = name, label = def.label or name, price = priceFor(def, pricing.buyMult) })
      end
      if anyTag(def, profile.buyTags) then
        table.insert(buy, { name = name, label = def.label or name, price = priceFor(def, pricing.sellMult) })
      end
    end
  end

  table.sort(sell, function(a,b) return a.price < b.price end)
  table.sort(buy, function(a,b) return a.price > b.price end)

  TriggerClientEvent('aln42:vendor:list', src, { sell = sell, buy = buy, type = locationType, id = locationId })
end)

RegisterNetEvent('aln42:vendor:buy', function(locationId, locationType, itemName, qty)
  local src = source
  local it = getItems()
  if not it then return end

  qty = tonumber(qty) or 1
  if qty <= 0 then return end

  local defs = getItemDefs()
  local def = defs[itemName]
  if not def then
    TriggerClientEvent('aln42:vendor:toast', src, 'Unknown item.')
    return
  end

  local profile = getVendorProfile(locationId, locationType)
  if not anyTag(def, profile.sellTags) then
    TriggerClientEvent('aln42:vendor:toast', src, 'This vendor does not sell that.')
    return
  end

  local pricing = Config.TypePricing[locationType] or { buyMult = 1.0 }
  local unit = priceFor(def, pricing.buyMult)
  local total = unit * qty

  if not it:HasItem(src, Config.CashItem, total) then
    TriggerClientEvent('aln42:vendor:toast', src, 'Not enough cash.')
    return
  end

  it:TakeItem(src, Config.CashItem, total)
  it:GiveItem(src, itemName, qty)

  TriggerClientEvent('aln42:vendor:toast', src, ('Bought %dx %s for $%d'):format(qty, def.label or itemName, total))
end)

RegisterNetEvent('aln42:vendor:sell', function(locationId, locationType, itemName, qty)
  local src = source
  local it = getItems()
  if not it then return end

  qty = tonumber(qty) or 1
  if qty <= 0 then return end

  local defs = getItemDefs()
  local def = defs[itemName]
  if not def then
    TriggerClientEvent('aln42:vendor:toast', src, 'Unknown item.')
    return
  end

  local profile = getVendorProfile(locationId, locationType)
  if not anyTag(def, profile.buyTags) then
    TriggerClientEvent('aln42:vendor:toast', src, 'This vendor will not buy that.')
    return
  end

  if not it:HasItem(src, itemName, qty) then
    TriggerClientEvent('aln42:vendor:toast', src, 'You do not have enough of that item.')
    return
  end

  local pricing = Config.TypePricing[locationType] or { sellMult = 0.5 }
  local unit = priceFor(def, pricing.sellMult)
  local total = unit * qty

  it:TakeItem(src, itemName, qty)
  it:GiveItem(src, Config.CashItem, total)

  TriggerClientEvent('aln42:vendor:toast', src, ('Sold %dx %s for $%d'):format(qty, def.label or itemName, total))
end)

AddEventHandler('onResourceStart', function(res)
  if res ~= GetCurrentResourceName() then return end
  loadVendorCfg()
end)
