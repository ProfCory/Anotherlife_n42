fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'ALN42 Vendors: tag-filtered shops/pawn/fence buying/selling using cash item'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'

files { 'data/vendors.json' }
