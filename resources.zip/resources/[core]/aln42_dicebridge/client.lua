local pending = {}

local function rollBg3(payload)
  -- This matches the pattern you had: exports['bg3_dice']:RollCheck({...}) :contentReference[oaicite:1]{index=1}
  local modifier = tonumber(payload.modifier) or 0
  local dc = tonumber(payload.dc) or 12
  local mode = payload.mode or 'normal' -- 'normal' | 'adv' | 'dis'

  local success, total, raw = exports['bg3_dice']:RollCheck({
    modifier = modifier,
    dc = dc,
    mode = mode,
    skin = payload.skin,
    meta = payload.meta or { system = payload.activity or 'check' }
  })

  return success == true, total, raw
end

RegisterNetEvent('aln42:dicebridge:dcResult', function(reqId, info)
  local cb = pending[reqId]
  if not cb then return end
  pending[reqId] = nil
  cb(info)
end)

-- PUBLIC EXPORT (main)
-- Usage:
-- local ok, info = exports['aln42_dicebridge']:DoCheck({
--   activity='lockpick',
--   grade=3,
--   skill=15,
--   tool='lockpick_advanced',
--   mode='adv',
--   modifier=2,
--   skin=nil,
--   meta={target='vehicle', plate='XYZ'}
-- })
exports('DoCheck', function(opts)
  opts = opts or {}
  local activity = opts.activity or 'check'
  local grade = tonumber(opts.grade) or 2
  local skill = tonumber(opts.skill) or 0
  local tool = opts.tool
  local mode = opts.mode or 'normal'
  local modifier = tonumber(opts.modifier) or 0

  local reqId = tostring(GetGameTimer()) .. '_' .. tostring(math.random(1000, 9999))

  local done = false
  local dcInfo = nil

  pending[reqId] = function(info)
    dcInfo = info
    done = true
  end

  TriggerServerEvent('aln42:dicebridge:calcDC', reqId, activity, grade, skill, tool)

  while not done do Wait(0) end

  local ok, total, raw = rollBg3({
    activity = activity,
    dc = dcInfo.dc,
    mode = mode,
    modifier = modifier,
    skin = opts.skin,
    meta = opts.meta
  })

  dcInfo.total = total
  dcInfo.raw = raw
  dcInfo.mode = mode
  dcInfo.modifier = modifier

  return ok, dcInfo
end)

-- Convenience export: quick roll with explicit DC (no server calc)
exports('Roll', function(dc, modifier, mode, meta)
  local ok, total, raw = rollBg3({
    dc = tonumber(dc) or 12,
    modifier = tonumber(modifier) or 0,
    mode = mode or 'normal',
    meta = meta
  })
  return ok, { dc = dc, total = total, raw = raw, modifier = modifier, mode = mode }
end)

-- Test command
RegisterCommand('dice_test_lockpick', function()
  local ok, info = exports['aln42_dicebridge']:DoCheck({
    activity = 'lockpick',
    grade = 3,
    skill = 0,
    tool = 'lockpick_basic',
    mode = 'normal',
    modifier = 0,
    meta = { test = true }
  })
  print(('lockpick ok=%s dc=%s total=%s'):format(tostring(ok), tostring(info.dc), tostring(info.total)))
end, false)
