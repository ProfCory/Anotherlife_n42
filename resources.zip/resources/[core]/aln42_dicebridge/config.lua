Config = {}

-- Activities you will reuse everywhere
Config.BaseDC = {
  lockpick  = 12,
  hacking   = 14,
  keypad    = 13,
  safe      = 15,
  hotwire   = 13,
  robbery   = 12,
  keysearch = 11
}

-- “Target grade” (1..4) adds DC (you can feed this from vehicle class, door tier, safe tier, etc.)
Config.GradeDC = {
  [1] = 0,
  [2] = 2,
  [3] = 4,
  [4] = 6,
}

-- Skill scaling: every N skill reduces DC by 1
Config.SkillBonusPerLevels = 10
Config.MaxSkillBonus = 8

-- Tool bonuses (optional)
Config.ToolBonuses = {
  lockpick_basic    = 0,
  lockpick_advanced = 2,

  hacking_laptop    = 1,
  hacking_usb       = 2,

  keypad_decoder    = 2,
  safe_drill        = 2,

  keysearch_gloves  = 1,
  keysearch_flash   = 1,

  hotwire_kit       = 2
}

-- Clamp DC
Config.MinDC = 5
Config.MaxDC = 25
