fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'ALN42 Dice Bridge: unified DC calc + bg3_dice RollCheck wrapper'

shared_scripts {
  'config.lua',
}

client_scripts {
  'client.lua',
}

server_scripts {
  'server.lua',
}
