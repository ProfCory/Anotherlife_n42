local function clamp(x, a, b)
  if x < a then return a end
  if x > b then return b end
  return x
end

-- Server-side DC calculation (authoritative)
-- Caller provides:
-- activity: string (lockpick/hacking/etc)
-- grade: number 1..4 (target difficulty tier)
-- skillLevel: number 0..100+ (optional)
-- toolKey: string (optional)
RegisterNetEvent('aln42:dicebridge:calcDC', function(reqId, activity, grade, skillLevel, toolKey)
  local src = source
  if not reqId then return end

  local base = Config.BaseDC[activity] or 12
  local g = tonumber(grade) or 2
  local gradeDC = Config.GradeDC[g] or 0

  local sl = tonumber(skillLevel) or 0
  local skillBonus = math.floor(sl / (Config.SkillBonusPerLevels or 10))
  skillBonus = clamp(skillBonus, 0, Config.MaxSkillBonus or 8)

  local toolBonus = 0
  if toolKey and Config.ToolBonuses[toolKey] then
    toolBonus = tonumber(Config.ToolBonuses[toolKey]) or 0
  end

  local dc = base + gradeDC - skillBonus - toolBonus
  dc = clamp(dc, Config.MinDC or 5, Config.MaxDC or 25)

  TriggerClientEvent('aln42:dicebridge:dcResult', src, reqId, {
    activity = activity,
    dc = dc,
    grade = g,
    base = base,
    gradeDC = gradeDC,
    skillBonus = skillBonus,
    toolBonus = toolBonus,
  })
end)
