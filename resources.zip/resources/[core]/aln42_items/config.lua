Config = {}

-- Max stack per item in a "slotless" inventory
Config.MaxStack = 99

-- Commands
Config.Commands = {
  give = 'giveitem',
  inv = 'inv',
  use = 'use',
}

-- Starter items on new character (optional)
Config.StarterItems = {
  { name = 'fake_id', count = 1 },      -- grants +lives if you want, later
  { name = 'bandage', count = 3 },
  { name = 'water', count = 2 },
}
