fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'ALN42 Items: frameworkless registry + give/use + license gates'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'

files {
  'items/*.png',
  'data/items.json'
}
