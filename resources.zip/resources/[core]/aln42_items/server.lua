local ITEMS_FILE = 'data/items.json'
local Items = {}
local Inventories = {} -- keyed by character CID

local function loadItems()
  local raw = LoadResourceFile(GetCurrentResourceName(), ITEMS_FILE)
  Items = raw and raw ~= '' and json.decode(raw) or {}
end

local function getChar(src)
  if GetResourceState('aln42_characters') ~= 'started' then return nil end
  return exports['aln42_characters']:GetCharacter(src)
end

local function getCID(src)
  local c = getChar(src)
  if not c or not c.id or not c.id.cid then return nil end
  return c.id.cid
end

local function inv(cid)
  Inventories[cid] = Inventories[cid] or {}
  return Inventories[cid]
end

local function getStackLimit(itemName)
  local def = Items[itemName]
  if not def then return 99 end
  if def.stack then return tonumber(def.stack) or 99 end
  return 99
end

local function addItem(cid, name, count)
  count = tonumber(count) or 1
  if count <= 0 then return false end
  if not Items[name] then return false end

  local i = inv(cid)
  local limit = getStackLimit(name)
  local have = tonumber(i[name]) or 0
  if have + count > limit then
    i[name] = limit
  else
    i[name] = have + count
  end
  return true
end

local function removeItem(cid, name, count)
  count = tonumber(count) or 1
  local i = inv(cid)
  local have = tonumber(i[name]) or 0
  if have < count then return false end
  i[name] = have - count
  if i[name] <= 0 then i[name] = nil end
  return true
end

-- EXPORTS (for other resources)
exports('HasItem', function(src, name, count)
  local cid = getCID(src)
  if not cid then return false end
  count = tonumber(count) or 1
  local have = tonumber(inv(cid)[name]) or 0
  return have >= count
end)

exports('GetCount', function(src, name)
  local cid = getCID(src)
  if not cid then return 0 end
  return tonumber(inv(cid)[name]) or 0
end)

exports('GiveItem', function(src, name, count)
  local cid = getCID(src)
  if not cid then return false, 'no_character' end
  if not Items[name] then return false, 'unknown_item' end
  return addItem(cid, name, count), nil
end)

exports('TakeItem', function(src, name, count)
  local cid = getCID(src)
  if not cid then return false, 'no_character' end
  return removeItem(cid, name, count), nil
end)

exports('GetInventory', function(src)
  local cid = getCID(src)
  if not cid then return {} end
  return inv(cid)
end)

-- Simple events to inspect inventory (optional)
RegisterNetEvent('aln42:items:requestInv', function()
  local src = source
  local cid = getCID(src)
  if not cid then
    TriggerClientEvent('aln42:items:inv', src, {})
    return
  end
  TriggerClientEvent('aln42:items:inv', src, inv(cid))
end)

AddEventHandler('onResourceStart', function(res)
  if res ~= GetCurrentResourceName() then return end
  loadItems()
end)
