local function notify(msg)
  print(('[ALN42 Items] %s'):format(msg))
  TriggerEvent('chat:addMessage', { args = { '^2ALN42-Items', msg } })
end

RegisterNetEvent('aln42:items:toast', function(msg) notify(msg) end)

RegisterNetEvent('aln42:items:inv', function(inv)
  notify('Inventory:')
  for k, v in pairs(inv) do
    notify((' - %s x%d'):format(k, v))
  end
end)

RegisterNetEvent('aln42:items:effect', function(effect)
  local ped = PlayerPedId()
  if effect == 'drink' then
    TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_DRINKING', 0, true)
    Wait(2500)
    ClearPedTasks(ped)
  elseif effect == 'bandage' then
    SetEntityHealth(ped, math.min(GetEntityMaxHealth(ped), GetEntityHealth(ped) + 25))
  elseif effect == 'weapon_pistol' then
    GiveWeaponToPed(ped, joaat('WEAPON_PISTOL'), 36, false, true)
  end
end)

RegisterCommand(Config.Commands.give, function(_, args)
  local name = args[1]
  local count = tonumber(args[2]) or 1
  if not name then
    notify('Usage: /giveitem <name> <count>')
    return
  end
  TriggerServerEvent('aln42:items:give', name, count)
end, false)

RegisterCommand(Config.Commands.inv, function()
  TriggerServerEvent('aln42:items:requestInv')
end, false)

RegisterCommand(Config.Commands.use, function(_, args)
  local name = args[1]
  if not name then
    notify('Usage: /use <name>')
    return
  end
  TriggerServerEvent('aln42:items:use', name)
end, false)
