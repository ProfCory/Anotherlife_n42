fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'ALN42 Needs + Vehicle Status (fuel, engine, hot car), frameworkless, HUD-ready exports'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'
