local needs = {
  hunger = 100, thirst = 100, stress = 0, impaired = 0,
  staminaBuffUntil = 0,
  painIgnoreUntil = 0
}

local vehState = { plate=nil, fuel=100.0, heat=0.0 }
local awaitingPay = nil

local function now() return GetGameTimer() end

local function clamp(x,a,b) if x<a then return a elseif x>b then return b else return x end end

local function notify(msg)
  print(('[ALN42 Needs] %s'):format(msg))
  TriggerEvent('chat:addMessage', { args = { '^4ALN42-Needs', msg } })
end

RegisterNetEvent('aln42:needs:toast', function(msg) notify(msg) end)
RegisterNetEvent('aln42:needs:loaded', function(n)
  if type(n) ~= 'table' then return end
  for k,v in pairs(n) do
    if type(v) == 'number' then needs[k] = v end
  end
end)

RegisterNetEvent('aln42:veh:set', function(plate, s)
  if type(s) ~= 'table' then return end
  vehState.plate = plate
  vehState.fuel = tonumber(s.fuel) or vehState.fuel
  vehState.heat = tonumber(s.heat) or vehState.heat
end)

RegisterNetEvent('aln42:veh:pay:result', function(ok)
  if awaitingPay then
    awaitingPay(ok == true)
    awaitingPay = nil
  end
end)

local function saveNeeds()
  TriggerServerEvent('aln42:needs:save', needs)
end

local function loadNeeds()
  TriggerServerEvent('aln42:needs:load')
end

-- Export for HUD/phone later
exports('GetNeeds', function()
  return needs
end)

exports('GetVehicleStatus', function()
  return vehState
end)

local function applyEffect(tag)
  local e = Config.Effects[tag]
  if not e then return end

  if e.hunger then needs.hunger = clamp(needs.hunger + e.hunger, 0, 100) end
  if e.thirst then needs.thirst = clamp(needs.thirst + e.thirst, 0, 100) end
  if e.stress then needs.stress = clamp(needs.stress + e.stress, 0, 100) end
  if e.impaired then needs.impaired = clamp(needs.impaired + e.impaired, 0, 100) end

  if e.staminaBuffSec then
    needs.staminaBuffUntil = math.max(needs.staminaBuffUntil or 0, now() + (e.staminaBuffSec * 1000))
  end
  if e.painIgnoreSec then
    needs.painIgnoreUntil = math.max(needs.painIgnoreUntil or 0, now() + (e.painIgnoreSec * 1000))
  end
end

local function itemTags(itemName)
  local raw = LoadResourceFile('aln42_items', 'data/items.json')
  if not raw or raw == '' then return {} end
  local ok, defs = pcall(json.decode, raw)
  if not ok or type(defs) ~= 'table' then return {} end
  local def = defs[itemName]
  if not def or type(def.tags) ~= 'table' then return {} end
  return def.tags
end

local function useItem(itemName)
  if GetResourceState('aln42_items') ~= 'started' then
    notify('aln42_items not running.')
    return
  end

  if not exports['aln42_items']:HasItem(PlayerId(), itemName, 1) then
    notify('You do not have that item.')
    return
  end

  -- apply tag-driven effects
  local tags = itemTags(itemName)

  -- baseline tag groups
  if table.concat(tags, ' '):find('food') then applyEffect('food') end
  if table.concat(tags, ' '):find('drink') then applyEffect('drink') end
  if table.concat(tags, ' '):find('junk') then applyEffect('junk') end
  if table.concat(tags, ' '):find('drug') then applyEffect('drug') end

  -- specific tags
  for _, t in ipairs(tags) do
    if t == 'coffee' then applyEffect('coffee') end
    if t == 'soda' then applyEffect('soda') end
    if t == 'liquor' then applyEffect('liquor') end
    if t == 'pain_ignore' then applyEffect('painkillers') end
    if t == 'fuel_can' then
      -- fuel can is handled via /fuel usecan
    end
  end

  exports['aln42_items']:TakeItem(PlayerId(), itemName, 1)
  TriggerServerEvent('aln42:items:use', itemName)
  notify(('Used %s'):format(itemName))
end

-- Commands to use items until HUD/phone
RegisterCommand('use', function(_, args)
  local item = args[1]
  if not item then notify('Usage: /use <itemId>'); return end
  useItem(item)
end, false)

-- Vehicle state: attach to current vehicle plate
local function ensureVehicleState()
  local ped = PlayerPedId()
  local veh = GetVehiclePedIsIn(ped, false)
  if veh == 0 then return end
  local plate = tostring(GetVehicleNumberPlateText(veh) or '')
  plate = plate:gsub('%s+','')
  if plate == '' then return end
  if vehState.plate ~= plate then
    TriggerServerEvent('aln42:veh:get', plate)
  end
end

local function setFuel(newFuel)
  vehState.fuel = clamp(newFuel, 0.0, Config.Vehicle.fuelMax or 100.0)
  TriggerServerEvent('aln42:veh:set', vehState.plate, { fuel = vehState.fuel, heat = vehState.heat })
end

local function setHeat(newHeat)
  vehState.heat = clamp(newHeat, 0.0, Config.Vehicle.heatMax or 100.0)
  TriggerServerEvent('aln42:veh:set', vehState.plate, { fuel = vehState.fuel, heat = vehState.heat })
end

-- Gas station proximity uses aln42_locations type="gas"
local gasLocations = {}

local function readGasLocations()
  local raw = LoadResourceFile('aln42_locations', 'data/locations.json')
  if not raw or raw == '' then return {} end
  local ok, parsed = pcall(json.decode, raw)
  if not ok or type(parsed) ~= 'table' then return {} end
  local out = {}
  for _, loc in ipairs(parsed) do
    if loc and loc.type == 'gas' and loc.coords then table.insert(out, loc) end
  end
  return out
end

local function nearGas(range)
  local p = GetEntityCoords(PlayerPedId())
  local p3 = {x=p.x,y=p.y,z=p.z}
  for _, loc in ipairs(gasLocations) do
    local c = loc.coords
    local dx=p3.x-c.x; local dy=p3.y-c.y; local dz=p3.z-c.z
    local d = math.sqrt(dx*dx+dy*dy+dz*dz)
    if d <= (range or 4.0) then return true, loc end
  end
  return false, nil
end

-- Fuel commands
-- /fuel status
-- /fuel fill (at gas station, charges cash)
-- /fuel usecan (consumes jerrycan_fuel)
RegisterCommand('fuel', function(_, args)
  local sub = (args[1] or 'status'):lower()
  ensureVehicleState()
  if not vehState.plate then notify('No vehicle state (get in a vehicle).'); return end

  if sub == 'status' then
    notify(('Fuel: %.1f / %.1f | Heat: %.0f / %.0f')
      :format(vehState.fuel, Config.Vehicle.fuelMax, vehState.heat, Config.Vehicle.heatMax))
    return
  end

  if sub == 'usecan' then
    if GetResourceState('aln42_items') ~= 'started' then notify('aln42_items not running.'); return end
    if not exports['aln42_items']:HasItem(PlayerId(), 'jerrycan_fuel', 1) then
      notify('You need jerrycan_fuel.')
      return
    end
    exports['aln42_items']:TakeItem(PlayerId(), 'jerrycan_fuel', 1)
    setFuel(vehState.fuel + (Config.Vehicle.jerryCanAdds or 20.0))
    notify('Jerry can used.')
    return
  end

  if sub == 'fill' then
    local ok = nearGas(6.0)
    if not ok then notify('You must be at a gas station.'); return end
    local need = (Config.Vehicle.fuelMax or 100.0) - vehState.fuel
    if need <= 0.1 then notify('Tank already full.'); return end
    local cost = math.floor(need * (Config.Vehicle.fillCostPerUnit or 2))

    awaitingPay = function(paid)
      if not paid then return end
      setFuel(Config.Vehicle.fuelMax or 100.0)
      notify(('Fuel filled for $%d'):format(cost))
    end
    TriggerServerEvent('aln42:veh:pay', cost)
    return
  end

  notify('Usage: /fuel status | /fuel fill | /fuel usecan')
end, false)

-- Repair with toolbox + dicebridge
RegisterCommand('vehfix', function()
  local ped = PlayerPedId()
  local v = GetVehiclePedIsIn(ped, false)
  if v == 0 then notify('Get in a vehicle.'); return end

  if GetResourceState('aln42_items') ~= 'started' then notify('aln42_items not running.'); return end
  if not exports['aln42_items']:HasItem(PlayerId(), Config.Repair.toolboxItem, 1) then
    notify('You need a toolbox.')
    return
  end

  if GetResourceState('aln42_dicebridge') ~= 'started' then
    notify('Dice bridge not running.')
    return
  end

  DoScreenFadeOut(400)
  Wait(450)

  local ok = exports['aln42_dicebridge']:Roll(Config.Repair.dc, 0, Config.Repair.mode, { activity = Config.Repair.activity })
  if ok then
    local eh = GetVehicleEngineHealth(v)
    local bh = GetVehicleBodyHealth(v)
    SetVehicleEngineHealth(v, clamp(eh + (Config.Repair.onSuccessEngineAdd or 250.0), 0.0, 1000.0))
    SetVehicleBodyHealth(v, clamp(bh + (Config.Repair.onSuccessBodyAdd or 200.0), 0.0, 1000.0))
    notify('Repair succeeded.')
  else
    notify('Repair failed.')
  end

  DoScreenFadeIn(500)
end, false)

-- Needs decay + effects tick
CreateThread(function()
  if not Config.Enabled then return end

  gasLocations = readGasLocations()
  loadNeeds()

  local lastSave = now()
  local lastTick = now()
  local lastWanted = 0

  while true do
    ensureVehicleState()

    local t = now()
    local dt = (t - lastTick) / 1000.0
    lastTick = t

    -- decay (per minute)
    local perMin = Config.DecayPerMin
    needs.hunger = clamp(needs.hunger - (perMin.hunger/60.0)*dt, 0, 100)
    needs.thirst = clamp(needs.thirst - (perMin.thirst/60.0)*dt, 0, 100)
    needs.impaired = clamp(needs.impaired - (perMin.impairedDown/60.0)*dt, 0, 100)

    -- stamina buff: extend sprint
    if t < (needs.staminaBuffUntil or 0) then
      RestorePlayerStamina(PlayerId(), 0.4)
    end

    -- “pain ignore”: reduce health loss feeling (simple: regen a bit, and lower ragdoll chance)
    if t < (needs.painIgnoreUntil or 0) then
      local hp = GetEntityHealth(PlayerPedId())
      SetEntityHealth(PlayerPedId(), math.min(hp + 1, 200))
      SetPedCanRagdoll(PlayerPedId(), false)
    else
      SetPedCanRagdoll(PlayerPedId(), true)
    end

    -- Stress relief activities: boat/plane while driving
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
      local cls = GetVehicleClass(veh)
      if cls == 14 then
        needs.stress = clamp(needs.stress + (Config.Activity.boat.stressPerMin/60.0)*dt, 0, 100)
      elseif cls == 15 or cls == 16 then
        needs.stress = clamp(needs.stress + (Config.Activity.plane.stressPerMin/60.0)*dt, 0, 100)
      end
    end

    -- Vehicle fuel + heat
    if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped and vehState.plate then
      local speed = GetEntitySpeed(veh)
      local use = (speed < 1.0) and (Config.Vehicle.fuelUsePerSecIdle or 0.0008) or (Config.Vehicle.fuelUsePerSecDrive or 0.0020)
      if vehState.fuel > 0.0 then
        vehState.fuel = clamp(vehState.fuel - use, 0.0, Config.Vehicle.fuelMax)
        if math.random() < 0.02 then
          TriggerServerEvent('aln42:veh:set', vehState.plate, { fuel = vehState.fuel, heat = vehState.heat })
        end
      end

      -- heat gain based on wanted star increases while driving this car
      local wanted = GetPlayerWantedLevel(PlayerId())
      if wanted > lastWanted then
        local gain = (wanted - lastWanted) * (Config.Vehicle.heatGainPerWantedStar or 9.0)
        vehState.heat = clamp(vehState.heat + gain, 0.0, Config.Vehicle.heatMax)
        TriggerServerEvent('aln42:veh:set', vehState.plate, { fuel = vehState.fuel, heat = vehState.heat })
      end
      lastWanted = wanted

      -- On sight hostility when max heat
      if vehState.heat >= (Config.Vehicle.heatHostileAt or 100.0) then
        SetPlayerWantedLevel(PlayerId(), Config.Vehicle.heatWantedOnSight or 2, false)
        SetPlayerWantedLevelNow(PlayerId(), false)
      end
    else
      lastWanted = GetPlayerWantedLevel(PlayerId())
      -- heat decay while not actively driving
      if vehState.plate and vehState.heat > 0.0 then
        local dec = (Config.Vehicle.heatDecayPerMin/60.0)*dt
        vehState.heat = clamp(vehState.heat - dec, 0.0, Config.Vehicle.heatMax)
        if math.random() < 0.03 then
          TriggerServerEvent('aln42:veh:set', vehState.plate, { fuel = vehState.fuel, heat = vehState.heat })
        end
      end
    end

    -- save periodically
    if (t - lastSave) >= ((Config.SaveEvery or 30) * 1000) then
      saveNeeds()
      lastSave = t
    end

    Wait(500)
  end
end)
