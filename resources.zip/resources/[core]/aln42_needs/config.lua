Config = {}

Config.Enabled = true

-- Save cadence (seconds)
Config.SaveEvery = 30

-- Needs decay per minute
Config.DecayPerMin = {
  hunger = 1.3,
  thirst = 1.8,
  stressDown = 0.0,   -- passive stress relief (0 by default)
  impairedDown = 1.0
}

-- Effects (base)
Config.Effects = {
  food = { hunger = 25 },
  drink = { thirst = 25 },
  junk = { hunger = 18, stress = -12 },

  soda = { thirst = 18, staminaBuffSec = 60 },
  coffee = { thirst = 14, staminaBuffSec = 120 },

  liquor = { stress = -18, painIgnoreSec = 75, impaired = 20 },
  painkillers = { painIgnoreSec = 90 },

  drug = { stress = -25, impaired = 35 }
}

-- Stress relief by activities
Config.Activity = {
  boat = { stressPerMin = -8 },
  plane = { stressPerMin = -10 }
}

-- Vehicle fuel
Config.Vehicle = {
  fuelMax = 100.0,
  fuelUsePerSecIdle = 0.0008,
  fuelUsePerSecDrive = 0.0020,
  lowFuelAt = 15.0,

  jerryCanAdds = 20.0,          -- one can adds this fuel
  fillCostPerUnit = 2,          -- $ per 1 fuel unit

  -- Hot car heat
  heatMax = 100.0,
  heatGainPerWantedStar = 9.0,  -- heat added when you gain stars while in the vehicle
  heatDecayPerMin = 2.0,
  heatHostileAt = 100.0,        -- at full heat, cops treat as hostile “on sight” behavior
  heatWantedOnSight = 2         -- wanted level applied when driving a max-heat car
}

-- Dicebridge repair
Config.Repair = {
  toolboxItem = 'toolbox',
  activity = 'veh_repair',
  grade = 2,
  dc = 12,
  mode = 'normal',
  onSuccessEngineAdd = 250.0,   -- adds to engine health (clamped)
  onSuccessBodyAdd = 200.0
}
