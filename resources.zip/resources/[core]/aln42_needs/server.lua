local veh = {} -- [plate] = { fuel=, heat=, last=unix }

local function chars()
  if GetResourceState('aln42_characters') ~= 'started' then return nil end
  return exports['aln42_characters']
end

local function items()
  if GetResourceState('aln42_items') ~= 'started' then return nil end
  return exports['aln42_items']
end

local function normPlate(p)
  p = tostring(p or ''):upper()
  p = p:gsub('%s+', '')
  return p
end

local function getChar(src)
  local ch = chars()
  if not ch then return nil end
  return ch:GetCharacter(src)
end

local function ensureNeedsMeta(c)
  c.meta = c.meta or {}
  c.meta.needs = c.meta.needs or {
    hunger = 100, thirst = 100, stress = 0, impaired = 0,
    staminaBuffUntil = 0,
    painIgnoreUntil = 0
  }
  return c.meta.needs
end

RegisterNetEvent('aln42:needs:load', function()
  local src = source
  local c = getChar(src)
  if not c then return end
  local n = ensureNeedsMeta(c)
  TriggerClientEvent('aln42:needs:loaded', src, n)
end)

RegisterNetEvent('aln42:needs:save', function(payload)
  local src = source
  local c = getChar(src)
  if not c then return end
  local n = ensureNeedsMeta(c)
  if type(payload) ~= 'table' then return end

  for k,v in pairs(payload) do
    if type(v) == 'number' then
      n[k] = v
    end
  end
end)

RegisterNetEvent('aln42:veh:get', function(plate)
  local src = source
  plate = normPlate(plate)
  if plate == '' then return end
  local s = veh[plate]
  if not s then
    s = { fuel = Config.Vehicle.fuelMax, heat = 0.0, last = os.time() }
    veh[plate] = s
  end
  TriggerClientEvent('aln42:veh:set', src, plate, s)
end)

RegisterNetEvent('aln42:veh:set', function(plate, state)
  plate = normPlate(plate)
  if plate == '' or type(state) ~= 'table' then return end
  veh[plate] = veh[plate] or { fuel = Config.Vehicle.fuelMax, heat = 0.0, last = os.time() }
  local s = veh[plate]
  if type(state.fuel) == 'number' then s.fuel = state.fuel end
  if type(state.heat) == 'number' then s.heat = state.heat end
  s.last = os.time()
end)

RegisterNetEvent('aln42:veh:pay', function(amount)
  local src = source
  local it = items()
  if not it then return end
  amount = math.floor(tonumber(amount) or 0)
  if amount <= 0 then return end
  if not it:HasItem(src, 'cash', amount) then
    TriggerClientEvent('aln42:needs:toast', src, 'Not enough cash.')
    TriggerClientEvent('aln42:veh:pay:result', src, false)
    return
  end
  it:TakeItem(src, 'cash', amount)
  TriggerClientEvent('aln42:veh:pay:result', src, true)
end)

RegisterNetEvent('aln42:items:use', function(itemName)
  -- optional hook if you want server-side auditing later
end)
