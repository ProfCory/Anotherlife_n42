const wrap = document.getElementById('wrap');
const frame = document.getElementById('frame');
const list = document.getElementById('list');
const title = document.getElementById('title');

let idx = 0;
let items = [
  { id:'vendors', label:'Nearby vendor list' },
  { id:'stash', label:'Open stash' },
  { id:'garage', label:'Garage list' },
  { id:'bank', label:'Bank (stub)' },
  { id:'messages', label:'Messages (stub)' },
];

function post(name, data) {
  fetch(`https://${GetParentResourceName()}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(data || {})
  });
}

function render() {
  list.innerHTML = '';
  items.forEach((it, i) => {
    const el = document.createElement('div');
    el.className = 'row' + (i === idx ? ' sel' : '');
    el.textContent = it.label;
    list.appendChild(el);
  });
}

window.addEventListener('message', (e) => {
  const msg = e.data;
  if (!msg || !msg.type) return;

  if (msg.type === 'open') {
    wrap.classList.remove('hidden');
    frame.classList.remove('aphone','bardsung');
    frame.classList.add(msg.skin === 'bardsung' ? 'bardsung' : 'aphone');
    title.textContent = msg.skin === 'bardsung' ? 'BARDSUNG' : 'APHONE';
    idx = 0;
    render();
  }
  if (msg.type === 'close') {
    wrap.classList.add('hidden');
  }
});

document.addEventListener('keydown', (e) => {
  if (wrap.classList.contains('hidden')) return;

  if (e.key === 'ArrowUp') { idx = Math.max(0, idx - 1); render(); }
  else if (e.key === 'ArrowDown') { idx = Math.min(items.length - 1, idx + 1); render(); }
  else if (e.key === 'Enter') { post('action', items[idx]); }
  else if (e.key === 'Backspace' || e.key === 'Escape') { post('close'); }
});
