local phoneMode = 'none' -- none|burner|smart
local burnerOpen = false
local burnerIdx = 1

local function hasRes(name) return GetResourceState(name) == 'started' end

local function hasItemSafe(item)
  if not hasRes('aln42_items') then return false end
  local sid = GetPlayerServerId(PlayerId())

  local ok, res = pcall(function() return exports['aln42_items']:HasItem(sid, item, 1) end)
  if ok then return res == true end

  ok, res = pcall(function() return exports['aln42_items']:HasItem(PlayerId(), item, 1) end)
  return ok and res == true
end

local function getMode()
  if Config.SmartItem and hasItemSafe(Config.SmartItem) then return 'smart' end
  if Config.BurnerItem and hasItemSafe(Config.BurnerItem) then return 'burner' end
  return 'none'
end

local function inVehicle()
  return IsPedInAnyVehicle(PlayerPedId(), false)
end

local function allowedRadar(mode)
  local rule = (Config.Radar and Config.Radar[mode]) or Config.Radar.none
  return inVehicle() and rule.inVehicle or rule.onFoot
end

local function allowedNeeds(mode)
  local rule = (Config.NeedsHud and Config.NeedsHud[mode]) or Config.NeedsHud.none
  return inVehicle() and rule.inVehicle or rule.onFoot
end

local function drawTxt(x,y,text,scale)
  SetTextFont(0)
  SetTextScale(scale or 0.32, scale or 0.32)
  SetTextOutline()
  BeginTextCommandDisplayText('STRING')
  AddTextComponentString(text)
  EndTextCommandDisplayText(x, y)
end

local function pct(v)
  v = tonumber(v) or 0
  v = math.floor(v)
  if v < 0 then v = 0 end
  if v > 100 then v = 100 end
  return v
end

local function badge(label, v)
  v = pct(v)
  if v <= 15 then return ('~r~%s %d~s~'):format(label, v) end
  if v <= 35 then return ('~y~%s %d~s~'):format(label, v) end
  return ('%s %d'):format(label, v)
end

local function toast(msg)
  TriggerEvent('chat:addMessage', { args = { '^3ALN42 Phone', msg } })
end

-- Notifications (simple popups)
RegisterNetEvent('aln42:phone:notify', function(_, title, body)
  title = tostring(title or '')
  body = tostring(body or '')
  BeginTextCommandThefeedPost('STRING')
  AddTextComponentSubstringPlayerName(('%s: %s'):format(title, body))
  EndTextCommandThefeedPostTicker(false, true)
end)

-- ---------- Burner menu (no HTML) ----------
local function burnerItems()
  return (Config.BurnerMenu and Config.BurnerMenu.items) or {}
end

local function burnerClose()
  burnerOpen = false
end

local function burnerRun(itemId)
  if itemId == 'vendors' then
    if Config.UseContextMenu and hasRes(Config.ContextMenuResource) then
      local ok = pcall(function() exports[Config.ContextMenuResource][Config.ContextMenuExport]('burner') end)
      if ok then return end
    end
    ExecuteCommand(Config.VendorCommand or 'shop list')
    return
  end

  if itemId == 'stash' then
    ExecuteCommand(Config.StashCommand or 'stash')
    return
  end

  if itemId == 'garage' then
    ExecuteCommand(Config.GarageCommand or 'garage vehicles')
    return
  end

  if itemId == 'needs' then
    if hasRes('aln42_needs') then
      local n = exports['aln42_needs']:GetNeeds() or {}  -- ✅ matches your needs export :contentReference[oaicite:3]{index=3}
      toast(('Hunger %d | Thirst %d | Stress %d'):format(pct(n.hunger), pct(n.thirst), pct(n.stress)))
    else
      toast('Needs system not started.')
    end
    return
  end
end

local function burnerOpenMenu()
  burnerOpen = true
  burnerIdx = 1
end

local function burnerDraw()
  local title = (Config.BurnerMenu and Config.BurnerMenu.title) or 'BURNER'
  local items = burnerItems()
  if #items == 0 then
    drawTxt(0.78, 0.20, '~y~'..title..'~s~', 0.45)
    drawTxt(0.78, 0.24, 'No entries.', 0.35)
    return
  end

  drawTxt(0.78, 0.18, ('~y~%s~s~'):format(title), 0.48)
  drawTxt(0.78, 0.21, 'UP/DOWN • ENTER • BACK', 0.30)

  local y = 0.25
  for i, it in ipairs(items) do
    local prefix = (i == burnerIdx) and '~g~>~s~ ' or '  '
    drawTxt(0.78, y, prefix .. (it.label or it.id), 0.38)
    y = y + 0.028
  end
end

-- ---------- Smart UI (HTML, simple) ----------
local smartOpen = false

local function smartSetOpen(state)
  smartOpen = state

  if smartOpen then
    SetNuiFocus(true, true)
    SendNUIMessage({
      type = 'open',
      skin = Config.SmartSkin or 'aphone'
    })
  else
    SetNuiFocus(false, false)
    SendNUIMessage({ type = 'close' })
  end
end

RegisterNUICallback('close', function(_, cb)
  smartSetOpen(false)
  cb(true)
end)

RegisterNUICallback('action', function(data, cb)
  local id = data and data.id
  if not id then cb(true); return end

  -- For now, same actions as burner + room to grow
  if id == 'vendors' then ExecuteCommand(Config.VendorCommand or 'shop list') end
  if id == 'stash' then ExecuteCommand(Config.StashCommand or 'stash') end
  if id == 'garage' then ExecuteCommand(Config.GarageCommand or 'garage vehicles') end
  if id == 'bank' then toast('Bank app stub (next step: ATM/pin + balance).') end
  if id == 'messages' then toast('Messages stub (next step: message log).') end

  cb(true)
end)

-- ---------- Open phone ----------
local function openPhone()
  local mode = getMode()
  if mode == 'none' then toast('No phone.'); return end

  if mode == 'burner' then
    burnerOpenMenu()
    return
  end

  -- smart
  if Config.SmartUI then
    smartSetOpen(true)
    return
  end

  -- fallback: context menu
  if Config.UseContextMenu and hasRes(Config.ContextMenuResource) then
    local ok, err = pcall(function()
      exports[Config.ContextMenuResource][Config.ContextMenuExport]('smart')
    end)
    if ok then return end
    toast(('ContextMenu export failed: %s'):format(tostring(err)))
  end

  toast('Smart: apps soon.')
end

RegisterCommand(Config.OpenCommand or 'phone', function()
  openPhone()
end, false)

RegisterKeyMapping(Config.OpenCommand or 'phone', 'Phone: Open', 'keyboard', Config.OpenKeyKeyboard or 'M')
RegisterKeyMapping(Config.OpenCommand or 'phone', 'Phone: Open', 'PAD_DIGITALBUTTON', Config.OpenKeyPad or 'LUP_INDEX')

-- Update mode periodically
CreateThread(function()
  if not Config.Enabled then return end
  while true do
    phoneMode = getMode()
    Wait(Config.ScanMs or 750)
  end
end)

-- Burner input loop
CreateThread(function()
  while true do
    if burnerOpen then
      DisableControlAction(0, 24, true)
      DisableControlAction(0, 25, true)

      local items = burnerItems()

      if IsControlJustPressed(0, 172) then burnerIdx = math.max(1, burnerIdx - 1) end -- up
      if IsControlJustPressed(0, 173) then burnerIdx = math.min(#items, burnerIdx + 1) end -- down
      if IsControlJustPressed(0, 191) then
        local it = items[burnerIdx]
        if it then burnerRun(it.id) end
        burnerClose()
      end
      if IsControlJustPressed(0, 177) then burnerClose() end -- backspace

      burnerDraw()
      Wait(0)
    else
      Wait(100)
    end
  end
end)

-- Enforce gating continuously (radar + needs owned by phone)
CreateThread(function()
  if not Config.Enabled then return end

  while true do
    DisplayRadar(allowedRadar(phoneMode))

    if allowedNeeds(phoneMode) and hasRes('aln42_needs') then
      local n = exports['aln42_needs']:GetNeeds() or {}          -- ✅ your export :contentReference[oaicite:4]{index=4}
      local vs = exports['aln42_needs']:GetVehicleStatus() or {} -- ✅ your export :contentReference[oaicite:5]{index=5}

      local x = Config.Badge.x
      local y = Config.Badge.y
      local dy = Config.Badge.line

      drawTxt(x, y + 0*dy, badge('HU', n.hunger or 100), 0.32)
      drawTxt(x, y + 1*dy, badge('TH', n.thirst or 100), 0.32)
      drawTxt(x, y + 2*dy, badge('ST', n.stress or 0), 0.32)

      if inVehicle() then
        drawTxt(x, y + 3*dy, badge('FU', vs.fuel or 100), 0.32)
        drawTxt(x, y + 4*dy, badge('HE', vs.heat or 0), 0.32)
      end
    end

    Wait(0)
  end
end)
