-- Simple notification relay (later: persist “email inbox” in character meta)
RegisterNetEvent('aln42:phone:notify', function(kind, title, body)
  TriggerClientEvent('aln42:phone:notify', -1, kind, title, body)
end)
