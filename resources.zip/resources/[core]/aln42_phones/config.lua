Config = {}

Config.Enabled = true

-- Item IDs in aln42_items
Config.BurnerItem = 'nokia'
Config.SmartItem  = 'smart_phone'

Config.ScanMs = 750

-- Open phone keybind
Config.OpenCommand = 'phone'
Config.OpenKeyKeyboard = 'M'
Config.OpenKeyPad = 'LUP_INDEX'  -- D-Pad Up (fixes “Invalid key name PAD_UP”)

-- Radar rules
Config.Radar = {
  none   = { onFoot = false, inVehicle = false },
  burner = { onFoot = false, inVehicle = true  },
  smart  = { onFoot = true,  inVehicle = true  }
}

-- Needs HUD rules (phone owns the needs display)
Config.NeedsHud = {
  none   = { onFoot = false, inVehicle = false },
  burner = { onFoot = false, inVehicle = true  },
  smart  = { onFoot = true,  inVehicle = true  }
}

Config.Badge = { x = 0.015, y = 0.78, line = 0.022 }

-- Burner UI (no HTML): list-only controls
Config.BurnerMenu = {
  title = 'NOKIA',
  items = {
    { id='vendors', label='Nearby vendor list' },
    { id='stash',   label='Open stash' },
    { id='garage',  label='Garage list' },
    { id='needs',   label='Needs status (chat)' },
  }
}

-- Smart UI (HTML): simple, functional now
Config.SmartUI = true
Config.SmartSkin = 'aphone' -- 'aphone' or 'bardsung'

-- Vendors integration (fallback to chat command if you don’t have direct events)
Config.VendorCommand = 'shop list'

-- Stash command
Config.StashCommand = 'stash'

-- Garage command
Config.GarageCommand = 'garage vehicles'

-- Optional: open your context menu from phone if you prefer
Config.UseContextMenu = true
Config.ContextMenuResource = 'aln42_contextmenu'
Config.ContextMenuExport = 'OpenPhoneMenu'
