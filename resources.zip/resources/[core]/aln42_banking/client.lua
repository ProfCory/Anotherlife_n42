local locations = {}
local myNear = { bank=false, atm=false, fence=false }

local function readLocations()
  local raw = LoadResourceFile('aln42_locations', 'data/locations.json')
  if not raw or raw == '' then return {} end
  local ok, parsed = pcall(json.decode, raw)
  return (ok and type(parsed) == 'table') and parsed or {}
end

local function notify(msg)
  print(('[ALN42 Banking] %s'):format(msg))
  TriggerEvent('chat:addMessage', { args = { '^3ALN42-Bank', msg } })
end

RegisterNetEvent('aln42:bank:toast', function(msg) notify(msg) end)

RegisterNetEvent('aln42:bank:balance', function(balance, minFloor)
  notify(('Bank balance: $%d (loan floor: $%d)'):format(balance, minFloor))
end)

local function dist(a, b)
  local dx = a.x - b.x
  local dy = a.y - b.y
  local dz = a.z - b.z
  return math.sqrt(dx*dx + dy*dy + dz*dz)
end

local function refreshNear()
  if not (Config.Proximity and Config.Proximity.enabled) then
    myNear.bank, myNear.atm, myNear.fence = true, true, true
    return
  end

  myNear.bank, myNear.atm, myNear.fence = false, false, false
  local p = GetEntityCoords(PlayerPedId())

  for i=1, #locations do
    local loc = locations[i]
    if loc and loc.coords and loc.type then
      local d = dist({x=p.x,y=p.y,z=p.z}, loc.coords)
      if Config.Types.banks[loc.type] and d <= (Config.Proximity.bankRange or 5.0) then myNear.bank = true end
      if Config.Types.atms[loc.type] and d <= (Config.Proximity.atmRange or 2.5) then myNear.atm = true end
      if Config.Types.fences[loc.type] and d <= (Config.Proximity.fenceRange or 5.0) then myNear.fence = true end
    end
  end
end

CreateThread(function()
  locations = readLocations()
  while true do
    refreshNear()
    Wait(500)
  end
end)

-- Commands (bank)
RegisterCommand('getcard', function()
  if not myNear.bank then
    notify('You must be at a bank to get an ATM card.')
    return
  end
  TriggerServerEvent('aln42:bank:issueCard')
end, false)

RegisterCommand('setpin', function(_, args)
  if not myNear.bank then
    notify('You must be at a bank to set your PIN.')
    return
  end
  local pin = args[1]
  if not pin then
    notify('Usage: /setpin ####')
    return
  end
  TriggerServerEvent('aln42:bank:setPin', pin)
end, false)

RegisterCommand('bankbal', function()
  if not myNear.bank then
    notify('You must be at a bank to check balance (ATM works too).')
    return
  end
  TriggerServerEvent('aln42:bank:balance')
end, false)

RegisterCommand('deposit', function(_, args)
  if not myNear.bank then
    notify('You must be at a bank to deposit (ATM works too).')
    return
  end
  local amt = tonumber(args[1] or '0')
  if amt <= 0 then notify('Usage: /deposit <amount>'); return end
  TriggerServerEvent('aln42:bank:deposit', amt)
end, false)

RegisterCommand('withdraw', function(_, args)
  if not myNear.bank then
    notify('You must be at a bank to withdraw (ATM works too).')
    return
  end
  local amt = tonumber(args[1] or '0')
  if amt <= 0 then notify('Usage: /withdraw <amount>'); return end
  TriggerServerEvent('aln42:bank:withdraw', amt)
end, false)

-- Commands (ATM)
RegisterCommand('atmpin', function(_, args)
  if not myNear.atm then
    notify('You must be at an ATM to enter PIN.')
    return
  end
  local pin = args[1]
  if not pin then notify('Usage: /atmpin ####'); return end
  TriggerServerEvent('aln42:bank:authPin', pin)
end, false)

RegisterCommand('atm', function(_, args)
  if not myNear.atm then
    notify('You must be at an ATM.')
    return
  end

  local action = (args[1] or ''):lower()
  local amt = tonumber(args[2] or '0')

  if action == 'bal' then
    TriggerServerEvent('aln42:atm:balance')
  elseif action == 'wd' then
    if amt <= 0 then notify('Usage: /atm wd <amount>'); return end
    TriggerServerEvent('aln42:atm:withdraw', amt)
  elseif action == 'dep' then
    if amt <= 0 then notify('Usage: /atm dep <amount>'); return end
    TriggerServerEvent('aln42:atm:deposit', amt)
  else
    notify('ATM usage: /atmpin ####  then  /atm bal | /atm wd <amt> | /atm dep <amt>')
  end
end, false)

-- Commands (launder)
RegisterCommand('launder', function(_, args)
  if not myNear.fence then
    notify('You must be at a fence/cash-check to launder.')
    return
  end
  local amt = tonumber(args[1] or '0')
  if amt <= 0 then notify('Usage: /launder <amount>'); return end
  TriggerServerEvent('aln42:launder', amt)
end, false)
