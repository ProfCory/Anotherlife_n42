local pinAuth = {} -- [src] = { untilTs = os.time() + N }

local function getChar(src)
  if GetResourceState('aln42_characters') ~= 'started' then return nil end
  return exports['aln42_characters']:GetCharacter(src)
end

local function getCID(src)
  local c = getChar(src)
  if not c or not c.id or not c.id.cid then return nil end
  return c.id.cid
end

-- Character persistence lives in aln42_characters' JSON file already; we’ll store banking in char.meta.
-- We retrieve the live character table via export; it’s the same table reference stored in server memory.
local function getMeta(src)
  local c = getChar(src)
  if not c then return nil end
  c.meta = c.meta or {}
  c.meta.bank = c.meta.bank or { balance = 0, pinHash = nil }
  return c.meta.bank, c
end

local function hashPin(pin)
  -- Not “secure”, but fine for solo/local. Avoid storing raw pin.
  return tostring(GetHashKey('PIN:' .. tostring(pin)))
end

local function isAuthed(src)
  local a = pinAuth[src]
  if not a or not a.untilTs then return false end
  return os.time() < a.untilTs
end

local function auth(src)
  pinAuth[src] = { untilTs = os.time() + (Config.PinAuthSeconds or 300) }
end

local function clampBank(x)
  local min = Config.MinBankBalance or -50000
  if x < min then return min end
  return x
end

local function items()
  if GetResourceState('aln42_items') ~= 'started' then return nil end
  return exports['aln42_items']
end

local function ensureCard(src)
  local it = items()
  if not it then return false, 'items_not_started' end
  return it:HasItem(src, Config.Items.card, 1)
end

RegisterNetEvent('aln42:bank:issueCard', function()
  local src = source
  local cid = getCID(src)
  if not cid then return end
  local it = items()
  if not it then return end

  if it:HasItem(src, Config.Items.card, 1) then
    TriggerClientEvent('aln42:bank:toast', src, 'You already have an ATM card.')
    return
  end

  it:GiveItem(src, Config.Items.card, 1)
  TriggerClientEvent('aln42:bank:toast', src, 'ATM card issued.')
end)

RegisterNetEvent('aln42:bank:setPin', function(pin)
  local src = source
  local bank = getMeta(src)
  if not bank then return end

  pin = tostring(pin or '')
  if #pin < 4 or #pin > 8 or not pin:match('^%d+$') then
    TriggerClientEvent('aln42:bank:toast', src, 'PIN must be 4–8 digits.')
    return
  end

  bank.pinHash = hashPin(pin)
  TriggerClientEvent('aln42:bank:toast', src, 'PIN set.')
end)

RegisterNetEvent('aln42:bank:authPin', function(pin)
  local src = source
  local bank = getMeta(src)
  if not bank then return end

  if not bank.pinHash then
    TriggerClientEvent('aln42:bank:toast', src, 'No PIN set. Go to a bank to set one.')
    return
  end

  if hashPin(pin) == bank.pinHash then
    auth(src)
    TriggerClientEvent('aln42:bank:toast', src, 'PIN accepted (session authorized).')
  else
    TriggerClientEvent('aln42:bank:toast', src, 'Wrong PIN.')
  end
end)

RegisterNetEvent('aln42:bank:balance', function()
  local src = source
  local bank = getMeta(src)
  if not bank then return end
  TriggerClientEvent('aln42:bank:balance', src, bank.balance or 0, Config.MinBankBalance or -50000)
end)

RegisterNetEvent('aln42:bank:deposit', function(amount)
  local src = source
  local bank = getMeta(src)
  if not bank then return end
  local it = items()
  if not it then return end

  amount = tonumber(amount) or 0
  if amount <= 0 then return end

  if not it:HasItem(src, Config.Items.cash, amount) then
    TriggerClientEvent('aln42:bank:toast', src, 'Not enough cash.')
    return
  end

  it:TakeItem(src, Config.Items.cash, amount)
  bank.balance = clampBank((tonumber(bank.balance) or 0) + amount)

  TriggerClientEvent('aln42:bank:toast', src, ('Deposited $%d'):format(amount))
  TriggerClientEvent('aln42:bank:balance', src, bank.balance, Config.MinBankBalance or -50000)
end)

RegisterNetEvent('aln42:bank:withdraw', function(amount)
  local src = source
  local bank = getMeta(src)
  if not bank then return end
  local it = items()
  if not it then return end

  amount = tonumber(amount) or 0
  if amount <= 0 then return end

  local bal = tonumber(bank.balance) or 0
  local newBal = clampBank(bal - amount)

  -- If clamped, you hit the debt floor; limit the withdraw
  local actual = bal - newBal
  if actual <= 0 then
    TriggerClientEvent('aln42:bank:toast', src, 'Loan limit reached. Cannot withdraw more.')
    return
  end

  bank.balance = newBal
  it:GiveItem(src, Config.Items.cash, actual)

  TriggerClientEvent('aln42:bank:toast', src, ('Withdrew $%d'):format(actual))
  TriggerClientEvent('aln42:bank:balance', src, bank.balance, Config.MinBankBalance or -50000)
end)

-- ATM actions require: card + session auth
RegisterNetEvent('aln42:atm:deposit', function(amount)
  local src = source
  if not ensureCard(src) then
    TriggerClientEvent('aln42:bank:toast', src, 'ATM card required.')
    return
  end
  if not isAuthed(src) then
    TriggerClientEvent('aln42:bank:toast', src, 'Enter PIN first: /atmpin ####')
    return
  end
  TriggerEvent('aln42:bank:deposit', amount)
end)

RegisterNetEvent('aln42:atm:withdraw', function(amount)
  local src = source
  if not ensureCard(src) then
    TriggerClientEvent('aln42:bank:toast', src, 'ATM card required.')
    return
  end
  if not isAuthed(src) then
    TriggerClientEvent('aln42:bank:toast', src, 'Enter PIN first: /atmpin ####')
    return
  end
  TriggerEvent('aln42:bank:withdraw', amount)
end)

RegisterNetEvent('aln42:atm:balance', function()
  local src = source
  if not ensureCard(src) then
    TriggerClientEvent('aln42:bank:toast', src, 'ATM card required.')
    return
  end
  if not isAuthed(src) then
    TriggerClientEvent('aln42:bank:toast', src, 'Enter PIN first: /atmpin ####')
    return
  end
  TriggerEvent('aln42:bank:balance')
end)

-- Dirty money laundering (fence/cash-check)
RegisterNetEvent('aln42:launder', function(amount)
  local src = source
  local it = items()
  if not it then return end

  amount = tonumber(amount) or 0
  if amount <= 0 then return end

  local min = Config.Launder.min or 100
  local maxPer = Config.Launder.maxPerTxn or 20000
  if amount < min then
    TriggerClientEvent('aln42:bank:toast', src, ('Minimum to launder is $%d'):format(min))
    return
  end
  if amount > maxPer then
    amount = maxPer
  end

  if not it:HasItem(src, Config.Items.dirty, amount) then
    TriggerClientEvent('aln42:bank:toast', src, 'Not enough dirty money.')
    return
  end

  it:TakeItem(src, Config.Items.dirty, amount)
  local clean = math.floor(amount * (Config.Launder.rate or 0.85))
  it:GiveItem(src, Config.Items.cash, clean)

  TriggerClientEvent('aln42:bank:toast', src, ('Laundered $%d → $%d clean'):format(amount, clean))
end)
