fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'ALN42 Banking: ATM card + PIN + bank account + dirty money laundering'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'
