Config = {}

Config.Enabled = true

-- Account floor (loan/debt limit)
Config.MinBankBalance = -50000

-- Session auth after correct PIN (seconds)
Config.PinAuthSeconds = 300

-- Laundering
Config.Launder = {
  rate = 0.85,              -- 85% clean payout
  min = 100,
  maxPerTxn = 20000
}

-- Proximity checks using aln42_locations
Config.Proximity = {
  enabled = true,
  bankRange = 5.0,
  atmRange = 2.5,
  fenceRange = 5.0
}

-- Which location types count as what
Config.Types = {
  banks = { bank = true },
  atms  = { atm = true },
  fences = { fence = true, cashcheck = true }
}

-- Items used by the system
Config.Items = {
  cash = 'cash',
  dirty = 'dirty_money',
  card = 'atm_card'
}
