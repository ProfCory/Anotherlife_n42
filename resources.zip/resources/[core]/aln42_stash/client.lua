local open = false
local stash = {}

local itemsDef = {} -- itemId -> {label, icon, tags, type}

local function notify(msg)
  print(('[ALN42 Stash] %s'):format(msg))
  TriggerEvent('chat:addMessage', { args = { '^3Stash', msg } })
end

RegisterNetEvent('aln42:stash:toast', function(msg) notify(msg) end)

local function loadItemsJson()
  local res = Config.ItemsResource or 'aln42_items'
  local path = Config.ItemsJsonPath or 'data/items.json'
  local raw = LoadResourceFile(res, path)
  if not raw or raw == '' then
    notify(('Could not read %s/%s'):format(res, path))
    return
  end
  local ok, parsed = pcall(json.decode, raw)
  if not ok or type(parsed) ~= 'table' then
    notify('items.json parse failed')
    return
  end
  itemsDef = parsed
end

local function isBlocked(def, itemId)
  itemId = tostring(itemId or ''):lower()
  if itemId:find('weapon') or itemId:find('ammo') then return true end
  if type(def) == 'table' then
    local t = tostring(def.type or ''):lower()
    if t == 'weapon' or t == 'ammo' then return true end
    local tags = def.tags
    if type(tags) == 'table' then
      for _, tg in ipairs(tags) do
        tg = tostring(tg):lower()
        if tg == 'weapon' or tg == 'ammo' then return true end
      end
    end
  end
  return false
end

local function toGridPayload(stashItems)
  local list = {}
  for itemId, qty in pairs(stashItems or {}) do
    local def = itemsDef[itemId] or {}
    if not isBlocked(def, itemId) then
      local icon = def.icon or def.image or def.png
      -- If your items.json stores icon filenames only, put them in items/ and we’ll prefix it:
      if icon and not tostring(icon):find('/') then
        icon = ('items/%s'):format(icon)
      end
      if not icon then icon = Config.IconFallback end

      list[#list+1] = {
        id = itemId,
        qty = tonumber(qty) or 0,
        label = def.label or itemId,
        icon = icon
      }
    end
  end

  table.sort(list, function(a,b) return a.label < b.label end)

  return {
    cols = Config.GridCols or 5,
    rows = Config.GridRows or 4,
    maxSlots = Config.MaxSlots or 20,
	itemsResource = Config.ItemsResource or 'aln42_items',
    items = list
  }
end

RegisterNetEvent('aln42:stash:data', function(items)
  stash = items or {}
  if open then
    SendNUIMessage({ type = 'stash', data = toGridPayload(stash) })
  end
end)

local function setOpen(state)
  open = state

  if open then
    if next(itemsDef) == nil then loadItemsJson() end
    TriggerServerEvent('aln42:stash:get')

    SetNuiFocus(true, true)
    SendNUIMessage({ type = 'open', data = toGridPayload(stash) })
  else
    SetNuiFocus(false, false)
    SendNUIMessage({ type = 'close' })
  end
end

RegisterCommand(Config.OpenCommand, function()
  setOpen(not open)
end, false)

RegisterKeyMapping(Config.OpenCommand, 'Open Stash', 'keyboard', Config.DefaultKey)

RegisterNUICallback('close', function(_, cb)
  setOpen(false)
  cb(true)
end)

RegisterNUICallback('withdraw', function(data, cb)
  local itemId = data and data.id
  if itemId then
    TriggerServerEvent('aln42:stash:withdraw', itemId, 1)
  end
  cb(true)
end)

RegisterNUICallback('deposit', function(data, cb)
  local itemId = data and data.id
  if itemId then
    TriggerServerEvent('aln42:stash:deposit', itemId, 1)
  end
  cb(true)
end)
