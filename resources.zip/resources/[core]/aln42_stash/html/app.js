const wrap = document.getElementById('wrap');
const grid = document.getElementById('grid');

let state = { cols: 5, rows: 4, maxSlots: 20, items: [] };

function post(name, data) {
  fetch(`https://${GetParentResourceName()}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(data || {})
  });
}

function render() {
  grid.style.gridTemplateColumns = `repeat(${state.cols}, 76px)`;
  grid.innerHTML = '';

  // Fill fixed slot count
  const slotCount = state.maxSlots;
  const items = state.items.slice(0);

  for (let i = 0; i < slotCount; i++) {
    const it = items[i];
    const el = document.createElement('div');
    el.className = 'slot' + (it ? '' : ' empty');

    if (it) {
      const img = document.createElement('img');
      img.className = 'icon';
      img.src = `nui://${state.itemsResource || 'aln42_items'}/${it.icon}`;
      el.appendChild(img);

      const qty = document.createElement('div');
      qty.className = 'qty';
      qty.textContent = it.qty;
      el.appendChild(qty);

      const label = document.createElement('div');
      label.className = 'label';
      label.textContent = it.label;
      el.appendChild(label);

      el.addEventListener('click', () => post('withdraw', { id: it.id }));
      el.addEventListener('contextmenu', (e) => { e.preventDefault(); post('deposit', { id: it.id }); });
    }

    grid.appendChild(el);
  }
}

window.addEventListener('message', (e) => {
  const msg = e.data;
  if (!msg || !msg.type) return;

  if (msg.type === 'open') {
    wrap.classList.remove('hidden');
    state = msg.data || state;
    render();
  }
  if (msg.type === 'stash') {
    state = msg.data || state;
    render();
  }
  if (msg.type === 'close') {
    wrap.classList.add('hidden');
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') post('close');
});
