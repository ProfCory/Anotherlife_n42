Config = {}

Config.Enabled = true
Config.MaxSlots = 40     -- simple cap (not weight)
Config.MaxStack = 999

Config.OpenCommand = 'stash'
Config.DefaultKey = 'V'  -- key mapping; user can change in settings
