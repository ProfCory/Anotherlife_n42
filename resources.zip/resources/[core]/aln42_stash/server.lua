local function chars()
  if GetResourceState('aln42_characters') ~= 'started' then return nil end
  return exports['aln42_characters']
end

local function items()
  if GetResourceState('aln42_items') ~= 'started' then return nil end
  return exports['aln42_items']
end

local function getChar(src)
  local ch = chars()
  if not ch then return nil end
  return ch:GetCharacter(src)
end

local function ensureStash(c)
  c.meta = c.meta or {}
  c.meta.stash = c.meta.stash or { items = {} } -- items[itemId]=count
  return c.meta.stash
end

local function countSlots(stash)
  local n = 0
  for _, v in pairs(stash.items or {}) do
    if (tonumber(v) or 0) > 0 then n = n + 1 end
  end
  return n
end

local function toast(src, msg)
  TriggerClientEvent('aln42:stash:toast', src, msg)
end

RegisterNetEvent('aln42:stash:get', function()
  local src = source
  local c = getChar(src); if not c then return end
  local stash = ensureStash(c)
  TriggerClientEvent('aln42:stash:data', src, stash.items or {})
end)

-- Server-side allowlist: only “custom inventory” items, no weapon wheel stuff.
-- If your aln42_items has richer metadata exports later, we can tighten this.
local function isBlockedItem(itemId)
  itemId = tostring(itemId or ''):lower()
  if itemId == '' then return true end
  if itemId:find('weapon') then return true end
  if itemId:find('ammo') then return true end
  return false
end

RegisterNetEvent('aln42:stash:deposit', function(itemId, qty)
  local src = source
  local c = getChar(src); if not c then return end
  local it = items(); if not it then return end

  itemId = tostring(itemId or '')
  qty = math.floor(tonumber(qty) or 0)
  if itemId == '' or qty <= 0 then return end
  if isBlockedItem(itemId) then toast(src, 'That item cannot be stashed.'); return end

  local stash = ensureStash(c)

  if not stash.items[itemId] or stash.items[itemId] <= 0 then
    if countSlots(stash) >= (Config.MaxSlots or 20) then
      toast(src, 'Stash full.')
      return
    end
  end

  if not it:HasItem(src, itemId, qty) then
    toast(src, 'You do not have that.')
    return
  end

  it:TakeItem(src, itemId, qty)
  stash.items[itemId] = math.min((stash.items[itemId] or 0) + qty, Config.MaxStack or 999)
  TriggerClientEvent('aln42:stash:data', src, stash.items)
end)

RegisterNetEvent('aln42:stash:withdraw', function(itemId, qty)
  local src = source
  local c = getChar(src); if not c then return end
  local it = items(); if not it then return end

  itemId = tostring(itemId or '')
  qty = math.floor(tonumber(qty) or 0)
  if itemId == '' or qty <= 0 then return end
  if isBlockedItem(itemId) then toast(src, 'That item cannot be withdrawn.'); return end

  local stash = ensureStash(c)
  local have = tonumber(stash.items[itemId] or 0)
  if have < qty then
    toast(src, 'Not enough in stash.')
    return
  end

  stash.items[itemId] = have - qty
  if stash.items[itemId] <= 0 then stash.items[itemId] = nil end

  it:GiveItem(src, itemId, qty)
  TriggerClientEvent('aln42:stash:data', src, stash.items)
end)
