fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'ALN42 Stash: 20-slot grid, icons, persistent meta stash'

ui_page 'html/index.html'

files {
  'html/index.html',
  'html/style.css',
  'html/app.js'
}

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'
