local locations = {}
local zones = {}
local buyersCfg = {}

local activeBuyer = nil -- spawned “walk-up” buyer
local activeCount = 0
local lastCops = 0

local function readJson(res, path)
  local raw = LoadResourceFile(res, path)
  if not raw or raw == '' then return {} end
  local ok, parsed = pcall(json.decode, raw)
  return (ok and type(parsed) == 'table') and parsed or {}
end

local function notify(msg)
  print(('[ALN42 Drugs] %s'):format(msg))
  TriggerEvent('chat:addMessage', { args = { '^5ALN42-Drugs', msg } })
end

RegisterNetEvent('aln42:drugs:toast', function(msg) notify(msg) end)

RegisterNetEvent('aln42:drugs:sold', function(info)
  if not info then return end
  notify(('Sold %dx %s to %s for %d (%s)')
    :format(info.qty, info.item, info.buyerType, info.payout, info.payItem))

  -- heat
  local wanted = 0
  if info.buyerType == 'dealer' then
    wanted = info.isBrick and (Config.Heat.wantedOnDealerBrick or 2) or (Config.Heat.wantedOnDealerSmall or 1)
  elseif info.buyerType == 'druggie' then
    wanted = Config.Heat.wantedOnDruggie or 1
  else
    wanted = Config.Heat.wantedOnFence or 0
  end

  if wanted > 0 then
    SetPlayerWantedLevel(PlayerId(), wanted, false)
    SetPlayerWantedLevelNow(PlayerId(), false)
    notify(('Heat: wanted level %d for ~%ds'):format(wanted, Config.Heat.wantedDurationSeconds or 90))

    CreateThread(function()
      local untilT = GetGameTimer() + ((Config.Heat.wantedDurationSeconds or 90) * 1000)
      while GetGameTimer() < untilT do Wait(500) end
      ClearPlayerWantedLevel(PlayerId())
    end)
  end
end)

local function dist3(a,b)
  local dx=a.x-b.x; local dy=a.y-b.y; local dz=a.z-b.z
  return math.sqrt(dx*dx+dy*dy+dz*dz)
end

local function inZone(p, z)
  return dist3(p, z.center) <= (z.radius or 200.0)
end

local function hourInWindow(h, startH, endH)
  startH = startH or 0
  endH = endH or 23
  if startH < endH then return h >= startH and h < endH end
  return (h >= startH) or (h < endH)
end

local function nearTypedLocation(p, typeMap, range)
  for i=1,#locations do
    local loc = locations[i]
    if loc and loc.type and typeMap[loc.type] and loc.coords then
      local d = dist3(p, loc.coords)
      if d <= (range or 3.0) then return true, loc end
    end
  end
  return false, nil
end

local function currentDruggieDemandTag()
  local rot = buyersCfg.druggieRotation or {}
  if #rot == 0 then return nil end
  local idx = (GetClockHours() % #rot) + 1
  return rot[idx].drugTag
end

local function playerHasDrugTag(tag)
  if GetResourceState('aln42_items') ~= 'started' then return false end
  local inv = exports['aln42_items']:GetInventory(PlayerId())
  local defs = readJson('aln42_items', 'data/items.json')
  for name, count in pairs(inv or {}) do
    if count and count > 0 then
      local def = defs[name]
      if def and type(def.tags) == 'table' then
        local hasDrug = false
        local hasTag = false
        for _, t in ipairs(def.tags) do
          if t == 'drug' then hasDrug = true end
          if t == tag then hasTag = true end
        end
        if hasDrug and hasTag then return true, name end
      end
    end
  end
  return false
end

-- Simple spawned buyer ped that walks up; you sell via /drug sellbuyer <qty>
local function spawnBuyerNear(p)
  if activeBuyer then return end
  local model = joaat('a_m_m_skater_01')
  RequestModel(model)
  local timeout = GetGameTimer() + 8000
  while not HasModelLoaded(model) do
    Wait(0)
    if GetGameTimer() > timeout then return end
  end

  local x = p.x + math.random(-25,25)
  local y = p.y + math.random(-25,25)
  local z = p.z

  local ped = CreatePed(4, model, x, y, z, 0.0, false, true)
  SetBlockingOfNonTemporaryEvents(ped, true)
  SetEntityAsMissionEntity(ped, true, true)

  TaskGoToEntity(ped, PlayerPedId(), -1, 2.0, 1.0, 1073741824, 0)

  activeBuyer = ped
  activeCount = activeCount + 1

  notify('A buyer is approaching... (use /drug sellbuyer <qty>)')
end

local function despawnBuyer()
  if activeBuyer and DoesEntityExist(activeBuyer) then
    DeleteEntity(activeBuyer)
  end
  activeBuyer = nil
  activeCount = 0
end

RegisterCommand('drug', function(_, args)
  local sub = (args[1] or ''):lower()
  local qty = tonumber(args[3] or args[2] or '0') or 0

  local p = GetEntityCoords(PlayerPedId())
  local p3 = {x=p.x,y=p.y,z=p.z}

  -- determine who you’re selling to based on proximity
  local nearFence, fenceLoc = nearTypedLocation(p3, Config.Buyers.fence.locationTypes, 3.5)
  local nearDealer, dealerLoc = nearTypedLocation(p3, Config.Buyers.dealer.locationTypes, 3.5)
  local nearDruggie, druggieLoc = nearTypedLocation(p3, Config.Buyers.druggie.locationTypes, 3.5)

  if sub == 'sell' then
    local item = args[2]
    if not item or qty <= 0 then
      notify('Usage: /drug sell <itemId> <qty>')
      return
    end

    local buyerType = nearFence and 'fence' or (nearDealer and 'dealer' or (nearDruggie and 'druggie' or nil))
    if not buyerType then
      notify('No fence/dealer/druggie nearby.')
      return
    end

    if buyerType == 'druggie' then
      local demand = currentDruggieDemandTag()
      if not demand then notify('Drug-ies have no demand configured.'); return end
      local ok, matched = playerHasDrugTag(demand)
      if not ok or matched ~= item then
        notify(('Drug-ies currently only want: %s'):format(demand))
        return
      end
    end

    TriggerServerEvent('aln42:drugs:sell', buyerType, item, qty, { loc = (fenceLoc or dealerLoc or druggieLoc) and (fenceLoc or dealerLoc or druggieLoc).id })
    return
  end

  if sub == 'sellbuyer' then
    if not activeBuyer or not DoesEntityExist(activeBuyer) then
      notify('No active street buyer. Walk around in a zone/time window.')
      return
    end
    local d = #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(activeBuyer))
    if d > (Config.Spawn.buyerInteractRange or 3.0) then
      notify('Buyer is not close enough.')
      return
    end

    local demand = currentDruggieDemandTag()
    if not demand then notify('No demand configured.'); return end
    local ok, itemName = playerHasDrugTag(demand)
    if not ok then
      notify(('Buyer wants %s; you do not have any.'):format(demand))
      return
    end

    qty = tonumber(args[2] or '0') or 0
    if qty <= 0 then
      notify('Usage: /drug sellbuyer <qty>')
      return
    end

    -- buyer is treated as “druggie” pricing/rules
    TriggerServerEvent('aln42:drugs:sell', 'druggie', itemName, qty, { zoneBuyer = true })
    despawnBuyer()
    return
  end

  -- info
  notify('Commands:')
  notify('  /drug sell <itemId> <qty>     (near fence/dealer/druggie)')
  notify('  /drug sellbuyer <qty>         (when a zone buyer walks up)')
  notify(('Drug-ies demand rotates hourly: currently %s'):format(tostring(currentDruggieDemandTag())))
end, false)

CreateThread(function()
  if not Config.Enabled then return end
  locations = readJson('aln42_locations', 'data/locations.json')
  zones = readJson(GetCurrentResourceName(), 'data/zones.json')
  buyersCfg = readJson(GetCurrentResourceName(), 'data/buyers.json')

  while true do
    if Config.Spawn.enabled then
      local p = GetEntityCoords(PlayerPedId())
      local p3 = {x=p.x,y=p.y,z=p.z}
      local h = GetClockHours()

      local canSpawn = false
      for i=1,#zones do
        local z = zones[i]
        if z and z.center and inZone(p3, z) and z.hours and hourInWindow(h, z.hours.start, z.hours.end) then
          canSpawn = true
          break
        end
      end

      if canSpawn and (activeCount < (Config.Spawn.maxActiveBuyers or 1)) then
        if math.random() < (Config.Spawn.buyerChancePerTick or 0.18) then
          spawnBuyerNear(p3)
        end
      end
    end

    -- cleanup if buyer wanders off
    if activeBuyer and DoesEntityExist(activeBuyer) then
      local d = #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(activeBuyer))
      if d > (Config.Spawn.buyerApproachRange or 40.0) then
        despawnBuyer()
      end
    end

    Wait(Config.Spawn.tickMs or 2500)
  end
end)
