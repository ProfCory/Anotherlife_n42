fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'ALN42 Drug Sales: fence (bulk) + dealers (risk) + drug-ies (small/high) with area/time spawns'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'

files {
  'data/zones.json',
  'data/buyers.json'
}
