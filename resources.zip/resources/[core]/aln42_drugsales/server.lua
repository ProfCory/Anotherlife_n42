local itemDefs = {}

local function loadItems()
  local raw = LoadResourceFile('aln42_items', 'data/items.json')
  if not raw or raw == '' then itemDefs = {} return end
  local ok, parsed = pcall(json.decode, raw)
  itemDefs = (ok and type(parsed) == 'table') and parsed or {}
end

local function items()
  if GetResourceState('aln42_items') ~= 'started' then return nil end
  return exports['aln42_items']
end

local function hasTag(def, tag)
  if not def or type(def.tags) ~= 'table' then return false end
  for _, t in ipairs(def.tags) do
    if t == tag then return true end
  end
  return false
end

local function isDrugItem(name)
  local d = itemDefs[name]
  return d and hasTag(d, 'drug')
end

local function basePrice(name)
  local d = itemDefs[name]
  return d and tonumber(d.basePrice) or 0
end

RegisterNetEvent('aln42:drugs:sell', function(buyerType, itemName, qty, context)
  local src = source
  local it = items()
  if not it then return end

  qty = tonumber(qty) or 0
  if qty <= 0 then return end
  if not isDrugItem(itemName) then
    TriggerClientEvent('aln42:drugs:toast', src, 'That is not a drug item.')
    return
  end

  if not it:HasItem(src, itemName, qty) then
    TriggerClientEvent('aln42:drugs:toast', src, 'You do not have enough.')
    return
  end

  local def = itemDefs[itemName]
  local price = basePrice(itemName)
  if price <= 0 then
    TriggerClientEvent('aln42:drugs:toast', src, 'No price set for that item.')
    return
  end

  local isBrick = hasTag(def, 'brick')
  local isSmall = hasTag(def, 'small')

  local rules = Config.Buyers[buyerType]
  if not rules then return end

  -- Fence constraints: bulk only
  if buyerType == 'fence' then
    if isSmall and qty < (rules.minQtySmall or 25) then
      TriggerClientEvent('aln42:drugs:toast', src, 'Fence only buys bulk (small items need higher quantity).')
      return
    end
    if isBrick and qty < (rules.minQtyBrick or 2) then
      TriggerClientEvent('aln42:drugs:toast', src, 'Fence only buys bulk (need more bricks).')
      return
    end
  end

  -- Druggie constraints: small only, capped, plus “one drugTag at a time” enforced client-side
  if buyerType == 'druggie' then
    if not isSmall then
      TriggerClientEvent('aln42:drugs:toast', src, 'Drug-ies only buy small amounts.')
      return
    end
    if qty > (rules.maxQtySmall or 5) then
      TriggerClientEvent('aln42:drugs:toast', src, 'Drug-ies won’t buy that much at once.')
      return
    end
  end

  -- Pricing
  local mult = 1.0
  if buyerType == 'dealer' then
    mult = isBrick and (rules.payMultBrick or 0.70) or (rules.payMultSmall or 0.85)
  elseif buyerType == 'druggie' then
    mult = rules.payMultSmall or 1.35
  elseif buyerType == 'fence' then
    mult = rules.payMult or 0.50
  end

  local payout = math.max(1, math.floor(price * qty * mult))

  it:TakeItem(src, itemName, qty)

  local payItem = rules.paysDirty and Config.Items.dirty or Config.Items.cash
  it:GiveItem(src, payItem, payout)

  TriggerClientEvent('aln42:drugs:sold', src, {
    buyerType = buyerType,
    item = itemName,
    qty = qty,
    payout = payout,
    payItem = payItem,
    isBrick = isBrick
  })
end)

AddEventHandler('onResourceStart', function(res)
  if res ~= GetCurrentResourceName() then return end
  loadItems()
end)
