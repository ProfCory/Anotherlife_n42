Config = {}

Config.Enabled = true

Config.Items = {
  cash = 'cash',
  dirty = 'dirty_money'
}

-- Who buys what and how
Config.Buyers = {
  fence = {
    locationTypes = { fence = true, cashcheck = true },
    minQtySmall = 25,            -- fence only buys “large amounts”
    minQtyBrick = 2,
    payMult = 0.50,              -- 50%
    paysDirty = false,
    copsChanceBase = 0.02
  },

  dealer = {
    locationTypes = { dealer = true },
    payMultSmall = 0.85,
    payMultBrick = 0.70,
    paysDirty = false,

    copsChanceSmall = 0.08,
    copsChanceBrick = 0.40       -- bricks = high cops
  },

  drugie = {
    locationTypes = { drugie = true },
    maxQtySmall = 5,             -- “small amounts only”
    paysDirty = false,

    -- “only one kind at a time” comes from buyers.json rotation
    payMultSmall = 1.35,         -- highest price
    copsChanceSmall = 0.12
  }
}

-- Spawn system
Config.Spawn = {
  enabled = true,
  tickMs = 2500,

  buyerChancePerTick = 0.18,     -- chance to spawn an approaching buyer while in zone/time window
  maxActiveBuyers = 1,

  buyerApproachRange = 40.0,
  buyerInteractRange = 3.0,

  copsSpawnOnHeat = true,
  copsVehicleChance = 0.25
}

-- Police heat escalation (simple baseline)
Config.Heat = {
  wantedOnDealerBrick = 2,
  wantedOnDealerSmall = 1,
  wantedOnDruggie = 1,
  wantedOnFence = 0,
  wantedDurationSeconds = 90
}
