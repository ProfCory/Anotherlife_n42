Config = {}

Config.Enabled = true

-- Draw blips for POI locations
Config.Blips = {
  enabled = true,
  defaultScale = 0.85,
  showNamePrefix = false, -- if true: "[Shop] 24/7 Supermarket"
}

-- Draw simple “gang aura” / territory circles (no dependencies)
Config.Zones = {
  enabled = true,
  draw = true,
  drawDistance = 350.0, -- meters
  alpha = 90,           -- 0-255
}

-- Dev helpers
Config.Debug = {
  printLoadedCounts = true
}
