local locations = {}
local zones = {}
local blips = {}

local function readJson(path)
  local raw = LoadResourceFile(GetCurrentResourceName(), path)
  if not raw or raw == '' then return nil end
  local ok, parsed = pcall(json.decode, raw)
  if not ok then return nil end
  return parsed
end

local function makeBlip(loc)
  local c = loc.coords
  local b = loc.blip or {}
  local sprite = b.sprite or 1
  local color = b.color or 0
  local scale = b.scale or Config.Blips.defaultScale or 0.85

  local blip = AddBlipForCoord(c.x + 0.0, c.y + 0.0, c.z + 0.0)
  SetBlipSprite(blip, sprite)
  SetBlipColour(blip, color)
  SetBlipScale(blip, scale)
  SetBlipAsShortRange(blip, true)

  BeginTextCommandSetBlipName('STRING')
  local prefix = Config.Blips.showNamePrefix and ('[' .. tostring(loc.type) .. '] ') or ''
  AddTextComponentString(prefix .. (loc.name or loc.id or 'Location'))
  EndTextCommandSetBlipName(blip)

  return blip
end

local function ensureLoaded()
  locations = readJson('data/locations.json') or {}
  zones = readJson('data/zones.json') or {}

  if Config.Debug.printLoadedCounts then
    print(('[ALN42 Locations] loaded %d locations, %d zones'):format(#locations, #zones))
  end
end

local function clearBlips()
  for _, b in pairs(blips) do
    if DoesBlipExist(b) then RemoveBlip(b) end
  end
  blips = {}
end

local function buildBlips()
  if not (Config.Blips and Config.Blips.enabled) then return end
  clearBlips()

  for i = 1, #locations do
    local loc = locations[i]
    if loc and loc.coords and loc.coords.x and loc.coords.y and loc.coords.z then
      blips[loc.id or tostring(i)] = makeBlip(loc)
    end
  end
end

local function drawZoneCircle(center, radius, alpha)
  -- Simple circle outline using markers
  DrawMarker(
    1,
    center.x, center.y, center.z - 1.0,
    0.0, 0.0, 0.0,
    0.0, 0.0, 0.0,
    radius * 2.0, radius * 2.0, 2.0,
    255, 0, 0, alpha,
    false, false, 2, false, nil, nil, false
  )
end

CreateThread(function()
  if not Config.Enabled then return end

  ensureLoaded()
  buildBlips()

  while true do
    if Config.Zones and Config.Zones.enabled and Config.Zones.draw then
      local ped = PlayerPedId()
      local p = GetEntityCoords(ped)

      for i = 1, #zones do
        local z = zones[i]
        local c = z.center
        local r = z.radius or 200.0

        local dx = p.x - c.x
        local dy = p.y - c.y
        local dist = math.sqrt(dx*dx + dy*dy)

        if dist <= (Config.Zones.drawDistance or 350.0) then
          drawZoneCircle(c, r, Config.Zones.alpha or 90)
        end
      end

      Wait(0)
    else
      Wait(1000)
    end
  end
end)

-- Optional: /reloadlocs to re-read JSON without restart
RegisterCommand('reloadlocs', function()
  ensureLoaded()
  buildBlips()
  print('[ALN42 Locations] reloaded.')
end, false)
