fx_version 'cerulean'
game 'gta5'

description 'ALN42 Locations: map scaffold (blips + zones)'

shared_script 'config.lua'
client_script 'client.lua'

files {
  'data/locations.json',
  'data/zones.json'
}
