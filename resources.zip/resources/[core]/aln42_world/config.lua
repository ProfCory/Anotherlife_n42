Config = {}

-- Master kill switch
Config.Disabled = false

-- -------------------------
-- Weather behavior (canonical)
-- -------------------------
Config.DynamicWeather   = true
Config.StartWeather     = 'RAIN'
Config.NewWeatherTimer  = 10 -- minutes

-- Weighted pool via intentional duplicates
Config.AvailableWeatherTypes = {
  'NEUTRAL',
  'SMOG',
  'FOGGY',
  'OVERCAST',
  'FOGGY',
  'OVERCAST',
  'CLOUDS',
  'CLEARING',
  'RAIN',
  'RAIN',
  'RAIN',
  'RAIN',
  'THUNDER',
  'THUNDER',
  'SNOW',
  'BLIZZARD',
  'SNOWLIGHT',
  'XMAS',
  'HALLOWEEN',
}

-- Optional: extra ambience
Config.Wind = 0.6
Config.RainFx = false

-- -------------------------
-- Time behavior (canonical)
-- -------------------------
Config.BaseTime     = 8
Config.TimeOffset   = 0
Config.FreezeTime   = false
Config.RealTimeSync = false

-- Scale: 1.0 = normal GTA clock speed.
-- Lower feels more “continuous / not arcade-fast”.
Config.TimeScale = 0.6

-- -------------------------
-- World state (canonical)
-- -------------------------
Config.Blackout         = false
Config.BlackoutVehicle  = false

-- -------------------------
-- Density + Chaos (Phase-1)
-- -------------------------
Config.Density = {
  enabled = true,
  parked = 0.35,
  vehicle = 0.65,
  multiplier = 0.85,
  peds = 0.95,
  scenarioPeds = 1.2
}

Config.Dispatch = {
  enabled = true,
  cops = true,
  ems = true,
  fire = true,
  forceCopsOn = true
}

Config.Chaos = {
  enabled = true,
  gangsAtWar = true,
  copsVsGangs = true,
  pedAccuracy = 28,
  pedShootRate = 650,
  combatAbility = 1,
  combatRange = 1,
  keepTasks = true
}
