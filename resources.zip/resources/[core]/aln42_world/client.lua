local function pickWeather()
  local pool = Config.AvailableWeatherTypes or { 'RAIN' }
  return pool[math.random(1, #pool)]
end

local function applyBlackout()
  SetBlackout(Config.Blackout == true)
  -- Vehicle blackout is more of a framework feature; we keep it as a flag for later integration.
end

local function applyWindAndRainFx()
  if Config.Wind ~= nil then SetWind(Config.Wind) end
  if Config.RainFx then SetRainFxIntensity(1.0) end
end

local currentWeather = Config.StartWeather or 'RAIN'
local lastWeatherChange = 0

local function setWeatherNow(w)
  currentWeather = w
  -- Over-time persist helps avoid “hard pops”
  SetWeatherTypeOvertimePersist(currentWeather, 15.0)
  applyWindAndRainFx()
end

local function ensureWeatherLoop()
  if not Config.DynamicWeather then
    if currentWeather ~= (Config.StartWeather or currentWeather) then
      setWeatherNow(Config.StartWeather or currentWeather)
    end
    return
  end

  local now = GetGameTimer()
  local intervalMs = (Config.NewWeatherTimer or 10) * 60 * 1000

  if lastWeatherChange == 0 then
    lastWeatherChange = now
    setWeatherNow(currentWeather)
    return
  end

  if (now - lastWeatherChange) >= intervalMs then
    lastWeatherChange = now
    setWeatherNow(pickWeather())
  end
end

-- Time: continuous, slower feel (TimeScale), not realtime by default
local function applyTime()
  if Config.RealTimeSync then
    -- If you later want real-time sync, we can add actual local time fetch + offset.
    -- For now, keep it simple and deterministic unless you flip this on.
  end

  if Config.FreezeTime then
    PauseClock(true)
  else
    PauseClock(false)
    -- GTA uses SetClockTime each frame to override; we instead adjust the clock rate:
    -- This native controls time progression rate (0.0 stops, 1.0 normal).
    -- Example: 2000 ms per in-game minute = 30 in-game minutes per real hour
SetMillisecondsPerGameMinute(Config.MsPerGameMinute or 2000)
  end

  -- BaseTime + TimeOffset gives you the canonical starting “morning is grey”
  local baseHour = Config.BaseTime or 8
  local offset = Config.TimeOffset or 0
  local hour = (baseHour + offset) % 24

  -- If you don’t want a hard snap at join, you can remove this,
  -- but it helps keep the world consistent in solo.
  NetworkOverrideClockTime(hour, 0, 0)
end

local function applyDensity()
  if not (Config.Density and Config.Density.enabled) then return end
  SetParkedVehicleDensityMultiplierThisFrame(Config.Density.parked or 0.0)
  SetVehicleDensityMultiplierThisFrame(Config.Density.vehicle or 0.0)
  SetRandomVehicleDensityMultiplierThisFrame(Config.Density.multiplier or 0.0)
  SetPedDensityMultiplierThisFrame(Config.Density.peds or 0.0)
  SetScenarioPedDensityMultiplierThisFrame(Config.Density.scenarioPeds or 0.0, Config.Density.scenarioPeds or 0.0)
end

local function applyDispatch()
  if not (Config.Dispatch and Config.Dispatch.enabled) then return end

  for i = 1, 15 do EnableDispatchService(i, true) end

  if not Config.Dispatch.cops then
    for i = 1, 15 do EnableDispatchService(i, false) end
  end

  if not Config.Dispatch.ems then EnableDispatchService(5, false) end
  if not Config.Dispatch.fire then EnableDispatchService(3, false) end

  if Config.Dispatch.forceCopsOn then
    SetCreateRandomCops(true)
    SetCreateRandomCopsNotOnScenarios(true)
    SetCreateRandomCopsOnScenarios(true)
  end
end

local function setRel(a, b, rel)
  SetRelationshipBetweenGroups(rel, a, b)
  SetRelationshipBetweenGroups(rel, b, a)
end

local function applyChaos()
  if not (Config.Chaos and Config.Chaos.enabled) then return end

  local playerGroup = GetHashKey('PLAYER')
  local cops = GetHashKey('COP')

  local gangs = {
    GetHashKey('AMBIENT_GANG_LOST'),
    GetHashKey('AMBIENT_GANG_MEXICAN'),
    GetHashKey('AMBIENT_GANG_FAMILY'),
    GetHashKey('AMBIENT_GANG_BALLAS'),
    GetHashKey('AMBIENT_GANG_MARABUNTE'),
    GetHashKey('AMBIENT_GANG_SALVA'),
    GetHashKey('AMBIENT_GANG_WEICHENG'),
  }

  if Config.Chaos.gangsAtWar then
    for i = 1, #gangs do
      for j = i + 1, #gangs do
        setRel(gangs[i], gangs[j], 5) -- hate
      end
    end
  end

  if Config.Chaos.copsVsGangs then
    for i = 1, #gangs do
      setRel(cops, gangs[i], 5)
    end
  end

  -- Keep player not “instantly hunted” unless you want that.
  setRel(playerGroup, cops, 2)
end

local function tuneNearbyPeds()
  if not (Config.Chaos and Config.Chaos.enabled) then return end

  local me = PlayerPedId()
  local px, py, pz = table.unpack(GetEntityCoords(me))

  local handle, npc = FindFirstPed()
  local ok = true

  while ok do
    if npc ~= me and DoesEntityExist(npc) and not IsPedAPlayer(npc) then
      local x, y, z = table.unpack(GetEntityCoords(npc))
      local dist = #(vector3(px, py, pz) - vector3(x, y, z))
      if dist < 120.0 then
        SetPedAccuracy(npc, Config.Chaos.pedAccuracy or 20)
        SetPedShootRate(npc, Config.Chaos.pedShootRate or 500)
        SetPedCombatAbility(npc, Config.Chaos.combatAbility or 1)
        SetPedCombatRange(npc, Config.Chaos.combatRange or 1)
        SetPedKeepTask(npc, Config.Chaos.keepTasks == true)
      end
    end
    ok, npc = FindNextPed(handle)
  end

  EndFindPed(handle)
end

CreateThread(function()
  if Config.Disabled then return end

  math.randomseed(GetGameTimer())

  applyBlackout()
  applyDispatch()
  applyChaos()

  -- initial weather
  setWeatherNow(currentWeather)

  while true do
    applyDensity()
    ensureWeatherLoop()
    applyTime()
    tuneNearbyPeds()
    Wait(1000)
  end
end)

local function applyDensity()
  if not Config.Density.enabled then return end
  SetParkedVehicleDensityMultiplierThisFrame(Config.Density.parked or 0.0)
  SetVehicleDensityMultiplierThisFrame(Config.Density.vehicle or 0.0)
  SetRandomVehicleDensityMultiplierThisFrame(Config.Density.multiplier or 0.0)
  SetPedDensityMultiplierThisFrame(Config.Density.peds or 0.0)
  SetScenarioPedDensityMultiplierThisFrame(Config.Density.scenarioPeds or 0.0, Config.Density.scenarioPeds or 0.0)
end

local function applyDispatch()
  if not Config.Dispatch.enabled then return end

  -- Enable/disable dispatch services (1..15). We’ll manage the key ones by toggling broad sets.
  -- 1 = police, 2 = police heli, 3 = fire, 5 = ambulance, etc (varies by build).
  -- Safer approach: set them all enabled first, then selectively disable by category.
  for i = 1, 15 do
    EnableDispatchService(i, true)
  end

  if not Config.Dispatch.cops then
    for i = 1, 15 do EnableDispatchService(i, false) end
  end

  if not Config.Dispatch.ems then
    EnableDispatchService(5, false)
  end

  if not Config.Dispatch.fire then
    EnableDispatchService(3, false)
  end

  if Config.Dispatch.forceCopsOn then
    SetCreateRandomCops(true)
    SetCreateRandomCopsNotOnScenarios(true)
    SetCreateRandomCopsOnScenarios(true)
  end
end

local function setRel(a, b, rel)
  SetRelationshipBetweenGroups(rel, a, b)
  SetRelationshipBetweenGroups(rel, b, a)
end

local function applyChaos()
  if not Config.Chaos.enabled then return end

  local playerGroup = GetHashKey('PLAYER')
  local cops = GetHashKey('COP')

  if Config.Chaos.gangsAtWar or Config.Chaos.copsVsGangs then
    -- Common ambient gang groups
    local gangs = {
      GetHashKey('AMBIENT_GANG_LOST'),
      GetHashKey('AMBIENT_GANG_MEXICAN'),
      GetHashKey('AMBIENT_GANG_FAMILY'),
      GetHashKey('AMBIENT_GANG_BALLAS'),
      GetHashKey('AMBIENT_GANG_MARABUNTE'),
      GetHashKey('AMBIENT_GANG_SALVA'),
      GetHashKey('AMBIENT_GANG_WEICHENG'),
    }

    if Config.Chaos.gangsAtWar then
      for i = 1, #gangs do
        for j = i + 1, #gangs do
          setRel(gangs[i], gangs[j], 5) -- 5 = hate
        end
      end
    end

    if Config.Chaos.copsVsGangs then
      for i = 1, #gangs do
        setRel(cops, gangs[i], 5)
      end
    end

    -- Optional: keep player neutral so you’re not instantly hunted 24/7
    setRel(playerGroup, cops, 2) -- 2 = respect / neutral-ish
  end
end

local function tuneNearbyPeds()
  local ped = PlayerPedId()
  local px, py, pz = table.unpack(GetEntityCoords(ped))
  local handle, npc = FindFirstPed()
  local ok = true

  while ok do
    if npc ~= ped and DoesEntityExist(npc) and not IsPedAPlayer(npc) then
      local x, y, z = table.unpack(GetEntityCoords(npc))
      local dist = #(vector3(px, py, pz) - vector3(x, y, z))
      if dist < 120.0 then
        SetPedAccuracy(npc, Config.Chaos.pedAccuracy or 20)
        SetPedShootRate(npc, Config.Chaos.pedShootRate or 500)
        SetPedCombatAbility(npc, Config.Chaos.combatAbility or 1)
        SetPedCombatRange(npc, Config.Chaos.combatRange or 1)
        SetPedKeepTask(npc, Config.Chaos.keepTasks == true)
      end
    end
    ok, npc = FindNextPed(handle)
  end

  EndFindPed(handle)
end

CreateThread(function()
  applyDispatch()
  applyChaos()

  while true do
    -- Apply “every frame” density
    applyDensity()


    if Config.Chaos.enabled then
      tuneNearbyPeds()
    end

    Wait(1000)
  end
end)
