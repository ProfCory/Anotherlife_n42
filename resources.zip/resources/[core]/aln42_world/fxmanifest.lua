fx_version 'cerulean'
game 'gta5'

description 'ALN42 Phase-1 World: weather, density, dispatch, gangs'
client_scripts {
  'config.lua',
  'client.lua'
}
