Config = {}

Config.Enabled = true

-- General
Config.TickMs = 2000
Config.DespawnRange = 220.0
Config.MaxPedsTotal = 18

-- COPS
Config.Cops = {
  enabled = true,

  -- Spawns when wanted >= this
  minWanted = 1,

  -- Cooldowns per wanted level (seconds)
  cooldown = { [1]=55, [2]=45, [3]=35, [4]=30, [5]=25 },

  -- Max active units by wanted
  maxUnits = { [1]=1, [2]=2, [3]=2, [4]=3, [5]=3 },

  -- Unit composition
  unit = {
    vehicleModels = { 'police', 'police2', 'police3' },
    pedModels = { 's_m_y_cop_01', 's_f_y_cop_01' },
    weapons = { 'WEAPON_PISTOL', 'WEAPON_SMG' },
    pedsPerCar = 2
  },

  -- If true, try to spawn a cop car slightly down the road
  spawnDistance = { min = 80.0, max = 140.0 },

  -- Chance to spawn a vehicle unit vs foot unit (0..1)
  vehicleChance = 0.80
}

-- GANGS / CONTRACT CRIMINALS
Config.Gangs = {
  enabled = true,

  -- Gang “patrol” spawns in zones
  zones = {
    {
      id = 'grove_st',
      name = 'Grove St',
      center = { x = 104.2, y = -1937.4, z = 20.8 },
      radius = 260.0,
      hours = { start = 18, ["end"] = 6 }
    },
    {
      id = 'vespucci',
      name = 'Vespucci',
      center = { x = -1160.0, y = -1560.0, z = 4.4 },
      radius = 240.0,
      hours = { start = 20, ["end"] = 5 }
    }
  },

  -- How often to attempt a gang spawn while in zone/time
  chancePerTick = 0.18,

  -- Max active gang groups at once
  maxGroups = 2,

  groups = {
    {
      name = 'GANG_A',
      pedModels = { 'g_m_y_ballasout_01', 'g_m_y_ballaeast_01' },
      vehicleModels = { 'baller', 'granger' },
      weapons = { 'WEAPON_PISTOL', 'WEAPON_MICROSMG' }
    },
    {
      name = 'GANG_B',
      pedModels = { 'g_m_y_mexgoon_02', 'g_m_y_mexgoon_03' },
      vehicleModels = { 'tornado', 'buffalo' },
      weapons = { 'WEAPON_PISTOL', 'WEAPON_SAWNOFFSHOTGUN' }
    }
  },

  pedsPerGroup = 3,
  vehicleChance = 0.55,
  spawnDistance = { min = 70.0, max = 140.0 },

  -- If true, gangs will also sometimes fight each other (not just the player)
  interGangWar = true
}

Config.ContractCriminals = {
  enabled = true,

  -- Spawn chance while roaming (outside safe zones)
  chancePerTick = 0.08,

  -- Extra chance if you’re carrying lots of cash/dirty
  cashThreshold = 2500,
  dirtyThreshold = 2500,
  bonusChance = 0.12,

  -- Cooldown seconds between ambushes
  cooldownSeconds = 120,

  -- NPC setup
  pedModels = { 'g_m_m_armboss_01', 'g_m_m_chiboss_01', 'g_m_y_strpunk_01' },
  weapons = { 'WEAPON_KNIFE', 'WEAPON_PISTOL', 'WEAPON_SMG' },
  pedsPerAmbush = 2,

  spawnDistance = { min = 55.0, max = 110.0 }
}
