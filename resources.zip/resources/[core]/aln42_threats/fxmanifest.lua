fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'ALN42 Threats: physical cops + gangs + contract criminals spawns (frameworkless)'

shared_script 'config.lua'
client_script 'client.lua'
