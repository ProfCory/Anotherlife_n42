local spawned = {
  cops = {},      -- list of {veh=, peds={...}, ts=}
  gangs = {},     -- list of {veh=, peds={...}, groupName=, ts=}
  contracts = {}  -- list of {peds={...}, ts=}
}

local lastCopSpawnAt = { [1]=0,[2]=0,[3]=0,[4]=0,[5]=0 }
local lastContractAt = 0

local REL = {
  PLAYER = nil,
  COPS = nil,
  GANG_A = nil,
  GANG_B = nil,
  CONTRACT = nil
}

local function nowMs() return GetGameTimer() end

local function notify(msg)
  print(('[ALN42 Threats] %s'):format(msg))
end

local function ensureRelGroups()
  REL.PLAYER = GetHashKey('PLAYER')
  AddRelationshipGroup('ALN42_COPS')
  AddRelationshipGroup('ALN42_GANG_A')
  AddRelationshipGroup('ALN42_GANG_B')
  AddRelationshipGroup('ALN42_CONTRACT')

  REL.COPS = GetHashKey('ALN42_COPS')
  REL.GANG_A = GetHashKey('ALN42_GANG_A')
  REL.GANG_B = GetHashKey('ALN42_GANG_B')
  REL.CONTRACT = GetHashKey('ALN42_CONTRACT')

  -- Cops hate player + gangs + contract criminals
  SetRelationshipBetweenGroups(5, REL.COPS, REL.PLAYER)
  SetRelationshipBetweenGroups(5, REL.COPS, REL.GANG_A)
  SetRelationshipBetweenGroups(5, REL.COPS, REL.GANG_B)
  SetRelationshipBetweenGroups(5, REL.COPS, REL.CONTRACT)

  -- Player hates threats (so they engage)
  SetRelationshipBetweenGroups(5, REL.PLAYER, REL.COPS)
  SetRelationshipBetweenGroups(5, REL.PLAYER, REL.GANG_A)
  SetRelationshipBetweenGroups(5, REL.PLAYER, REL.GANG_B)
  SetRelationshipBetweenGroups(5, REL.PLAYER, REL.CONTRACT)

  -- Gangs hate player
  SetRelationshipBetweenGroups(5, REL.GANG_A, REL.PLAYER)
  SetRelationshipBetweenGroups(5, REL.GANG_B, REL.PLAYER)

  -- Gang war (optional)
  if Config.Gangs.interGangWar then
    SetRelationshipBetweenGroups(5, REL.GANG_A, REL.GANG_B)
    SetRelationshipBetweenGroups(5, REL.GANG_B, REL.GANG_A)
  else
    SetRelationshipBetweenGroups(1, REL.GANG_A, REL.GANG_B)
    SetRelationshipBetweenGroups(1, REL.GANG_B, REL.GANG_A)
  end

  -- Contract criminals hate player
  SetRelationshipBetweenGroups(5, REL.CONTRACT, REL.PLAYER)
  SetRelationshipBetweenGroups(5, REL.PLAYER, REL.CONTRACT)
end

local function loadModel(model)
  local hash = type(model) == 'number' and model or joaat(model)
  if not IsModelInCdimage(hash) or not IsModelValid(hash) then return nil end
  RequestModel(hash)
  local deadline = nowMs() + 12000
  while not HasModelLoaded(hash) do
    Wait(0)
    if nowMs() > deadline then return nil end
  end
  return hash
end

local function randFrom(t)
  return t[math.random(1, #t)]
end

local function clamp(x,a,b) if x<a then return a elseif x>b then return b else return x end end

local function dist3(a,b)
  local dx=a.x-b.x; local dy=a.y-b.y; local dz=a.z-b.z
  return math.sqrt(dx*dx+dy*dy+dz*dz)
end

local function hourInWindow(h, startH, endH)
  if startH < endH then return h >= startH and h < endH end
  return (h >= startH) or (h < endH)
end

local function getSpawnPointAroundPlayer(minD, maxD)
  local ped = PlayerPedId()
  local p = GetEntityCoords(ped)
  local heading = GetEntityHeading(ped)
  local angle = heading + math.random(-110,110)
  local d = math.random() * (maxD - minD) + minD
  local rad = math.rad(angle)
  local x = p.x + math.cos(rad) * d
  local y = p.y + math.sin(rad) * d
  local z = p.z

  local ok, outPos = GetNthClosestVehicleNode(x, y, z, 1, 0, 0, 0)
  if ok then
    return outPos
  end
  return vector3(x,y,z)
end

local function pedSetupCombat(ped, relGroup, weapon)
  SetPedRelationshipGroupHash(ped, relGroup)
  SetPedFleeAttributes(ped, 0, false)
  SetPedCombatAttributes(ped, 46, true) -- Always fight
  SetPedCombatAbility(ped, 2)
  SetPedCombatRange(ped, 2)
  SetPedCombatMovement(ped, 2)
  SetPedAccuracy(ped, 28)
  SetPedKeepTask(ped, true)

  if weapon then
    GiveWeaponToPed(ped, joaat(weapon), 150, false, true)
  end
end

local function makePed(modelName, pos, relGroup, weapon)
  local mh = loadModel(modelName)
  if not mh then return nil end
  local ped = CreatePed(4, mh, pos.x, pos.y, pos.z, 0.0, true, true)
  SetModelAsNoLongerNeeded(mh)
  if not DoesEntityExist(ped) then return nil end
  SetEntityAsMissionEntity(ped, true, true)
  SetBlockingOfNonTemporaryEvents(ped, true)
  pedSetupCombat(ped, relGroup, weapon)
  return ped
end

local function makeVehicle(modelName, pos)
  local vh = loadModel(modelName)
  if not vh then return nil end
  local veh = CreateVehicle(vh, pos.x, pos.y, pos.z, 0.0, true, true)
  SetModelAsNoLongerNeeded(vh)
  if not DoesEntityExist(veh) then return nil end
  SetEntityAsMissionEntity(veh, true, true)
  SetVehicleOnGroundProperly(veh)
  return veh
end

local function cleanupList(list)
  local ped = PlayerPedId()
  local p = GetEntityCoords(ped)
  local keep = {}

  for _, u in ipairs(list) do
    local any = false
    if u.veh and DoesEntityExist(u.veh) then
      local vpos = GetEntityCoords(u.veh)
      if dist3({x=p.x,y=p.y,z=p.z},{x=vpos.x,y=vpos.y,z=vpos.z}) <= (Config.DespawnRange or 220.0) then
        any = true
      else
        DeleteEntity(u.veh)
        u.veh = nil
      end
    end
    if u.peds then
      local newP = {}
      for _, pedId in ipairs(u.peds) do
        if pedId and DoesEntityExist(pedId) then
          local ppos = GetEntityCoords(pedId)
          if dist3({x=p.x,y=p.y,z=p.z},{x=ppos.x,y=ppos.y,z=ppos.z}) <= (Config.DespawnRange or 220.0) then
            table.insert(newP, pedId)
            any = true
          else
            DeleteEntity(pedId)
          end
        end
      end
      u.peds = newP
    end

    if any then table.insert(keep, u) end
  end
  return keep
end

local function totalPeds()
  local n = 0
  local function count(list)
    for _, u in ipairs(list) do
      n = n + (u.peds and #u.peds or 0)
    end
  end
  count(spawned.cops)
  count(spawned.gangs)
  count(spawned.contracts)
  return n
end

-- COPS
local function spawnCopUnit(wanted)
  local maxUnits = (Config.Cops.maxUnits and Config.Cops.maxUnits[wanted]) or 1
  if #spawned.cops >= maxUnits then return end
  if totalPeds() >= (Config.MaxPedsTotal or 18) then return end

  local pos = getSpawnPointAroundPlayer(Config.Cops.spawnDistance.min, Config.Cops.spawnDistance.max)
  local useVehicle = (math.random() < (Config.Cops.vehicleChance or 0.8))

  local unit = { veh=nil, peds={}, ts=nowMs() }

  if useVehicle then
    local vehModel = randFrom(Config.Cops.unit.vehicleModels)
    unit.veh = makeVehicle(vehModel, pos)
    if not unit.veh then return end
  end

  for i=1,(Config.Cops.unit.pedsPerCar or 2) do
    local m = randFrom(Config.Cops.unit.pedModels)
    local w = randFrom(Config.Cops.unit.weapons)
    local pedId = makePed(m, pos, REL.COPS, w)
    if pedId then
      table.insert(unit.peds, pedId)
      if unit.veh and DoesEntityExist(unit.veh) then
        TaskWarpPedIntoVehicle(pedId, unit.veh, i==1 and -1 or (i-2))
      end
      TaskCombatPed(pedId, PlayerPedId(), 0, 16)
    end
  end

  table.insert(spawned.cops, unit)
end

-- GANGS
local function playerInGangZone()
  local ped = PlayerPedId()
  local p = GetEntityCoords(ped)
  local h = GetClockHours()

  for _, z in ipairs(Config.Gangs.zones or {}) do
    if z.center and z.radius and z.hours then
      local d = dist3({x=p.x,y=p.y,z=p.z}, z.center)
      if d <= z.radius and hourInWindow(h, z.hours.start, z.hours.end) then
        return true, z
      end
    end
  end
  return false, nil
end

local function spawnGangGroup()
  if #spawned.gangs >= (Config.Gangs.maxGroups or 2) then return end
  if totalPeds() >= (Config.MaxPedsTotal or 18) then return end

  local inZone = playerInGangZone()
  if not inZone then return end
  if math.random() >= (Config.Gangs.chancePerTick or 0.18) then return end

  local gang = randFrom(Config.Gangs.groups)
  local rel = (gang.name == 'GANG_A') and REL.GANG_A or REL.GANG_B

  local pos = getSpawnPointAroundPlayer(Config.Gangs.spawnDistance.min, Config.Gangs.spawnDistance.max)
  local useVehicle = (math.random() < (Config.Gangs.vehicleChance or 0.55))

  local grp = { veh=nil, peds={}, groupName=gang.name, ts=nowMs() }

  if useVehicle then
    local vehModel = randFrom(gang.vehicleModels)
    grp.veh = makeVehicle(vehModel, pos)
  end

  for i=1,(Config.Gangs.pedsPerGroup or 3) do
    local m = randFrom(gang.pedModels)
    local w = randFrom(gang.weapons)
    local pedId = makePed(m, pos, rel, w)
    if pedId then
      table.insert(grp.peds, pedId)
      if grp.veh and DoesEntityExist(grp.veh) then
        TaskWarpPedIntoVehicle(pedId, grp.veh, i==1 and -1 or (i-2))
      end

      -- Either go after player or roam; roaming still causes fights via relationship groups
      if math.random() < 0.55 then
        TaskCombatPed(pedId, PlayerPedId(), 0, 16)
      else
        TaskWanderInArea(pedId, pos.x, pos.y, pos.z, 65.0, 4.0, 8.0)
      end
    end
  end

  table.insert(spawned.gangs, grp)
end

-- CONTRACT CRIMINALS (ambush/mugger squads)
local function getCashCounts()
  if GetResourceState('aln42_items') ~= 'started' then return 0,0 end
  local inv = exports['aln42_items']:GetInventory(PlayerId())
  local cash = tonumber(inv and inv['cash']) or 0
  local dirty = tonumber(inv and inv['dirty_money']) or 0
  return cash, dirty
end

local function spawnContractAmbush()
  if not Config.ContractCriminals.enabled then return end
  if totalPeds() >= (Config.MaxPedsTotal or 18) then return end
  if (nowMs() - lastContractAt) < ((Config.ContractCriminals.cooldownSeconds or 120) * 1000) then return end

  local baseChance = Config.ContractCriminals.chancePerTick or 0.08
  local cash, dirty = getCashCounts()
  local bonus = 0.0
  if cash >= (Config.ContractCriminals.cashThreshold or 2500) or dirty >= (Config.ContractCriminals.dirtyThreshold or 2500) then
    bonus = Config.ContractCriminals.bonusChance or 0.12
  end

  if math.random() >= clamp(baseChance + bonus, 0.0, 0.9) then return end

  local pos = getSpawnPointAroundPlayer(Config.ContractCriminals.spawnDistance.min, Config.ContractCriminals.spawnDistance.max)
  local grp = { peds={}, ts=nowMs() }

  for i=1,(Config.ContractCriminals.pedsPerAmbush or 2) do
    local m = randFrom(Config.ContractCriminals.pedModels)
    local w = randFrom(Config.ContractCriminals.weapons)
    local pedId = makePed(m, pos, REL.CONTRACT, w)
    if pedId then
      table.insert(grp.peds, pedId)
      TaskCombatPed(pedId, PlayerPedId(), 0, 16)
    end
  end

  if #grp.peds > 0 then
    table.insert(spawned.contracts, grp)
    lastContractAt = nowMs()
  end
end

CreateThread(function()
  if not Config.Enabled then return end
  math.randomseed(GetGameTimer())
  ensureRelGroups()

  while true do
    spawned.cops = cleanupList(spawned.cops)
    spawned.gangs = cleanupList(spawned.gangs)
    spawned.contracts = cleanupList(spawned.contracts)

    local wanted = GetPlayerWantedLevel(PlayerId())

    -- Cops spawn based on wanted
    if Config.Cops.enabled and wanted >= (Config.Cops.minWanted or 1) then
      local cd = ((Config.Cops.cooldown and Config.Cops.cooldown[wanted]) or 50) * 1000
      if (nowMs() - (lastCopSpawnAt[wanted] or 0)) >= cd then
        spawnCopUnit(wanted)
        lastCopSpawnAt[wanted] = nowMs()
      end
    end

    -- Gang presence + wars (zone/time)
    if Config.Gangs.enabled then
      spawnGangGroup()
    end

    -- Contract criminals (ambush squads)
    spawnContractAmbush()

    Wait(Config.TickMs or 2000)
  end
end)
