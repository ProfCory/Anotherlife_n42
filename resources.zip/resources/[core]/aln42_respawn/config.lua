Config = {}

-- Delay after death before respawn (ms)
Config.RespawnDelay = 3500

-- If true: use "nearest station" logic
Config.UseNearest = true

-- When true: save last position periodically (for later use with characters)
Config.TrackLastLocation = true
Config.TrackIntervalMs = 8000

-- Routing lists (add/remove as you like)
Config.Hospitals = {
  { x =  298.23,  y = -584.51, z = 43.26, h = 70.0 },   -- Pillbox Hill
  { x = 1839.55,  y = 3672.23, z = 34.28, h = 210.0 }, -- Sandy Shores Medical
  { x = -247.76,  y = 6331.23, z = 32.43, h = 225.0 }, -- Paleto
}

Config.PoliceStations = {
  { x =  425.13,  y = -979.56, z = 30.71, h = 90.0 },  -- Mission Row
  { x = 1853.27,  y = 3686.63, z = 34.27, h = 120.0 }, -- Sandy Shores
  { x = -446.21,  y = 6012.52, z = 31.72, h = 315.0 }, -- Paleto
}

Config.FireStations = {
  { x =  215.70,  y = -1642.00, z = 29.71, h = 50.0 }, -- Davis
  { x = 1200.42,  y = -1463.36, z = 34.86, h = 0.0 },  -- El Burro
  { x = -379.90,  y = 6118.55, z = 31.85, h = 45.0 },  -- Paleto
}
