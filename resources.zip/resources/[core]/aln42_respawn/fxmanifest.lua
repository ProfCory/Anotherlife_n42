fx_version 'cerulean'
game 'gta5'

description 'ALN42 Respawn Routing: hospital/fire/police'
client_scripts {
  'config.lua',
  'client.lua'
}
