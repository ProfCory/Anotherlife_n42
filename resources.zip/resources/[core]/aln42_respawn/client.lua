local function dist2(a, b)
  local dx = a.x - b.x
  local dy = a.y - b.y
  local dz = a.z - b.z
  return dx*dx + dy*dy + dz*dz
end

local function nearest(list, pos)
  local best, bestD = list[1], math.huge
  for i = 1, #list do
    local d = dist2(list[i], pos)
    if d < bestD then
      bestD = d
      best = list[i]
    end
  end
  return best
end

local function isFireDeath(ped)
  if IsEntityOnFire(ped) then return true end
  local cause = GetPedCauseOfDeath(ped)
  -- Common fire-related weapon hashes
  if cause == joaat('WEAPON_MOLOTOV') then return true end
  if cause == joaat('WEAPON_PETROLCAN') then return true end
  if cause == joaat('WEAPON_FIRE') then return true end
  return false
end

local function isCopRelated(ped)
  -- Frameworkless “arrested” doesn’t exist; this is a best-effort heuristic:
  -- if you died while wanted, or killed by a cop ped.
  local wanted = GetPlayerWantedLevel(PlayerId())
  if wanted and wanted > 0 then return true end

  local killer = GetPedSourceOfDeath(ped)
  if killer ~= 0 and DoesEntityExist(killer) and IsPedAPlayer(killer) == false then
    if IsPedInAnyPoliceVehicle(killer) then return true end
    if GetPedRelationshipGroupHash(killer) == GetHashKey('COP') then return true end
  end

  return false
end

local function doRespawnAt(spawn)
  local ped = PlayerPedId()

  DoScreenFadeOut(250)
  while not IsScreenFadedOut() do Wait(0) end

  NetworkResurrectLocalPlayer(spawn.x, spawn.y, spawn.z, spawn.h or 0.0, true, false)
  ClearPedTasksImmediately(ped)
  ClearPlayerWantedLevel(PlayerId())

  SetEntityCoordsNoOffset(PlayerPedId(), spawn.x, spawn.y, spawn.z, false, false, false)
  SetEntityHeading(PlayerPedId(), spawn.h or 0.0)

  DoScreenFadeIn(500)
end

-- Optional: last location tracking for later character persistence
local function kvpKey()
  return 'aln42:lastpos'
end

local function saveLastPos()
  local ped = PlayerPedId()
  if not ped or ped == -1 then return end
  local c = GetEntityCoords(ped)
  local h = GetEntityHeading(ped)
  local s = ('%.3f,%.3f,%.3f,%.3f'):format(c.x, c.y, c.z, h)
  SetResourceKvp(kvpKey(), s)
end

CreateThread(function()
  if Config.TrackLastLocation then
    while true do
      saveLastPos()
      Wait(Config.TrackIntervalMs or 8000)
    end
  end
end)

-- Main death watcher
CreateThread(function()
  while true do
    Wait(250)

    local ped = PlayerPedId()
    if ped ~= 0 and IsEntityDead(ped) then
      local pos = GetEntityCoords(ped)

      Wait(Config.RespawnDelay or 3500)

      local spawn

      if isFireDeath(ped) then
        spawn = Config.UseNearest and nearest(Config.FireStations, pos) or Config.FireStations[1]
      elseif isCopRelated(ped) then
        spawn = Config.UseNearest and nearest(Config.PoliceStations, pos) or Config.PoliceStations[1]
      else
        spawn = Config.UseNearest and nearest(Config.Hospitals, pos) or Config.Hospitals[1]
      end

      doRespawnAt(spawn)
      Wait(2000) -- prevent double-trigger
    end
  end
end)
