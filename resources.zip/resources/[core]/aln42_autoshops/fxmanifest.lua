fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'ALN42 Auto Shops: repair/repaint/mods + title/keys + persistent owned vehicles'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'

files { 'data/mods.json' }
