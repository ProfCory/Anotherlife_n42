local function chars()
  if GetResourceState('aln42_characters') ~= 'started' then return nil end
  return exports['aln42_characters']
end

local function items()
  if GetResourceState('aln42_items') ~= 'started' then return nil end
  return exports['aln42_items']
end

local function getChar(src)
  local ch = chars()
  if not ch then return nil end
  return ch:GetCharacter(src)
end

local function ensureGarageMeta(c)
  c.meta = c.meta or {}
  c.meta.vehicles = c.meta.vehicles or {
    owned = {},    -- [plate] = { model=, props=, mods=, created=, last= }
    keys = {}      -- [plate]=true
  }
  return c.meta.vehicles
end

local function pay(src, amount)
  amount = math.floor(tonumber(amount) or 0)
  if amount <= 0 then return true end
  local it = items()
  if not it then return false, 'items not running' end
  if not it:HasItem(src, Config.CashItem, amount) then
    return false, 'Not enough cash.'
  end
  it:TakeItem(src, Config.CashItem, amount)
  return true
end

RegisterNetEvent('aln42:auto:buyTitle', function(payload)
  local src = source
  local c = getChar(src)
  if not c then return end
  local m = ensureGarageMeta(c)

  if type(payload) ~= 'table' then return end
  local plate = tostring(payload.plate or ''):gsub('%s+','')
  if plate == '' then return end

  local heat = tonumber(payload.heat) or 0.0
  if heat > (Config.Hot.maxHeatToTitle or 15.0) then
    TriggerClientEvent('aln42:auto:toast', src, 'Too hot to title. Cool it down or clean it first.')
    return
  end

  local ok, err = pay(src, Config.Prices.title or 900)
  if not ok then
    TriggerClientEvent('aln42:auto:toast', src, err or 'Payment failed.')
    return
  end

  -- claim ownership
  m.owned[plate] = m.owned[plate] or {
    model = payload.model,
    props = payload.props or {},
    mods = payload.mods or {},
    created = os.time(),
    last = os.time()
  }

  -- keys granted automatically on title
  m.keys[plate] = true

  -- optional flavor tokens
  local it = items()
  if it then
    it:GiveItem(src, 'vehicle_title', 1)
    it:GiveItem(src, 'vehicle_key', 1)
  end

  TriggerClientEvent('aln42:auto:titled', src, plate, Config.Hot.clearHeatOnTitle == true)
end)

RegisterNetEvent('aln42:auto:buyKey', function(plate)
  local src = source
  local c = getChar(src)
  if not c then return end
  local m = ensureGarageMeta(c)

  plate = tostring(plate or ''):gsub('%s+','')
  if plate == '' then return end
  if not m.owned[plate] then
    TriggerClientEvent('aln42:auto:toast', src, 'You do not own this vehicle.')
    return
  end

  local ok, err = pay(src, Config.Prices.key or 50)
  if not ok then
    TriggerClientEvent('aln42:auto:toast', src, err or 'Payment failed.')
    return
  end

  m.keys[plate] = true
  local it = items()
  if it then it:GiveItem(src, 'vehicle_key', 1) end
  TriggerClientEvent('aln42:auto:toast', src, 'Key issued.')
end)

RegisterNetEvent('aln42:auto:saveOwnedProps', function(plate, data)
  local src = source
  local c = getChar(src)
  if not c then return end
  local m = ensureGarageMeta(c)

  plate = tostring(plate or ''):gsub('%s+','')
  if plate == '' then return end
  if not m.owned[plate] then return end
  if type(data) ~= 'table' then return end

  m.owned[plate].props = data.props or m.owned[plate].props
  m.owned[plate].mods = data.mods or m.owned[plate].mods
  m.owned[plate].last = os.time()
end)

RegisterNetEvent('aln42:auto:buyMod', function(plate, modType, modId, modsState, price)
  local src = source
  local c = getChar(src)
  if not c then return end
  local m = ensureGarageMeta(c)

  plate = tostring(plate or ''):gsub('%s+','')
  if plate == '' then return end
  if not m.owned[plate] then
    TriggerClientEvent('aln42:auto:toast', src, 'Title the vehicle first.')
    return
  end

  price = math.floor(tonumber(price) or 0)
  if price <= 0 then return end

  local ok, err = pay(src, price)
  if not ok then
    TriggerClientEvent('aln42:auto:toast', src, err or 'Payment failed.')
    return
  end

  m.owned[plate].mods = modsState or m.owned[plate].mods
  m.owned[plate].last = os.time()
  TriggerClientEvent('aln42:auto:toast', src, ('Installed: %s'):format(modId))
end)

RegisterNetEvent('aln42:auto:getOwnedList', function()
  local src = source
  local c = getChar(src)
  if not c then return end
  local m = ensureGarageMeta(c)
  TriggerClientEvent('aln42:auto:ownedList', src, m.owned or {}, m.keys or {})
end)
