Config = {}

Config.Enabled = true

Config.LocationType = 'autoshop'
Config.Range = 6.0

Config.CashItem = 'cash'
Config.ToolboxItem = 'toolbox'

-- Prices (2025-ish baseline; tune later)
Config.Prices = {
  repairBase = 350,
  repaint = 250,
  title = 900,          -- paperwork to claim a vehicle as yours
  key = 50,             -- duplicate key fee
  storeFee = 0,
  spawnFee = 0
}

-- Title cannot be purchased if the car is “hot”
Config.Hot = {
  maxHeatToTitle = 15.0,      -- if heat > this, no title
  clearHeatOnTitle = true
}

-- Dice repair option
Config.DiceRepair = {
  enabled = true,
  dc = 12,
  mode = 'normal',
  activity = 'veh_repair',
  onSuccessEngine = 350.0,
  onSuccessBody = 300.0
}
