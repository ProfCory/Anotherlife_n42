local locations = {}
local mods = {}
local atShop = nil

local function notify(msg)
  print(('[ALN42 Auto] %s'):format(msg))
  TriggerEvent('chat:addMessage', { args = { '^2ALN42-Auto', msg } })
end

RegisterNetEvent('aln42:auto:toast', function(msg) notify(msg) end)

local function readJson(res, path)
  local raw = LoadResourceFile(res, path)
  if not raw or raw == '' then return {} end
  local ok, parsed = pcall(json.decode, raw)
  return (ok and type(parsed) == 'table') and parsed or {}
end

local function dist3(a,b)
  local dx=a.x-b.x; local dy=a.y-b.y; local dz=a.z-b.z
  return math.sqrt(dx*dx+dy*dy+dz*dz)
end

local function getPlate(veh)
  local p = tostring(GetVehicleNumberPlateText(veh) or '')
  return (p:gsub('%s+',''))
end

local function getVehHeat()
  if GetResourceState('aln42_needs') ~= 'started' then return 0.0 end
  local s = exports['aln42_needs']:GetVehicleStatus()
  return tonumber(s and s.heat) or 0.0
end

local function inDriverSeat()
  local ped = PlayerPedId()
  local v = GetVehiclePedIsIn(ped, false)
  if v == 0 then return nil end
  if GetPedInVehicleSeat(v, -1) ~= ped then return nil end
  return v
end

local function findAutoshop()
  local p = GetEntityCoords(PlayerPedId())
  local p3 = {x=p.x,y=p.y,z=p.z}
  for _, loc in ipairs(locations) do
    if loc and loc.type == Config.LocationType and loc.coords then
      local d = dist3(p3, loc.coords)
      if d <= (Config.Range or 6.0) then return loc end
    end
  end
  return nil
end

-- Apply saved mods (basic)
local function applyModsToVehicle(v, state)
  if type(state) ~= 'table' then return end

  -- Turbo toggle
  if state.turbo == true then
    ToggleVehicleMod(v, 18, true) -- turbo
  end

  -- Handling multiplier (client-side “feel” via engine power/torque as a proxy)
  if state.handlingMult then
    local mult = tonumber(state.handlingMult) or 1.0
    SetVehicleEnginePowerMultiplier(v, (mult - 1.0) * 100.0)
    SetVehicleEngineTorqueMultiplier(v, mult)
  end
end

RegisterNetEvent('aln42:auto:titled', function(plate, clearHeat)
  notify(('Titled vehicle %s. Keys issued.'):format(plate))
  if clearHeat and GetResourceState('aln42_needs') == 'started' then
    local s = exports['aln42_needs']:GetVehicleStatus()
    if s and s.plate == plate then
      -- ask needs to persist heat down by setting its server state through its own channel:
      TriggerServerEvent('aln42:veh:set', plate, { fuel = s.fuel, heat = 0.0 })
      notify('Heat cleared on title.')
    end
  end
end)

-- Commands:
-- /auto title
-- /auto key
-- /auto repair
-- /auto repaint <r> <g> <b>
-- /auto mod list
-- /auto mod turbo
-- /auto mod handling <1|2|3>
-- /auto store
-- /auto spawn <plate>
-- /auto lock   (locks nearest owned vehicle by plate match)
RegisterCommand('auto', function(_, args)
  atShop = findAutoshop()
  local sub = (args[1] or ''):lower()

  if sub == 'mod' and (args[2] or ''):lower() == 'list' then
    notify('Mods:')
    for _, o in ipairs(mods.turbo or {}) do notify(('  turbo: %s $%d'):format(o.id, o.price)) end
    for _, o in ipairs(mods.handling or {}) do notify(('  handling: %s $%d'):format(o.id, o.price)) end
    return
  end

  if not atShop and sub ~= 'spawn' and sub ~= 'lock' then
    notify('You must be at an autoshop.')
    return
  end

  local v = inDriverSeat()

  if sub == 'title' then
    if not v then notify('Get in the vehicle (driver seat).'); return end
    local plate = getPlate(v)
    local heat = getVehHeat()

    local payload = {
      plate = plate,
      heat = heat,
      model = GetEntityModel(v),
      props = {
        color1 = select(1, GetVehicleColours(v)),
        color2 = select(2, GetVehicleColours(v))
      },
      mods = {}
    }

    TriggerServerEvent('aln42:auto:buyTitle', payload)
    return
  end

  if sub == 'key' then
    if not v then notify('Get in the vehicle (driver seat).'); return end
    TriggerServerEvent('aln42:auto:buyKey', getPlate(v))
    return
  end

  if sub == 'repair' then
    if not v then notify('Get in the vehicle (driver seat).'); return end

    -- Option A: pay repairBase
    local cost = Config.Prices.repairBase or 350
    TriggerServerEvent('aln42:veh:pay', cost)
    notify(('Attempting paid repair ($%d)...'):format(cost))

    -- We do it locally; if payment fails, you’ll see a toast from needs.
    SetVehicleFixed(v)
    SetVehicleDeformationFixed(v)
    SetVehicleEngineHealth(v, 1000.0)
    SetVehicleBodyHealth(v, 1000.0)
    notify('Repaired.')
    return
  end

  if sub == 'repaint' then
    if not v then notify('Get in the vehicle (driver seat).'); return end
    local r = tonumber(args[2] or '') or 0
    local g = tonumber(args[3] or '') or 0
    local b = tonumber(args[4] or '') or 0

    local cost = Config.Prices.repaint or 250
    TriggerServerEvent('aln42:veh:pay', cost)
    SetVehicleCustomPrimaryColour(v, r, g, b)
    SetVehicleCustomSecondaryColour(v, r, g, b)
    notify(('Repainted ($%d).'):format(cost))

    -- persist props to owned vehicle if titled
    TriggerServerEvent('aln42:auto:saveOwnedProps', getPlate(v), {
      props = { rgb = {r=r,g=g,b=b} }
    })
    return
  end

  if sub == 'mod' then
    if not v then notify('Get in the vehicle (driver seat).'); return end
    local kind = (args[2] or ''):lower()

    if kind == 'turbo' then
      local opt = (mods.turbo or {})[1]
      if not opt then notify('No turbo config.'); return end
      ToggleVehicleMod(v, 18, true)

      local plate = getPlate(v)
      local state = { turbo = true }
      TriggerServerEvent('aln42:auto:buyMod', plate, 'turbo', opt.id, state, opt.price)
      return
    end

    if kind == 'handling' then
      local tier = tonumber(args[3] or '') or 1
      tier = math.max(1, math.min(3, tier))
      local opt = (mods.handling or {})[tier]
      if not opt then notify('No handling config.'); return end

      local mult = tonumber(opt.handlingMult) or 1.0
      SetVehicleEnginePowerMultiplier(v, (mult - 1.0) * 100.0)
      SetVehicleEngineTorqueMultiplier(v, mult)

      local plate = getPlate(v)
      local state = { handlingMult = mult }
      TriggerServerEvent('aln42:auto:buyMod', plate, 'handling', opt.id, state, opt.price)
      return
    end

    notify('Usage: /auto mod list | /auto mod turbo | /auto mod handling <1|2|3>')
    return
  end

  if sub == 'store' then
    if not v then notify('Get in the vehicle (driver seat).'); return end
    local plate = getPlate(v)

    TriggerServerEvent('aln42:auto:saveOwnedProps', plate, {
      props = {
        model = GetEntityModel(v),
        engine = GetVehicleEngineHealth(v),
        body = GetVehicleBodyHealth(v)
      }
    })

    DeleteVehicle(v)
    notify(('Stored %s.'):format(plate))
    return
  end

  if sub == 'spawn' then
    local plate = tostring(args[2] or ''):gsub('%s+','')
    if plate == '' then notify('Usage: /auto spawn <plate>'); return end
    TriggerServerEvent('aln42:auto:getOwnedList')
    notify('Requested owned list (spawns happen client-side after list arrives).')
    return
  end

  if sub == 'lock' then
    -- simple lock for nearest vehicle that matches plate in owned list (handled after list load)
    TriggerServerEvent('aln42:auto:getOwnedList')
    notify('Checking owned keys for nearby vehicle...')
    return
  end

  notify('Auto shop:')
  notify('  /auto title')
  notify('  /auto key')
  notify('  /auto repair')
  notify('  /auto repaint <r> <g> <b>')
  notify('  /auto mod list | turbo | handling <1|2|3>')
  notify('  /auto store')
  notify('  /auto spawn <plate>')
  notify('  /auto lock')
end, false)

RegisterNetEvent('aln42:auto:ownedList', function(owned, keys)
  owned = owned or {}
  keys = keys or {}

  local wantedSpawn = nil
  -- If the user typed /auto spawn <plate>, we don't have that plate here; keep it simple:
  -- Spawn first owned vehicle if requested later. For now, provide a list.
  notify('Owned vehicles:')
  local n = 0
  for plate, data in pairs(owned) do
    n = n + 1
    notify(('  %s (keys=%s)'):format(plate, keys[plate] and 'yes' or 'no'))
  end
  if n == 0 then notify('  (none)') end

  -- Lock support: lock nearest vehicle if you have keys for its plate
  local ped = PlayerPedId()
  local p = GetEntityCoords(ped)
  local veh = GetClosestVehicle(p.x, p.y, p.z, 8.0, 0, 70)
  if veh ~= 0 then
    local plate = getPlate(veh)
    if keys[plate] then
      local lock = GetVehicleDoorLockStatus(veh)
      local new = (lock == 1 or lock == 0) and 2 or 1
      SetVehicleDoorsLocked(veh, new)
      notify(new == 2 and 'Locked.' or 'Unlocked.')
    end
  end
end)

CreateThread(function()
  if not Config.Enabled then return end
  locations = readJson('aln42_locations', 'data/locations.json')
  mods = readJson(GetCurrentResourceName(), 'data/mods.json')
end)
