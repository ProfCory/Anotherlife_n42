Config = {}

Config.Enabled = true

-- Preferred model: csb_undercover
-- Fallback model: u_m_y_paparazzi
Config.Model = 'csb_undercover'
Config.FallbackModel = 'u_m_y_paparazzi'

-- Put this at the spot you first spawn at the airport.
-- Adjust x/y/z/heading to your actual “upper airport” spawn.
Config.Spawn = {
  x = -1037.6, y = -2737.6, z = 20.2, heading = 330.0
}

Config.Interact = {
  key = 38,      -- E
  range = 2.5
}

-- Starter kit (items)
Config.Starter = {
  cash = 50,
  dirty = 100,
  fakeIds = 1,

  burnerPhoneItem = 'nokia', -- change to your real burner phone item id if different
  burnerPhoneQty = 1
}

-- Licenses set on the character meta
Config.Licenses = {
  driver = true,
  weapon_ccw = true
}

-- If true: tries to call a character appearance editor hook (best-effort)
Config.TryOpenAppearance = true
