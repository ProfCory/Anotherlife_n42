local introPed = nil
local busy = false
local pending = false

local function notify(msg)
  print(('[ALN42 Intro] %s'):format(msg))
  TriggerEvent('chat:addMessage', { args = { '^3ALN42-Intro', msg } })
end

RegisterNetEvent('aln42:intro:toast', function(msg) notify(msg) end)

RegisterNetEvent('aln42:intro:granted', function(info)
  notify(('Issued ID + licenses. Given: $%d cash, $%d dirty, %d fake_id.')
    :format(info.cash or 0, info.dirty or 0, info.fakeIds or 0))
  notify('Fake IDs are “one extra death” each. Buy more from his friends.')
end)

local function loadModel(name)
  local h = joaat(name)
  if not IsModelInCdimage(h) or not IsModelValid(h) then return nil end
  RequestModel(h)
  local deadline = GetGameTimer() + 12000
  while not HasModelLoaded(h) do
    Wait(0)
    if GetGameTimer() > deadline then return nil end
  end
  return h
end

local function spawnIntroPed()
  if introPed and DoesEntityExist(introPed) then return end
  local model = loadModel(Config.Model) or loadModel(Config.FallbackModel)
  if not model then notify('Could not load intro NPC model.'); return end

  local x,y,z,h = Config.Spawn.x, Config.Spawn.y, Config.Spawn.z, Config.Spawn.heading
  introPed = CreatePed(4, model, x, y, z, h, false, true)
  SetModelAsNoLongerNeeded(model)

  SetEntityAsMissionEntity(introPed, true, true)
  SetBlockingOfNonTemporaryEvents(introPed, true)
  FreezeEntityPosition(introPed, true)
  SetEntityInvincible(introPed, true)
  TaskStartScenarioInPlace(introPed, 'WORLD_HUMAN_PAPARAZZI', 0, true)
end

local function showHelp(text)
  BeginTextCommandDisplayHelp('STRING')
  AddTextComponentString(text)
  EndTextCommandDisplayHelp(0, false, false, 1)
end

local function playSnap()
  StartScreenEffect('SwitchHUDIn', 200, false)
  PlaySoundFrontend(-1, 'Camera_Shoot', 'Phone_Soundset_Franklin', true)
  ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.08)
end

AddEventHandler('aln42:appearance:done', function()
  if not pending then return end
  pending = false
  notify('Looks good. Processing your ID...')
  TriggerServerEvent('aln42:intro:claim')
end)

CreateThread(function()
  if not Config.Enabled then return end
  spawnIntroPed()

  while true do
    if introPed and DoesEntityExist(introPed) then
      local p = GetEntityCoords(PlayerPedId())
      local n = GetEntityCoords(introPed)
      local d = #(p - n)

      if d <= (Config.Interact.range or 2.5) then
        showHelp('Press ~INPUT_CONTEXT~ to begin intake (photo + appearance + starter ID).')

        if IsControlJustPressed(0, Config.Interact.key or 38) and not busy then
          busy = true
          playSnap()

          -- Trigger appearance flow first
          if GetResourceState('aln42_appearance') == 'started' then
            pending = true
            TriggerEvent('aln42:appearance:open', { mode = 'intro' })
            notify('Do your look setup, then type: /appearance done')
          else
            -- No appearance resource -> just grant
            TriggerServerEvent('aln42:intro:claim')
          end

          Wait(1000)
          busy = false
        end
      end
    end
    Wait(0)
  end
end)
