fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'ALN42 Intro NPC: one-time starter kit + licenses + optional appearance prompt'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'
