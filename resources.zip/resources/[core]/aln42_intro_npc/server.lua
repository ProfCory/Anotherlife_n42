local function getChar(src)
  if GetResourceState('aln42_characters') ~= 'started' then return nil end
  return exports['aln42_characters']:GetCharacter(src)
end

local function ensureMeta(src)
  local c = getChar(src)
  if not c then return nil end
  c.meta = c.meta or {}
  c.meta.intro = c.meta.intro or {}
  c.meta.licenses = c.meta.licenses or {}
  return c
end

local function items()
  if GetResourceState('aln42_items') ~= 'started' then return nil end
  return exports['aln42_items']
end

RegisterNetEvent('aln42:intro:claim', function()
  local src = source
  local c = ensureMeta(src)
  if not c then return end

  if c.meta.intro.done == true then
    TriggerClientEvent('aln42:intro:toast', src, 'Already processed.')
    return
  end

  local it = items()
  if not it then
    TriggerClientEvent('aln42:intro:toast', src, 'aln42_items not running.')
    return
  end

  -- Licenses
  c.meta.licenses.driver = Config.Licenses.driver == true
  c.meta.licenses.weapon_ccw = Config.Licenses.weapon_ccw == true

  -- Starter items
  if (Config.Starter.cash or 0) > 0 then
    it:GiveItem(src, 'cash', Config.Starter.cash)
  end
  if (Config.Starter.dirty or 0) > 0 then
    it:GiveItem(src, 'dirty_money', Config.Starter.dirty)
  end
  if (Config.Starter.fakeIds or 0) > 0 then
    it:GiveItem(src, 'fake_id', Config.Starter.fakeIds)
  end
  -- Starter burner phone
  if (Config.Starter.burnerPhoneQty or 0) > 0 and Config.Starter.burnerPhoneItem then
    it:GiveItem(src, Config.Starter.burnerPhoneItem, Config.Starter.burnerPhoneQty)
  end

  -- Mark complete
  c.meta.intro.done = true
  c.meta.intro.when = os.time()

  TriggerClientEvent('aln42:intro:granted', src, {
    cash = Config.Starter.cash,
    dirty = Config.Starter.dirty,
    fakeIds = Config.Starter.fakeIds
  })
end)
