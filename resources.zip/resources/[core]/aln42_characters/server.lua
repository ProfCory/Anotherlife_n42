local DATA_FILE = 'data/characters.json'
local db = {}

local function getPrimaryIdentifier(src)
  local id = GetPlayerIdentifierByType and GetPlayerIdentifierByType(src, 'license')
  if id and id ~= '' then return id end

  for i = 0, GetNumPlayerIdentifiers(src) - 1 do
    local v = GetPlayerIdentifier(src, i)
    if v and v:find('license:') == 1 then return v end
  end

  return GetPlayerIdentifier(src, 0) or ('src:' .. tostring(src))
end

local function loadDb()
  local raw = LoadResourceFile(GetCurrentResourceName(), DATA_FILE)
  if not raw or raw == '' then
    db = {}
    return
  end
  local ok, parsed = pcall(json.decode, raw)
  db = (ok and type(parsed) == 'table') and parsed or {}
end

local function saveDb()
  SaveResourceFile(GetCurrentResourceName(), DATA_FILE, json.encode(db, { indent = true }), -1)
end

local function ensureUser(uid)
  db[uid] = db[uid] or { active = 0, slots = {} }
  db[uid].slots = db[uid].slots or {}
  return db[uid]
end

local function getActiveChar(uid)
  local u = ensureUser(uid)
  if not u.active or u.active == 0 then return nil end
  return u.slots[tostring(u.active)]
end

local function defaultChar(slotIndex, payload)
  local now = os.date('!%Y-%m-%dT%H:%M:%SZ')
  return {
    slot = slotIndex,
    created_at = now,
    dead = false,

    id = {
      first = payload.first or 'John',
      last = payload.last or 'Doe',
      dob = payload.dob or '1990-01-01',
      sex = payload.sex or 'X',
      nationality = payload.nationality or 'US',
      cid = ('ALN42-%04d-%06d'):format(slotIndex, math.random(0, 999999)),
    },

    licenses = {
      drivers = Config.Starter.drivers == true,
      weapon_ccw = Config.Starter.weapon_ccw == true,
      blackmarket_contract = Config.Starter.blackmarket_contract == true,
    },

    fake_id = {
      lives = tonumber(Config.Starter.fake_id_lives) or 0
    },

    last = nil,

    meta = {
      money = 0,
      notes = ''
    }
  }
end

local function listSlots(uid)
  local u = ensureUser(uid)
  local out = {}

  for i = 1, Config.MaxSlots do
    local c = u.slots[tostring(i)]
    if c then
      out[i] = {
        exists = true,
        dead = c.dead == true,
        name = (c.id.first or '?') .. ' ' .. (c.id.last or '?'),
        dob = c.id.dob or '?',
        cid = c.id.cid or '?',
        lives = (c.fake_id and c.fake_id.lives) or 0
      }
    else
      out[i] = { exists = false }
    end
  end

  return out, u.active or 0
end

local function setLastPosForActive(uid, pos)
  local c = getActiveChar(uid)
  if not c or c.dead then return false end

  c.last = {
    x = pos.x, y = pos.y, z = pos.z,
    h = pos.h or 0.0,
    ts = os.time()
  }

  saveDb()
  return true
end

-- Exports
exports('GetCharacter', function(src)
  local uid = getPrimaryIdentifier(src)
  return getActiveChar(uid)
end)

exports('GetCharacterSlots', function(src)
  local uid = getPrimaryIdentifier(src)
  return listSlots(uid)
end)

exports('ConsumeFakeIdLife', function(src, amount)
  local uid = getPrimaryIdentifier(src)
  local c = getActiveChar(uid)
  if not c then return false, 'no_active_character' end
  if c.dead then return false, 'character_dead' end

  amount = tonumber(amount) or 1
  c.fake_id = c.fake_id or { lives = 0 }
  c.fake_id.lives = math.max(0, (tonumber(c.fake_id.lives) or 0) - amount)

  if c.fake_id.lives <= 0 then
    c.dead = true
  end

  saveDb()
  return true, c.fake_id.lives
end)

-- Slots list
RegisterNetEvent('aln42:chars:requestSlots', function()
  local src = source
  local uid = getPrimaryIdentifier(src)
  local slots, active = listSlots(uid)
  TriggerClientEvent('aln42:chars:slots', src, slots, active)
end)

-- Active char on join
RegisterNetEvent('aln42:chars:requestActive', function()
  local src = source
  local uid = getPrimaryIdentifier(src)
  local c = getActiveChar(uid)

  if c and not c.dead then
    TriggerClientEvent('aln42:chars:active', src, c)
  else
    TriggerClientEvent('aln42:chars:active', src, nil)
  end
end)

-- Position persistence
RegisterNetEvent('aln42:chars:updatePos', function(pos)
  if not (Config.Persistence and Config.Persistence.enabled) then return end
  if type(pos) ~= 'table' then return end
  if type(pos.x) ~= 'number' or type(pos.y) ~= 'number' or type(pos.z) ~= 'number' then return end

  local src = source
  local uid = getPrimaryIdentifier(src)
  setLastPosForActive(uid, pos)
end)

-- Create
RegisterNetEvent('aln42:chars:create', function(slot, payload)
  local src = source
  local uid = getPrimaryIdentifier(src)
  local u = ensureUser(uid)

  slot = tonumber(slot)
  if not slot or slot < 1 or slot > Config.MaxSlots then
    TriggerClientEvent('aln42:chars:toast', src, 'Invalid slot.')
    return
  end

  if u.slots[tostring(slot)] then
    TriggerClientEvent('aln42:chars:toast', src, ('Slot %d already used.'):format(slot))
    return
  end

  u.slots[tostring(slot)] = defaultChar(slot, payload or {})
  u.active = slot
  saveDb()

  TriggerClientEvent('aln42:chars:toast', src, ('Created + selected slot %d.'):format(slot))
  TriggerClientEvent('aln42:chars:active', src, u.slots[tostring(slot)])
end)

-- Select
RegisterNetEvent('aln42:chars:select', function(slot)
  local src = source
  local uid = getPrimaryIdentifier(src)
  local u = ensureUser(uid)

  slot = tonumber(slot)
  if not slot or slot < 1 or slot > Config.MaxSlots then
    TriggerClientEvent('aln42:chars:toast', src, 'Invalid slot.')
    return
  end

  local c = u.slots[tostring(slot)]
  if not c then
    TriggerClientEvent('aln42:chars:toast', src, ('Slot %d is empty.'):format(slot))
    return
  end

  if c.dead then
    TriggerClientEvent('aln42:chars:toast', src, ('Slot %d is DEAD (no fake IDs left).'):format(slot))
    return
  end

  u.active = slot
  saveDb()

  TriggerClientEvent('aln42:chars:toast', src, ('Selected slot %d.'):format(slot))
  TriggerClientEvent('aln42:chars:active', src, c)
end)

-- Delete
RegisterNetEvent('aln42:chars:delete', function(slot)
  local src = source
  local uid = getPrimaryIdentifier(src)
  local u = ensureUser(uid)

  slot = tonumber(slot)
  if not slot or slot < 1 or slot > Config.MaxSlots then
    TriggerClientEvent('aln42:chars:toast', src, 'Invalid slot.')
    return
  end

  u.slots[tostring(slot)] = nil
  if u.active == slot then u.active = 0 end
  saveDb()

  TriggerClientEvent('aln42:chars:toast', src, ('Deleted slot %d.'):format(slot))
end)

-- Permadeath hook
RegisterNetEvent('aln42:chars:reportDeath', function()
  if not (Config.Permadeath.enabled and Config.Permadeath.consumeLifeOnDeath) then return end

  local src = source
  local ok, remaining = exports[GetCurrentResourceName()]:ConsumeFakeIdLife(src, 1)
  if not ok then return end

  if remaining <= 0 and Config.Permadeath.forceCharSelectOnZero then
    TriggerClientEvent('aln42:chars:dead', src)
  else
    TriggerClientEvent('aln42:chars:toast', src, ('Fake-ID life consumed. Remaining: %d'):format(remaining))
  end
end)

AddEventHandler('onResourceStart', function(res)
  if res ~= GetCurrentResourceName() then return end
  loadDb()
end)
