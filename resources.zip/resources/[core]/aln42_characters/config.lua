Config = {}

Config.MaxSlots = 4

-- Starter licenses on new character
Config.Starter = {
  drivers = true,
  weapon_ccw = true,
  blackmarket_contract = true, -- "knows a guy" access flag
  fake_id_lives = 1            -- starter fake-id lives
}

-- Per-character persistence (CID-scoped via the character record)
Config.Persistence = {
  enabled = true,
  trackIntervalMs = 8000, -- save last location every 8s
  minMoveMeters = 10.0,   -- don’t spam saves if you barely moved
}

-- Permadeath rules
Config.Permadeath = {
  enabled = true,
  consumeLifeOnDeath = true,   -- decrement fake-id lives when player dies
  forceCharSelectOnZero = true -- kick to character select when lives hit 0
}

-- Command names
Config.Commands = {
  menu = 'char',
  select = 'charselect',
  new = 'charnew',
  delete = 'chardel'
}
