local function notify(msg)
  print(('[ALN42] %s'):format(msg))
  TriggerEvent('chat:addMessage', { args = { '^3ALN42', msg } })
end

local function fadeTeleport(x, y, z, h)
  DoScreenFadeOut(250)
  while not IsScreenFadedOut() do Wait(0) end

  local ped = PlayerPedId()
  SetEntityCoordsNoOffset(ped, x, y, z, false, false, false)
  SetEntityHeading(ped, h or 0.0)

  Wait(200)
  DoScreenFadeIn(500)
end

local activeChar = nil
local lastSent = nil

local function showSlots(slots, active)
  notify(('Character Slots (active: %s)'):format(active == 0 and 'none' or tostring(active)))

  for i = 1, #slots do
    local s = slots[i]
    if not s.exists then
      notify(('[%d] EMPTY'):format(i))
    else
      notify(('[%d] %s | DOB %s | CID %s | FakeID lives: %d %s')
        :format(i, s.name, s.dob, s.cid, s.lives, s.dead and '^1(DEAD)^7' or ''))
    end
  end

  notify(('Use: /%s <slot>  |  /%s <slot> <First> <Last> <YYYY-MM-DD>  |  /%s <slot>')
    :format(Config.Commands.select, Config.Commands.new, Config.Commands.delete))
end

RegisterNetEvent('aln42:chars:toast', function(msg) notify(msg) end)

RegisterNetEvent('aln42:chars:slots', function(slots, active)
  showSlots(slots, active)
end)

RegisterNetEvent('aln42:chars:active', function(char)
  activeChar = char
  lastSent = nil

  if not char then
    notify('No active character selected. Use /char to pick/create one.')
    return
  end

  notify(('Active Character: %s %s | FakeID lives: %d')
    :format(char.id.first, char.id.last, (char.fake_id and char.fake_id.lives) or 0))

  -- Auto-load at last location if available
  if char.last and char.last.x and char.last.y and char.last.z then
    fadeTeleport(char.last.x, char.last.y, char.last.z, char.last.h or 0.0)
  end
end)

RegisterNetEvent('aln42:chars:dead', function()
  notify('^1PERMADEATH:^7 no fake IDs remaining. Choose/create a new slot: /char')
end)

-- Commands
RegisterCommand(Config.Commands.menu, function()
  TriggerServerEvent('aln42:chars:requestSlots')
end, false)

RegisterCommand(Config.Commands.select, function(_, args)
  local slot = tonumber(args[1])
  if not slot then
    notify('Usage: /charselect <1-4>')
    return
  end
  TriggerServerEvent('aln42:chars:select', slot)
end, false)

RegisterCommand(Config.Commands.new, function(_, args)
  local slot = tonumber(args[1])
  if not slot then
    notify('Usage: /charnew <1-4> <First> <Last> <YYYY-MM-DD>')
    return
  end

  local first = args[2] or 'John'
  local last  = args[3] or 'Doe'
  local dob   = args[4] or '1990-01-01'

  TriggerServerEvent('aln42:chars:create', slot, {
    first = first,
    last = last,
    dob = dob,
    sex = 'X',
    nationality = 'US'
  })
end, false)

RegisterCommand(Config.Commands.delete, function(_, args)
  local slot = tonumber(args[1])
  if not slot then
    notify('Usage: /chardel <1-4>')
    return
  end
  TriggerServerEvent('aln42:chars:delete', slot)
end, false)

-- On join: request active character
CreateThread(function()
  while not NetworkIsPlayerActive(PlayerId()) do Wait(100) end
  TriggerServerEvent('aln42:chars:requestActive')
end)

-- Periodic last-location persistence
CreateThread(function()
  if not (Config.Persistence and Config.Persistence.enabled) then return end

  local interval = Config.Persistence.trackIntervalMs or 8000
  local minMove = Config.Persistence.minMoveMeters or 10.0

  while true do
    Wait(interval)

    if activeChar and not IsEntityDead(PlayerPedId()) then
      local c = GetEntityCoords(PlayerPedId())
      local h = GetEntityHeading(PlayerPedId())

      if not lastSent then
        lastSent = c
      end

      local dx = c.x - lastSent.x
      local dy = c.y - lastSent.y
      local dz = c.z - lastSent.z
      local dist = math.sqrt(dx*dx + dy*dy + dz*dz)

      if dist >= minMove then
        lastSent = c
        TriggerServerEvent('aln42:chars:updatePos', { x = c.x, y = c.y, z = c.z, h = h })
      end
    end
  end
end)
