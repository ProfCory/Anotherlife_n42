fx_version 'cerulean'
game 'gta5'

description 'ALN42 Characters: 4 slots + IDs + licenses + permadeath via fake-id lives'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'
