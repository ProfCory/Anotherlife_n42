fx_version 'cerulean'
game 'gta5'

description 'ALN42 Phase-0: define spawnpoint + enable autospawn'
client_script 'client.lua'
