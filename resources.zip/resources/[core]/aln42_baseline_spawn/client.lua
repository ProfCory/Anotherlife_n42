-- aln42_baseline_spawn/client.lua
-- Phase-0: add one spawnpoint + enable autospawn

local function forceVisible()
    local ped = PlayerPedId()
    if not ped or ped == -1 then return end

    SetEntityVisible(ped, true, false)
    ResetEntityAlpha(ped)

    FreezeEntityPosition(ped, false)
    SetEntityCollision(ped, true, true)
    SetPlayerInvincible(PlayerId(), false)
end

CreateThread(function()
    while not NetworkIsPlayerActive(PlayerId()) do
        Wait(100)
    end

    while GetResourceState('spawnmanager') ~= 'started' do
        Wait(100)
    end

    -- Add ONE deterministic spawn point
    exports.spawnmanager:addSpawnPoint({
        x = -1037.6, y = -2737.6, z = 20.1,
        heading = 330.0,
        model = "a_m_y_business_01",
        skipFade = false
    })

    exports.spawnmanager:setAutoSpawn(true)
    exports.spawnmanager:forceRespawn()
end)

AddEventHandler('playerSpawned', function()
    Wait(500)
    forceVisible()
end)
