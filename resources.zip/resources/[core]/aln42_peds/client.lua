local locations = {}
local state = {}     -- shop state from server (closedUntil)
local peds = {}      -- [locationId] = ped
local lastPrompt = 0

local function readLocations()
  local raw = LoadResourceFile('aln42_locations', 'data/locations.json')
  if not raw or raw == '' then return {} end
  local ok, parsed = pcall(json.decode, raw)
  return (ok and type(parsed) == 'table') and parsed or {}
end

local function nowClosed(id)
  local s = state[id]
  if not s or not s.closedUntil then return false end
  return os.time() < s.closedUntil
end

local function isOnDuty()
  if not (Config.Duty and Config.Duty.enabled) then return true end
  local h = GetClockHours()
  local openH = Config.Duty.openHour or 7
  local closeH = Config.Duty.closeHour or 23
  if openH < closeH then
    return h >= openH and h < closeH
  end
  -- overnight windows if you ever set open > close
  return (h >= openH) or (h < closeH)
end

local function loadModel(model)
  local hash = joaat(model)
  if not IsModelInCdimage(hash) or not IsModelValid(hash) then return nil end
  RequestModel(hash)
  local timeout = GetGameTimer() + 10000
  while not HasModelLoaded(hash) do
    Wait(0)
    if GetGameTimer() > timeout then return nil end
  end
  return hash
end

local function spawnFor(loc)
  if not loc or not loc.id or not loc.coords then return end
  if peds[loc.id] and DoesEntityExist(peds[loc.id]) then return end
  if nowClosed(loc.id) then return end
  if not isOnDuty() then return end

  local def = Config.TypeDefaults[loc.type or 'shop']
  if not def then return end

  local model = def.model
  local scenario = def.scenario
  local heading = loc.coords.h or def.heading or 0.0

  local hash = loadModel(model)
  if not hash then return end

  local ped = CreatePed(4, hash, loc.coords.x + 0.0, loc.coords.y + 0.0, loc.coords.z + 0.0, heading, false, true)
  SetModelAsNoLongerNeeded(hash)

  SetEntityAsMissionEntity(ped, true, true)
  SetBlockingOfNonTemporaryEvents(ped, true)
  SetPedCanRagdoll(ped, true)
  SetPedFleeAttributes(ped, 0, false)

  if scenario and scenario ~= '' then
    TaskStartScenarioInPlace(ped, scenario, 0, true)
  end

  peds[loc.id] = ped
end

local function despawn(id)
  local ped = peds[id]
  if ped and DoesEntityExist(ped) then
    DeleteEntity(ped)
  end
  peds[id] = nil
end

local function showHelp(text)
  BeginTextCommandDisplayHelp('STRING')
  AddTextComponentString(text)
  EndTextCommandDisplayHelp(0, false, false, 1)
end

local function playerHasWeapon()
  local ped = PlayerPedId()
  local w = GetSelectedPedWeapon(ped)
  return w and w ~= joaat('WEAPON_UNARMED')
end

local function tryRob(loc, ped)
  if not Config.Robbery.enabled then return end
  if nowClosed(loc.id) or not isOnDuty() then return end

  if Config.Robbery.requireWeapon and not playerHasWeapon() then return end

  if Config.Robbery.requireAim then
    if not IsPlayerFreeAimingAtEntity(PlayerId(), ped) then return end
  end

  local me = PlayerPedId()
  local d = #(GetEntityCoords(me) - vector3(loc.coords.x, loc.coords.y, loc.coords.z))
  if d > (Config.Robbery.range or 3.0) then return end

  -- prompt
  if GetGameTimer() - lastPrompt > 250 then
    showHelp(('Press ~INPUT_CONTEXT~ to rob %s'):format(loc.name or 'shopkeeper'))
    lastPrompt = GetGameTimer()
  end

  if not IsControlJustPressed(0, Config.Robbery.interactKey or 38) then return end

  -- Decide outcome
  local roll = math.random()
  local fight = roll < (Config.Robbery.chanceFight or 0.15)
  local run = (not fight) and (roll < ((Config.Robbery.chanceFight or 0.15) + (Config.Robbery.chanceRun or 0.2)))

  ClearPedTasksImmediately(ped)

  if fight then
    GiveWeaponToPed(ped, joaat('WEAPON_PISTOL'), 24, false, true)
    SetPedCombatAttributes(ped, 46, true)
    TaskCombatPed(ped, me, 0, 16)
    TriggerServerEvent('aln42:peds:close', loc.id, Config.Robbery.closeMinutesOnFight or 35)
    return
  end

  if run then
    TaskSmartFleePed(ped, me, 150.0, -1, true, true)
    TriggerServerEvent('aln42:peds:close', loc.id, Config.Robbery.closeMinutesOnRun or 30)
    -- despawn after a moment
    SetTimeout(7000, function() despawn(loc.id) end)
    return
  end

  -- surrender payout
  TaskHandsUp(ped, 8000, me, -1, true)
  Wait(1200)
  TriggerServerEvent('aln42:peds:payout', loc.id)
end

RegisterNetEvent('aln42:peds:state', function(s)
  state = s or {}
end)

CreateThread(function()
  if not Config.Enabled then return end

  math.randomseed(GetGameTimer())

  locations = readLocations()
  TriggerServerEvent('aln42:peds:requestState')

  while true do
    local me = PlayerPedId()
    local myPos = GetEntityCoords(me)

    for i = 1, #locations do
      local loc = locations[i]
      if loc and loc.id and loc.coords and Config.ShopTypes[loc.type] then
        local dist = #(myPos - vector3(loc.coords.x, loc.coords.y, loc.coords.z))
        local exists = peds[loc.id] and DoesEntityExist(peds[loc.id])

        if dist <= (Config.Spawn.radius or 75.0) then
          if not exists then
            spawnFor(loc)
          else
            local ped = peds[loc.id]
            if nowClosed(loc.id) or not isOnDuty() then
              despawn(loc.id)
            else
              if IsEntityDead(ped) then
                TriggerServerEvent('aln42:peds:close', loc.id, Config.Robbery.closeMinutesOnKill or 60)
                despawn(loc.id)
              else
                tryRob(loc, ped)
              end
            end
          end
        elseif dist >= (Config.Spawn.despawnRadius or 120.0) then
          if exists then despawn(loc.id) end
        end
      end
    end

    Wait(250)
  end
end)
