Config = {}

Config.Enabled = true

Config.ShopTypes = {
  shop = true,
  gas = true,
  pawn = true,
  fence = true,
  chopshop = true,
  repaint = true,
  vehshop_new = true,
  vehshop_used = true,
  vehshop_vip = true,
  motel = true,

  dealer = true,
  drugie = true,

  barber = true,     -- NEW
  thrift = true,     -- NEW
  clothing = true    -- NEW
}

Config.TypeDefaults = {
  shop        = { model = 'mp_m_shopkeep_01', scenario = 'WORLD_HUMAN_STAND_IMPATIENT', heading = 0.0 },
  pawn        = { model = 's_m_m_lathandy_01', scenario = 'WORLD_HUMAN_CLIPBOARD', heading = 0.0 },
  fence       = { model = 'g_m_m_chicold_01', scenario = 'WORLD_HUMAN_SMOKING', heading = 0.0 },
  chopshop    = { model = 's_m_y_xmech_01', scenario = 'WORLD_HUMAN_HAMMERING', heading = 0.0 },
  repaint     = { model = 's_m_y_xmech_02', scenario = 'WORLD_HUMAN_WELDING', heading = 0.0 },
  vehshop_new = { model = 's_m_m_autoshop_02', scenario = 'WORLD_HUMAN_CLIPBOARD', heading = 0.0 },
  vehshop_used= { model = 's_m_m_autoshop_01', scenario = 'WORLD_HUMAN_STAND_IMPATIENT', heading = 0.0 },
  vehshop_vip = { model = 's_m_m_highsec_01', scenario = 'WORLD_HUMAN_GUARD_STAND', heading = 0.0 },
  gas         = { model = 's_m_m_gentransport', scenario = 'WORLD_HUMAN_STAND_IMPATIENT', heading = 0.0 },
  motel       = { model = 's_f_y_retail_01', scenario = 'WORLD_HUMAN_STAND_IMPATIENT', heading = 0.0 },

  dealer      = { model = 'g_m_y_mexgoon_03', scenario = 'WORLD_HUMAN_DRUG_DEALER', heading = 0.0 },
  drugie      = { model = 'a_m_m_tramp_01',  scenario = 'WORLD_HUMAN_DRUG_DEALER', heading = 0.0 },

  barber      = { model = 's_m_m_hairdress_01', scenario = 'WORLD_HUMAN_STAND_IMPATIENT', heading = 0.0 }, -- NEW
  thrift      = { model = 's_f_y_shop_mid',     scenario = 'WORLD_HUMAN_STAND_IMPATIENT', heading = 0.0 }, -- NEW
  clothing    = { model = 's_f_y_shop_low',     scenario = 'WORLD_HUMAN_STAND_IMPATIENT', heading = 0.0 }  -- NEW
}

-- Global duty window (simple baseline)
Config.Duty = { enabled = true, openHour = 7, closeHour = 23 }

Config.Spawn = { radius = 75.0, despawnRadius = 120.0 }

Config.Robbery = {
  enabled = true,
  interactKey = 38,
  requireWeapon = true,
  requireAim = true,
  range = 3.0,

  chanceFight = 0.18,
  chanceRun = 0.22,

  closeMinutesOnRobbery = 20,
  closeMinutesOnRun = 30,
  closeMinutesOnFight = 35,
  closeMinutesOnKill = 60,

  payoutDirtyMoneyMin = 80,
  payoutDirtyMoneyMax = 240
}

Config.DirtyMoneyItem = 'dirty_money'
