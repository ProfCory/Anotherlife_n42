fx_version 'cerulean'
game 'gta5'

description 'ALN42 Peds: location-based shop NPCs + robbery/closure state'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'
