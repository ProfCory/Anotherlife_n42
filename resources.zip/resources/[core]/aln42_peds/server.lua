local shopState = {} -- [locationId] = { closedUntil = os.time() }

local function isClosed(id)
  local s = shopState[id]
  if not s or not s.closedUntil then return false end
  return os.time() < s.closedUntil
end

local function closeShop(id, minutes)
  shopState[id] = shopState[id] or {}
  shopState[id].closedUntil = os.time() + (minutes * 60)
end

RegisterNetEvent('aln42:peds:requestState', function()
  TriggerClientEvent('aln42:peds:state', source, shopState)
end)

RegisterNetEvent('aln42:peds:close', function(locationId, minutes)
  if type(locationId) ~= 'string' then return end
  minutes = tonumber(minutes) or 10
  closeShop(locationId, minutes)
  TriggerClientEvent('aln42:peds:state', -1, shopState)
end)

RegisterNetEvent('aln42:peds:payout', function(locationId)
  local src = source
  if type(locationId) ~= 'string' then return end
  if isClosed(locationId) then return end

  local min = Config.Robbery.payoutDirtyMoneyMin or 50
  local max = Config.Robbery.payoutDirtyMoneyMax or 200
  local amt = math.random(min, max)

  -- close after successful robbery
  closeShop(locationId, Config.Robbery.closeMinutesOnRobbery or 20)
  TriggerClientEvent('aln42:peds:state', -1, shopState)

  -- If aln42_items exists, grant dirty money item; otherwise just notify.
  if GetResourceState('aln42_items') == 'started' then
    -- Give item via item resource event if you later formalize it; for now, simple server-side print.
    -- If you already implemented aln42_items from earlier, add a server export later (we can do that next).
    TriggerClientEvent('chat:addMessage', src, { args = { '^2ALN42', ('Robbery payout: %d %s (implement grant hook next)'):format(amt, Config.DirtyMoneyItem) } })
  else
    TriggerClientEvent('chat:addMessage', src, { args = { '^2ALN42', ('Robbery payout (no items system): $%d'):format(amt) } })
  end
end)
