fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'ALN42 Garages: one private garage per type, public parking, spawn/store owned vehicles by plate'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'
