local function chars()
  if GetResourceState('aln42_characters') ~= 'started' then return nil end
  return exports['aln42_characters']
end

local function items()
  if GetResourceState('aln42_items') ~= 'started' then return nil end
  return exports['aln42_items']
end

local function getChar(src)
  local ch = chars()
  if not ch then return nil end
  return ch:GetCharacter(src)
end

local function ensureMeta(c)
  c.meta = c.meta or {}
  c.meta.garages = c.meta.garages or {
    owned = {},      -- owned[type] = garageId
    private = {}     -- private[garageId]=true (purchase record)
  }
  c.meta.vehicles = c.meta.vehicles or { owned = {}, keys = {} }
  return c.meta.garages, c.meta.vehicles
end

local function pay(src, amount)
  amount = math.floor(tonumber(amount) or 0)
  if amount <= 0 then return true end
  local it = items()
  if not it then return false, 'aln42_items not running' end
  if not it:HasItem(src, Config.CashItem, amount) then
    return false, 'Not enough cash.'
  end
  it:TakeItem(src, Config.CashItem, amount)
  return true
end

RegisterNetEvent('aln42:garages:buy', function(garageType, garageId, price)
  local src = source
  local c = getChar(src)
  if not c then return end
  local gmeta = ensureMeta(c)

  if not Config.Types[garageType] then
    TriggerClientEvent('aln42:garages:toast', src, 'Invalid garage type.')
    return
  end

  garageId = tostring(garageId or '')
  if garageId == '' then return end

  local ok, err = pay(src, price)
  if not ok then
    TriggerClientEvent('aln42:garages:toast', src, err or 'Payment failed.')
    return
  end

  -- purchase record + set as your active owned garage for that type (one per type)
  c.meta.garages.private[garageId] = true
  c.meta.garages.owned[garageType] = garageId

  TriggerClientEvent('aln42:garages:toast', src, ('Purchased garage for %s.'):format(Config.Types[garageType].label))
  TriggerClientEvent('aln42:garages:ownedUpdated', src, c.meta.garages.owned)
end)

RegisterNetEvent('aln42:garages:setHome', function(garageType, garageId, kind)
  local src = source
  local c = getChar(src)
  if not c then return end
  ensureMeta(c)

  if not Config.Types[garageType] then
    TriggerClientEvent('aln42:garages:toast', src, 'Invalid garage type.')
    return
  end

  garageId = tostring(garageId or '')
  if garageId == '' then return end

  kind = tostring(kind or 'public')
  if kind == 'private' and c.meta.garages.private[garageId] ~= true then
    TriggerClientEvent('aln42:garages:toast', src, 'You do not own this private garage.')
    return
  end

  c.meta.garages.owned[garageType] = garageId
  TriggerClientEvent('aln42:garages:toast', src, ('Set %s garage to %s'):format(Config.Types[garageType].label, garageId))
  TriggerClientEvent('aln42:garages:ownedUpdated', src, c.meta.garages.owned)
end)

RegisterNetEvent('aln42:garages:getOwned', function()
  local src = source
  local c = getChar(src)
  if not c then return end
  ensureMeta(c)
  TriggerClientEvent('aln42:garages:ownedUpdated', src, c.meta.garages.owned)
end)

RegisterNetEvent('aln42:garages:getVehicles', function()
  local src = source
  local c = getChar(src)
  if not c then return end
  local _, vmeta = ensureMeta(c)
  TriggerClientEvent('aln42:garages:vehicles', src, vmeta.owned or {}, vmeta.keys or {})
end)

RegisterNetEvent('aln42:garages:spawnRequest', function(plate)
  local src = source
  local c = getChar(src)
  if not c then return end
  local _, vmeta = ensureMeta(c)

  plate = tostring(plate or ''):upper():gsub('%s+','')
  if plate == '' then return end

  local data = vmeta.owned[plate]
  if not data then
    TriggerClientEvent('aln42:garages:toast', src, 'You do not own that plate.')
    return
  end

  TriggerClientEvent('aln42:garages:spawnData', src, plate, data)
end)

RegisterNetEvent('aln42:garages:storeOwned', function(plate, props)
  local src = source
  local c = getChar(src)
  if not c then return end
  local _, vmeta = ensureMeta(c)

  plate = tostring(plate or ''):upper():gsub('%s+','')
  if plate == '' then return end
  if not vmeta.owned[plate] then return end
  if type(props) ~= 'table' then return end

  vmeta.owned[plate].props = props
  vmeta.owned[plate].last = os.time()
end)
