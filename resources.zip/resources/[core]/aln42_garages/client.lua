local locations = {}
local ownedHome = {}   -- ownedHome[type]=garageId
local vehicleCache = {} -- owned vehicles

local function notify(msg)
  print(('[ALN42 Garages] %s'):format(msg))
  TriggerEvent('chat:addMessage', { args = { '^3ALN42-Garage', msg } })
end

RegisterNetEvent('aln42:garages:toast', function(msg) notify(msg) end)
RegisterNetEvent('aln42:garages:ownedUpdated', function(t) ownedHome = t or {} end)
RegisterNetEvent('aln42:garages:vehicles', function(owned, keys)
  vehicleCache = owned or {}
  notify('Owned vehicles (plate list):')
  local n = 0
  for plate,_ in pairs(vehicleCache) do
    n = n + 1
    notify('  '..plate)
  end
  if n == 0 then notify('  (none)') end
end)

local function readJson(res, path)
  local raw = LoadResourceFile(res, path)
  if not raw or raw == '' then return {} end
  local ok, parsed = pcall(json.decode, raw)
  return (ok and type(parsed) == 'table') and parsed or {}
end

local function dist3(a,b)
  local dx=a.x-b.x; local dy=a.y-b.y; local dz=a.z-b.z
  return math.sqrt(dx*dx+dy*dy+dz*dz)
end

local function findNearestGarage()
  local p = GetEntityCoords(PlayerPedId())
  local p3 = {x=p.x,y=p.y,z=p.z}
  local best, bestD = nil, 999999.0

  for _, loc in ipairs(locations) do
    if loc and loc.coords and loc.type then
      if loc.type:find('garage_') or loc.type == 'parking_public' then
        local d = dist3(p3, loc.coords)
        if d < bestD then
          bestD = d
          best = loc
        end
      end
    end
  end

  if best and bestD <= (Config.Range or 12.0) then return best, bestD end
  return nil, nil
end

local function pickPad(loc)
  if loc and type(loc.pads) == 'table' and #loc.pads > 0 then
    return loc.pads[math.random(1, #loc.pads)]
  end
  return Config.DefaultPad
end

local function applySavedProps(veh, props)
  if type(props) ~= 'table' then return end

  if props.rgb and props.rgb.r then
    SetVehicleCustomPrimaryColour(veh, props.rgb.r, props.rgb.g, props.rgb.b)
    SetVehicleCustomSecondaryColour(veh, props.rgb.r, props.rgb.g, props.rgb.b)
  end

  if props.color1 and props.color2 then
    SetVehicleColours(veh, tonumber(props.color1), tonumber(props.color2))
  end
end

local function applySavedMods(veh, mods)
  if type(mods) ~= 'table' then return end
  if mods.turbo == true then ToggleVehicleMod(veh, 18, true) end
  if mods.handlingMult then
    local mult = tonumber(mods.handlingMult) or 1.0
    SetVehicleEnginePowerMultiplier(veh, (mult - 1.0) * 100.0)
    SetVehicleEngineTorqueMultiplier(veh, mult)
  end
end

local function loadModel(hashOrName)
  local h = type(hashOrName) == 'number' and hashOrName or joaat(hashOrName)
  if not IsModelInCdimage(h) or not IsModelValid(h) then return nil end
  RequestModel(h)
  local deadline = GetGameTimer() + 12000
  while not HasModelLoaded(h) do
    Wait(0)
    if GetGameTimer() > deadline then return nil end
  end
  return h
end

RegisterNetEvent('aln42:garages:spawnData', function(plate, data)
  local loc = select(1, findNearestGarage())
  if not loc then notify('Stand at a garage/parking lot to spawn.'); return end

  local pad = pickPad(loc)
  local model = data.model
  if not model then notify('Missing vehicle model in save data.'); return end

  local mh = loadModel(model)
  if not mh then notify('Could not load vehicle model.'); return end

  local veh = CreateVehicle(mh, pad.x, pad.y, pad.z, pad.h or 0.0, true, true)
  SetModelAsNoLongerNeeded(mh)
  if veh == 0 then notify('Vehicle spawn failed.'); return end

  SetEntityAsMissionEntity(veh, true, true)
  SetVehicleOnGroundProperly(veh)
  SetVehicleNumberPlateText(veh, plate)

  applySavedProps(veh, data.props or {})
  applySavedMods(veh, data.mods or {})

  notify(('Spawned %s at %s'):format(plate, loc.name or loc.id))
end)

-- /garage here         (shows nearest garage info)
-- /garage buy           (buys nearest private garage as home for that type)
-- /garage sethome       (sets nearest garage as your “home” for that type; private requires ownership)
-- /garage vehicles      (lists owned plates)
-- /garage spawn <plate> (spawns at nearest garage pad)
-- /garage store         (stores current vehicle if owned)
RegisterCommand('garage', function(_, args)
  local sub = (args[1] or 'here'):lower()
  local loc = select(1, findNearestGarage())

  if sub == 'here' then
    if not loc then notify('Not near a garage/parking.'); return end
    notify(('Nearest: %s (%s) kind=%s'):format(loc.name or loc.id, loc.type, loc.kind or 'public'))
    return
  end

  if sub == 'vehicles' then
    TriggerServerEvent('aln42:garages:getVehicles')
    return
  end

  if sub == 'buy' then
    if not loc then notify('Not near a garage.'); return end
    if not Config.Types[loc.type] then notify('This is not a purchasable garage type.'); return end
    if (loc.kind or 'public') ~= 'private' then notify('This garage is public and does not need purchase.'); return end
    local price = tonumber(loc.price) or 0
    TriggerServerEvent('aln42:garages:buy', loc.type, loc.id, price)
    return
  end

  if sub == 'sethome' then
    if not loc then notify('Not near a garage.'); return end
    if not Config.Types[loc.type] then notify('This is not a typed home garage.'); return end
    TriggerServerEvent('aln42:garages:setHome', loc.type, loc.id, loc.kind or 'public')
    return
  end

  if sub == 'spawn' then
    local plate = tostring(args[2] or ''):upper():gsub('%s+','')
    if plate == '' then notify('Usage: /garage spawn <plate>'); return end
    TriggerServerEvent('aln42:garages:spawnRequest', plate)
    return
  end

  if sub == 'store' then
    local ped = PlayerPedId()
    local v = GetVehiclePedIsIn(ped, false)
    if v == 0 or GetPedInVehicleSeat(v, -1) ~= ped then
      notify('Be in the vehicle (driver seat) to store it.')
      return
    end

    local plate = tostring(GetVehicleNumberPlateText(v) or ''):upper():gsub('%s+','')
    if plate == '' then return end

    local props = {
      color1 = select(1, GetVehicleColours(v)),
      color2 = select(2, GetVehicleColours(v)),
      engine = GetVehicleEngineHealth(v),
      body = GetVehicleBodyHealth(v)
    }

    TriggerServerEvent('aln42:garages:storeOwned', plate, props)
    DeleteVehicle(v)
    notify(('Stored %s'):format(plate))
    return
  end

  notify('Garage:')
  notify('  /garage here')
  notify('  /garage buy')
  notify('  /garage sethome')
  notify('  /garage vehicles')
  notify('  /garage spawn <plate>')
  notify('  /garage store')
end, false)

CreateThread(function()
  if not Config.Enabled then return end
  locations = readJson('aln42_locations', 'data/locations.json')
  TriggerServerEvent('aln42:garages:getOwned')
end)
