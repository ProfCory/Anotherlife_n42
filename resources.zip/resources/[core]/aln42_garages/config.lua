Config = {}

Config.Enabled = true
Config.Range = 12.0

Config.CashItem = 'cash'

-- one owned garage per type
Config.Types = {
  garage_cars = { label = 'Cars', maxOwned = 1 },
  garage_box_truck = { label = 'Box Truck', maxOwned = 1 },
  garage_big_rig = { label = 'Big Rig', maxOwned = 1 },
  garage_boat = { label = 'Boat', maxOwned = 1 },
  garage_plane = { label = 'Plane', maxOwned = 1 }
}

-- fallback if garage has no pads
Config.DefaultPad = { x = 0.0, y = 0.0, z = 72.0, h = 0.0 }
