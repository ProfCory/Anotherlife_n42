local function giveDirtyMoney(src, amount)
  if GetResourceState('aln42_items') ~= 'started' then
    TriggerClientEvent('chat:addMessage', src, { args = { '^2ALN42', ('(no items) Chop payout: $%d'):format(amount) } })
    return
  end
  exports['aln42_items']:GiveItem(src, Config.DirtyMoneyItem, amount)
end

RegisterNetEvent('aln42:chop:payout', function(payload)
  local src = source
  if type(payload) ~= 'table' then return end
  local amount = tonumber(payload.amount) or 0
  if amount <= 0 then return end
  giveDirtyMoney(src, amount)
end)
