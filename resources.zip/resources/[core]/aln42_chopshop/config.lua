Config = {}

Config.Enabled = true

-- Payout rules
Config.Payout = {
  maxPercent = 0.25,        -- 25% of vehicle value at most
  alertedPercent = 0.10,    -- 10% if police were ever alerted
  refundDirtyUsedPercent = 0.90, -- 90% refund if purchased used with dirty money (special case)

  -- Damage deduction:
  -- Uses BodyHealth (0..1000). At 1000 → 0% penalty, at 0 → 70% penalty.
  maxDamagePenalty = 0.70
}

-- Location type that counts as chop shop
Config.LocationType = 'chopshop'
Config.Range = 7.0

-- Item payout
Config.DirtyMoneyItem = 'dirty_money'
