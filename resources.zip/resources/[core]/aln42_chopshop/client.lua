local locations = {}

local function notify(msg)
  print(('[ALN42 ChopShop] %s'):format(msg))
  TriggerEvent('chat:addMessage', { args = { '^6ALN42-Chop', msg } })
end

local function readLocations()
  local raw = LoadResourceFile('aln42_locations', 'data/locations.json')
  if not raw or raw == '' then return {} end
  local ok, parsed = pcall(json.decode, raw)
  return (ok and type(parsed) == 'table') and parsed or {}
end

local function nearChop()
  local ped = PlayerPedId()
  local p = GetEntityCoords(ped)
  for i=1, #locations do
    local loc = locations[i]
    if loc and loc.type == Config.LocationType and loc.coords then
      local dx = p.x - loc.coords.x
      local dy = p.y - loc.coords.y
      local dz = p.z - loc.coords.z
      local d = math.sqrt(dx*dx + dy*dy + dz*dz)
      if d <= (Config.Range or 7.0) then
        return true, loc
      end
    end
  end
  return false, nil
end

local function getVehicleValue(veh)
  if GetResourceState('aln42_vehiclecrime') ~= 'started' then return 35000 end
  local name = GetDisplayNameFromVehicleModel(GetEntityModel(veh))
  if not name or name == '' then return 35000 end
  return exports['aln42_vehiclecrime']:GetVehicleValueByModel(name:lower())
end

local function isAlerted(veh)
  if GetResourceState('aln42_vehiclecrime') ~= 'started' then return false end
  local plate = tostring(GetVehicleNumberPlateText(veh) or '')
  return exports['aln42_vehiclecrime']:IsVehicleAlerted(plate) == true
end

-- Optional purchase metadata for “bought used with dirty money” refund:
-- You can set it with the command below (for now).
local function getPurchaseMeta(veh)
  local e = Entity(veh)
  local meta = e.state.aln42_purchase
  if type(meta) ~= 'table' then return nil end
  return meta
end

local function damageMultiplier(veh)
  local bh = GetVehicleBodyHealth(veh) -- 0..1000
  bh = math.max(0.0, math.min(1000.0, bh))
  local dmg = 1.0 - (bh / 1000.0)          -- 0 (no dmg) .. 1 (wreck)
  local penalty = dmg * (Config.Payout.maxDamagePenalty or 0.70)
  return math.max(0.05, 1.0 - penalty)     -- never less than 5% payout
end

local function chopCurrentVehicle()
  if not Config.Enabled then return end

  local okNear = nearChop()
  if not okNear then
    notify('You must be at a Chop Shop.')
    return
  end

  local ped = PlayerPedId()
  local veh = GetVehiclePedIsIn(ped, false)
  if veh == 0 then
    notify('You must be in a vehicle.')
    return
  end
  if GetPedInVehicleSeat(veh, -1) ~= ped then
    notify('You must be the driver.')
    return
  end

  local value = getVehicleValue(veh)
  local alerted = isAlerted(veh)

  -- base payout caps
  local basePercent = alerted and (Config.Payout.alertedPercent or 0.10) or (Config.Payout.maxPercent or 0.25)
  local payout = math.floor(value * basePercent)

  -- refund case (bought used with dirty money): refund 90% of purchase price (unless alerted, which forces 10% rule)
  local purchase = getPurchaseMeta(veh)
  if purchase and purchase.dirty == true and type(purchase.price) == 'number' and not alerted then
    local refund = math.floor(purchase.price * (Config.Payout.refundDirtyUsedPercent or 0.90))
    payout = math.max(payout, refund)
  end

  -- damage deduction applies to all cases
  local mult = damageMultiplier(veh)
  payout = math.floor(payout * mult)

  if payout <= 0 then
    notify('Vehicle too damaged to be worth chopping.')
    return
  end

  -- Pay in dirty money only
  TriggerServerEvent('aln42:chop:payout', { amount = payout })

  -- Delete vehicle
  SetEntityAsMissionEntity(veh, true, true)
  DeleteEntity(veh)

  notify(('Chopped for $%d dirty. %s %s')
    :format(
      payout,
      alerted and '^1(Police-alerted: 10%)^7' or '(25% cap)',
      ('(Damage multiplier: %.2f)'):format(mult)
    ))
end

-- Helper: mark a vehicle as “purchased used with dirty money” for refund logic (temporary tool)
-- Usage: /markdirtybuy 50000
RegisterCommand('markdirtybuy', function(_, args)
  local ped = PlayerPedId()
  local veh = GetVehiclePedIsIn(ped, false)
  if veh == 0 then notify('Get in a vehicle first.'); return end
  local price = tonumber(args[1] or '0')
  if price <= 0 then notify('Usage: /markdirtybuy <purchase_price>'); return end
  Entity(veh).state:set('aln42_purchase', { price = price, dirty = true }, true)
  notify(('Marked purchase: dirty used, price $%d'):format(price))
end, false)

RegisterCommand('chop', function()
  chopCurrentVehicle()
end, false)

CreateThread(function()
  locations = readLocations()
end)
