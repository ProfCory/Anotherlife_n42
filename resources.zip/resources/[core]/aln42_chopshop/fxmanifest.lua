fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'ALN42 Chop Shop: vehicle-only payout in dirty money with alert+damage rules'

shared_scripts { 'config.lua' }
server_scripts { 'server.lua' }
client_scripts { 'client.lua' }
