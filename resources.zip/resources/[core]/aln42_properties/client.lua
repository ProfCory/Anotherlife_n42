local props = {}
local active = nil

local function notify(msg)
  print(('[ALN42 Props] %s'):format(msg))
  TriggerEvent('chat:addMessage', { args = { '^5ALN42-Props', msg } })
end

RegisterNetEvent('aln42:props:toast', function(msg) notify(msg) end)
RegisterNetEvent('aln42:props:sync', function(list) props = list or {} end)

local function dist3(a,b)
  local dx=a.x-b.x; local dy=a.y-b.y; local dz=a.z-b.z
  return math.sqrt(dx*dx+dy*dy+dz*dz)
end

local function getPos()
  local p = GetEntityCoords(PlayerPedId())
  return { x=p.x, y=p.y, z=p.z }
end

local function showHelp(text)
  BeginTextCommandDisplayHelp('STRING')
  AddTextComponentString(text)
  EndTextCommandDisplayHelp(0, false, false, 1)
end

local function findActive()
  local p = getPos()
  local best, bestD = nil, 999999.0

  for _, pr in ipairs(props) do
    if pr and pr.entry and pr.entry.x then
      local d = dist3(p, pr.entry)
      if d < bestD then best = pr; bestD = d end
    end
  end

  if best and bestD <= (Config.Range or 2.5) then return best end
  return nil
end

local function teleportTo(vec, h)
  local ped = PlayerPedId()
  DoScreenFadeOut(250)
  Wait(260)
  SetEntityCoords(ped, vec.x, vec.y, vec.z, false, false, false, true)
  if h then SetEntityHeading(ped, h) end
  Wait(120)
  DoScreenFadeIn(250)
end

local lastDoorId = nil
local inside = false

RegisterNetEvent('aln42:props:enterResult', function(id, ok, reason)
  if id ~= lastDoorId then return end
  if not ok then
    notify(reason or 'Cannot enter.')
    return
  end

  local pr = nil
  for _, p in ipairs(props) do if p.id == id then pr = p; break end end
  if not pr then return end

  if not inside then
    if pr.exit and pr.exit.x then
      teleportTo(pr.exit, pr.exit.h)
    else
      -- fallback: step forward “fake interior” until you add shells/portals
      local ped = PlayerPedId()
      local fwd = GetEntityForwardVector(ped)
      local p = GetEntityCoords(ped)
      teleportTo({ x = p.x + fwd.x * (Config.FallbackEnterOffset.y or 2.0), y = p.y + fwd.y * (Config.FallbackEnterOffset.y or 2.0), z = p.z }, nil)
    end
    inside = true
    notify('Entered. Use E at the same door to exit.')
  else
    teleportTo(pr.entry, pr.entry.h)
    inside = false
    notify('Exited.')
  end
end)

local function openDoorMenu(pr)
  notify(('[%s] %s (%s) $%d'):format(pr.kind, pr.name or pr.id, pr.size or 'n/a', tonumber(pr.price) or 0))
  notify('Commands:')
  notify(('  /door enter %s'):format(pr.id))
  notify(('  /door buy %s'):format(pr.id))
  notify(('  /door lock %s'):format(pr.id))
  if Config.EnableSetHome and pr.kind == 'home' then
    notify(('  /door sethome %s'):format(pr.id))
  end
  if pr.kind == 'garage' then
    notify('  (garage spawns are handled by /garage spawn <plate> at this door location)')
  end
end

RegisterCommand('door', function(_, args)
  local sub = (args[1] or ''):lower()
  local id = tostring(args[2] or '')

  if sub == 'enter' then
    if id == '' and active then id = active.id end
    if id == '' then notify('Usage: /door enter <id>'); return end
    lastDoorId = id
    TriggerServerEvent('aln42:props:canEnter', id)
    return
  end

  if sub == 'buy' then
    if id == '' and active then id = active.id end
    if id == '' then notify('Usage: /door buy <id>'); return end
    TriggerServerEvent('aln42:props:buy', id)
    return
  end

  if sub == 'lock' then
    if id == '' and active then id = active.id end
    if id == '' then notify('Usage: /door lock <id>'); return end
    TriggerServerEvent('aln42:props:toggleLock', id)
    return
  end

  if sub == 'sethome' then
    if id == '' and active then id = active.id end
    if id == '' then notify('Usage: /door sethome <id>'); return end
    TriggerServerEvent('aln42:props:setHome', id)
    return
  end

  notify('Usage: /door enter|buy|lock|sethome <id>')
end, false)

-- ADMIN COMMANDS
-- /prop create home|garage <size> <name_words...>
-- /prop setexit <id>        (records your current position as exit)
-- /prop setentry <id>       (records your current position as entry)
-- /prop price <id> <amount>
-- /prop remove <id>
RegisterCommand('prop', function(_, args)
  local sub = (args[1] or ''):lower()

  if sub == 'create' then
    local kind = (args[2] or ''):lower() -- home|garage
    local size = (args[3] or ''):lower()
    if kind ~= 'home' and kind ~= 'garage' then notify('Usage: /prop create home|garage <size> <name>'); return end
    if not Config.Sizes[size] then notify('Invalid size.'); return end

    local name = table.concat(args, ' ', 4)
    if name == '' then name = (kind == 'home') and 'Home Door' or 'Garage Door' end

    local p = getPos()
    local h = GetEntityHeading(PlayerPedId())
    local id = ('%s_%s_%d'):format(kind, size, math.random(10000, 99999))
    local price = Config.Sizes[size].basePrice

    TriggerServerEvent('aln42:props:adminCreate', {
      id = id,
      kind = kind,         -- home|garage
      size = size,
      name = name,
      price = price,
      entry = { x=p.x, y=p.y, z=p.z, h=h },
      exit = nil
    })

    notify(('Created %s (%s) at your position. Use /prop setexit %s when inside.'):format(id, kind, id))
    return
  end

  if sub == 'setexit' then
    local id = tostring(args[2] or '')
    if id == '' then notify('Usage: /prop setexit <id>'); return end
    local p = getPos()
    local h = GetEntityHeading(PlayerPedId())
    TriggerServerEvent('aln42:props:adminUpdate', id, { exit = { x=p.x, y=p.y, z=p.z, h=h } })
    notify('Exit set.')
    return
  end

  if sub == 'setentry' then
    local id = tostring(args[2] or '')
    if id == '' then notify('Usage: /prop setentry <id>'); return end
    local p = getPos()
    local h = GetEntityHeading(PlayerPedId())
    TriggerServerEvent('aln42:props:adminUpdate', id, { entry = { x=p.x, y=p.y, z=p.z, h=h } })
    notify('Entry set.')
    return
  end

  if sub == 'price' then
    local id = tostring(args[2] or '')
    local amt = tonumber(args[3] or '')
    if id == '' or not amt then notify('Usage: /prop price <id> <amount>'); return end
    TriggerServerEvent('aln42:props:adminUpdate', id, { price = math.floor(amt) })
    notify('Price set.')
    return
  end

  if sub == 'remove' then
    local id = tostring(args[2] or '')
    if id == '' then notify('Usage: /prop remove <id>'); return end
    TriggerServerEvent('aln42:props:adminRemove', id)
    return
  end

  notify('Admin: /prop create home|garage <size> <name> | /prop setexit <id> | /prop setentry <id> | /prop price <id> <amt> | /prop remove <id>')
end, false)

CreateThread(function()
  if not Config.Enabled then return end
  TriggerServerEvent('aln42:props:request')

  while true do
    active = findActive()
    if active then
      showHelp(('Press ~INPUT_CONTEXT~ for %s'):format(active.name or active.id))
      if IsControlJustPressed(0, Config.Key or 38) then
        openDoorMenu(active)
      end
    end
    Wait(Config.ScanEveryMs or 250)
  end
end)
