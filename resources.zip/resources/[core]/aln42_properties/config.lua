Config = {}

Config.Enabled = true

Config.AdminAce = 'aln42.admin'     -- give yourself this ace in server.cfg
Config.Key = 38                    -- E
Config.Range = 2.5
Config.ScanEveryMs = 250

-- Price is based on size preset unless overridden by admin
Config.Sizes = {
  tiny   = { label='Tiny',   basePrice=15000, storage=30 },
  small  = { label='Small',  basePrice=30000, storage=60 },
  medium = { label='Medium', basePrice=65000, storage=120 },
  large  = { label='Large',  basePrice=120000, storage=220 }
}

-- Default “interior” behavior for now:
-- If no exit is set, it will just teleport you a few meters forward (placeholder).
Config.FallbackEnterOffset = { x = 0.0, y = 2.0, z = 0.0 }

Config.CashItem = 'cash'

-- Optional: hook into your spawn system later
Config.EnableSetHome = true
