fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'ALN42 Properties: home doors + garage doors + admin placement + E-menu'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'

files { 'data/properties.json' }
