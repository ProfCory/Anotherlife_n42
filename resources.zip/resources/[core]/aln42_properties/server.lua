local FILE = 'data/properties.json'
local props = {}

local function chars()
  if GetResourceState('aln42_characters') ~= 'started' then return nil end
  return exports['aln42_characters']
end

local function items()
  if GetResourceState('aln42_items') ~= 'started' then return nil end
  return exports['aln42_items']
end

local function getChar(src)
  local ch = chars()
  if not ch then return nil end
  return ch:GetCharacter(src)
end

local function ensureMeta(c)
  c.meta = c.meta or {}
  c.meta.properties = c.meta.properties or {
    owned = {},   -- owned[propId]=true
    locked = {},  -- locked[propId]=true
    home = nil    -- propId
  }
  return c.meta.properties
end

local function readProps()
  local raw = LoadResourceFile(GetCurrentResourceName(), FILE)
  if not raw or raw == '' then return {} end
  local ok, parsed = pcall(json.decode, raw)
  return (ok and type(parsed) == 'table') and parsed or {}
end

local function saveProps()
  SaveResourceFile(GetCurrentResourceName(), FILE, json.encode(props, { indent = true }), -1)
end

local function broadcast()
  TriggerClientEvent('aln42:props:sync', -1, props)
end

local function findById(id)
  for i=1,#props do
    if props[i] and props[i].id == id then return props[i], i end
  end
  return nil, nil
end

local function pay(src, amount)
  amount = math.floor(tonumber(amount) or 0)
  if amount <= 0 then return true end
  local it = items()
  if not it then return false, 'aln42_items not running' end
  if not it:HasItem(src, Config.CashItem, amount) then
    return false, 'Not enough cash.'
  end
  it:TakeItem(src, Config.CashItem, amount)
  return true
end

local function isAdmin(src)
  return IsPlayerAceAllowed(src, Config.AdminAce)
end

AddEventHandler('onResourceStart', function(res)
  if res ~= GetCurrentResourceName() then return end
  props = readProps()
  broadcast()
end)

RegisterNetEvent('aln42:props:request', function()
  TriggerClientEvent('aln42:props:sync', source, props)
end)

-- Admin create
RegisterNetEvent('aln42:props:adminCreate', function(payload)
  local src = source
  if not isAdmin(src) then return end
  if type(payload) ~= 'table' then return end

  local id = tostring(payload.id or '')
  if id == '' then return end
  if findById(id) then
    TriggerClientEvent('aln42:props:toast', src, 'ID already exists.')
    return
  end

  table.insert(props, payload)
  saveProps()
  broadcast()
  TriggerClientEvent('aln42:props:toast', src, ('Created %s'):format(id))
end)

RegisterNetEvent('aln42:props:adminUpdate', function(id, patch)
  local src = source
  if not isAdmin(src) then return end
  local p, idx = findById(id)
  if not p then return end
  if type(patch) ~= 'table' then return end

  for k,v in pairs(patch) do
    p[k] = v
  end

  props[idx] = p
  saveProps()
  broadcast()
  TriggerClientEvent('aln42:props:toast', src, ('Updated %s'):format(id))
end)

RegisterNetEvent('aln42:props:adminRemove', function(id)
  local src = source
  if not isAdmin(src) then return end
  local _, idx = findById(id)
  if not idx then return end
  table.remove(props, idx)
  saveProps()
  broadcast()
  TriggerClientEvent('aln42:props:toast', src, ('Removed %s'):format(id))
end)

-- Player purchase
RegisterNetEvent('aln42:props:buy', function(id)
  local src = source
  local c = getChar(src)
  if not c then return end
  local meta = ensureMeta(c)

  local p = findById(id)
  if not p then return end
  if meta.owned[id] then
    TriggerClientEvent('aln42:props:toast', src, 'You already own this.')
    return
  end

  local cost = tonumber(p.price) or 0
  if cost <= 0 then
    TriggerClientEvent('aln42:props:toast', src, 'Not for sale.')
    return
  end

  local ok, err = pay(src, cost)
  if not ok then
    TriggerClientEvent('aln42:props:toast', src, err or 'Payment failed.')
    return
  end

  meta.owned[id] = true
  meta.locked[id] = true

  local it = items()
  if it then
    if p.kind == 'home' then it:GiveItem(src, 'house_key', 1) end
    if p.kind == 'garage' then it:GiveItem(src, 'garage_key', 1) end
  end

  TriggerClientEvent('aln42:props:toast', src, ('Purchased %s'):format(p.name or id))
end)

RegisterNetEvent('aln42:props:toggleLock', function(id)
  local src = source
  local c = getChar(src)
  if not c then return end
  local meta = ensureMeta(c)

  local p = findById(id)
  if not p then return end
  if not meta.owned[id] then
    TriggerClientEvent('aln42:props:toast', src, 'You do not own this.')
    return
  end

  meta.locked[id] = not (meta.locked[id] == true)
  TriggerClientEvent('aln42:props:toast', src, meta.locked[id] and 'Locked.' or 'Unlocked.')
end)

RegisterNetEvent('aln42:props:setHome', function(id)
  local src = source
  local c = getChar(src)
  if not c then return end
  local meta = ensureMeta(c)

  local p = findById(id)
  if not p or p.kind ~= 'home' then return end
  if not meta.owned[id] then
    TriggerClientEvent('aln42:props:toast', src, 'You do not own this.')
    return
  end

  meta.home = id
  TriggerClientEvent('aln42:props:toast', src, 'Home set.')
end)

-- Query whether player can enter
RegisterNetEvent('aln42:props:canEnter', function(id)
  local src = source
  local c = getChar(src)
  if not c then
    TriggerClientEvent('aln42:props:enterResult', src, id, false, 'No character.')
    return
  end
  local meta = ensureMeta(c)
  local p = findById(id)
  if not p then
    TriggerClientEvent('aln42:props:enterResult', src, id, false, 'Not found.')
    return
  end

  if meta.locked[id] and not meta.owned[id] then
    TriggerClientEvent('aln42:props:enterResult', src, id, false, 'Locked.')
    return
  end

  TriggerClientEvent('aln42:props:enterResult', src, id, true, nil)
end)
