Config = {}

Config.Enabled = true

-- Tool items required
Config.Tools = {
  break_window   = nil,           -- no item required
  lockpick       = 'lockpick',
  slimjim        = 'slimjim',
  lockpick_set   = 'lockpick_set',
  e_lockpick     = 'e_lockpick',
  hotwire        = 'hotwire_kit',
  ignition_pick  = 'lockpick'     -- same as door lockpick
}

-- How often tools break (on failure)
Config.BreakChanceOnFail = {
  lockpick = 0.35,
  slimjim = 0.10,
  lockpick_set = 0.20,
  e_lockpick = 0.05,
  hotwire_kit = 0.30,
  ignition_pick = 0.35
}

-- Police alert chance by method (applies on attempt; higher = more heat)
Config.CopsChance = {
  break_window = 0.55,  -- high chance of cops
  lockpick = 0.18,      -- moderate chance
  slimjim = 0.00,       -- no chance of cops
  lockpick_set = 0.18,  -- same as lockpick (your spec)
  e_lockpick = 0.05,    -- low
  hotwire = 0.45,       -- high
  ignition_pick = 0.18  -- same as lockpick
}

-- Dice settings by method
-- - slimjim: advantage, no cops chance already handled above
-- - lockpick_set: DC -2
-- - e_lockpick: advantage + DC -2
Config.Dice = {
  lockpick_activity = 'lockpick',
  hotwire_activity = 'hotwire',

  method = {
    break_window  = { mode = 'normal', dcDelta = 0,  modifier = 0 },
    lockpick      = { mode = 'normal', dcDelta = 0,  modifier = 0 },
    slimjim       = { mode = 'adv',    dcDelta = 0,  modifier = 0 },
    lockpick_set  = { mode = 'normal', dcDelta = -2, modifier = 0 },
    e_lockpick    = { mode = 'adv',    dcDelta = -2, modifier = 0 },
    hotwire       = { mode = 'normal', dcDelta = 0,  modifier = 0 },
    ignition_pick = { mode = 'normal', dcDelta = 0,  modifier = 0 }
  }
}

-- Distance checks
Config.Range = {
  vehicle = 4.0
}

-- How we turn vehicle “value” into a grade (1..4) for DC scaling
Config.ValueGrade = {
  [1] = { max = 25000 },
  [2] = { max = 80000 },
  [3] = { max = 200000 },
  [4] = { max = 999999999 }
}

-- If model not found in data/vehicle_values.json, use this fallback value
Config.FallbackVehicleValue = 35000

-- Mark “police alerted” if cops chance triggers OR if player fires weapon during attempt (optional; currently chance-based only)
Config.MarkAlertedOnAttempt = true
