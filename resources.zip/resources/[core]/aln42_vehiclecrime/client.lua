local values = {}

local function notify(msg)
  print(('[ALN42 VehicleCrime] %s'):format(msg))
  TriggerEvent('chat:addMessage', { args = { '^1ALN42-Crime', msg } })
end

RegisterNetEvent('aln42:vehiclecrime:toast', function(msg) notify(msg) end)

local function readJson(path)
  local raw = LoadResourceFile(GetCurrentResourceName(), path)
  if not raw or raw == '' then return {} end
  local ok, parsed = pcall(json.decode, raw)
  if not ok or type(parsed) ~= 'table' then return {} end
  return parsed
end

local function getClosestVehicle(maxDist)
  local ped = PlayerPedId()
  local p = GetEntityCoords(ped)
  local veh = GetClosestVehicle(p.x, p.y, p.z, maxDist or 4.0, 0, 70)
  if veh and veh ~= 0 and DoesEntityExist(veh) then return veh end
  return nil
end

local function modelName(veh)
  local m = GetEntityModel(veh)
  local name = GetDisplayNameFromVehicleModel(m)
  return (name and name ~= '') and name:lower() or nil
end

local function plateOf(veh)
  return tostring(GetVehicleNumberPlateText(veh) or '')
end

local function hasItem(name, count)
  if not name then return true end
  if GetResourceState('aln42_items') ~= 'started' then return false end
  return exports['aln42_items']:HasItem(PlayerId(), name, count or 1)
end

local function takeItem(name, count)
  if not name then return true end
  if GetResourceState('aln42_items') ~= 'started' then return false end
  local ok = exports['aln42_items']:TakeItem(PlayerId(), name, count or 1)
  return ok == true
end

local function valueFor(veh)
  local n = modelName(veh)
  if n and values[n] then return tonumber(values[n]) end
  return Config.FallbackVehicleValue
end

local function gradeForValue(v)
  for g = 1, 4 do
    local maxv = Config.ValueGrade[g] and Config.ValueGrade[g].max or 999999999
    if v <= maxv then return g end
  end
  return 2
end

local function doDice(activity, grade, dcDelta, mode, modifier, meta)
  if GetResourceState('aln42_dicebridge') ~= 'started' then
    notify('Dice bridge not started.')
    return false, nil
  end

  local ok, info = exports['aln42_dicebridge']:DoCheck({
    activity = activity,
    grade = grade,
    skill = 0,
    tool = nil,
    mode = mode or 'normal',
    modifier = modifier or 0,
    meta = meta
  })

  -- Apply DC delta locally (your spec)
  if dcDelta and dcDelta ~= 0 and info and info.dc then
    local newDC = math.max(5, math.min(25, (info.dc + dcDelta)))
    local ok2, info2 = exports['aln42_dicebridge']:Roll(newDC, modifier or 0, mode or 'normal', meta)
    return ok2, { dc = newDC, total = info2.total, raw = info2.raw }
  end

  return ok, info
end

local function markPoliceChance(veh, method)
  local plate = plateOf(veh)
  local chance = Config.CopsChance[method] or 0
  if chance > 0 then
    TriggerServerEvent('aln42:vehiclecrime:maybeAlert', plate, chance)
  end
end

local function breakToolOnFail(method)
  local itemName = Config.Tools[method]
  if not itemName then return end
  local chance = (Config.BreakChanceOnFail[itemName] or 0)
  if math.random() < chance then
    takeItem(itemName, 1)
    notify(('Your %s broke.'):format(itemName))
  end
end

local function unlockVehicle(veh)
  SetVehicleDoorsLocked(veh, 1)
  SetVehicleDoorsLockedForAllPlayers(veh, false)
end

local function hotwireSuccess(veh)
  SetVehicleEngineOn(veh, true, true, false)
  SetVehicleUndriveable(veh, false)
end

local function attempt(method)
  if not Config.Enabled then return end

  local veh = getClosestVehicle(Config.Range.vehicle or 4.0)
  if not veh then notify('No vehicle nearby.'); return end

  local toolItem = Config.Tools[method]
  if toolItem and (GetResourceState('aln42_items') ~= 'started') then
    notify('aln42_items is required for tool checks.')
    return
  end
  if toolItem and (exports['aln42_items']:HasItem(PlayerId(), toolItem, 1) ~= true) then
    notify(('Missing required tool: %s'):format(toolItem))
    return
  end

  local v = valueFor(veh)
  local grade = gradeForValue(v)

  local diceCfg = Config.Dice.method[method]
  if not diceCfg then notify('Unknown method.'); return end

  -- Police alert chance on attempt
  markPoliceChance(veh, method)

  -- Activities: lockpick vs hotwire
  local activity = (method == 'hotwire') and Config.Dice.hotwire_activity or Config.Dice.lockpick_activity

  -- Special case: break window = no roll needed; it just opens entry with cops risk
  if method == 'break_window' then
    unlockVehicle(veh)
    notify('Window smashed; vehicle unlocked.')
    return
  end

  local ok, info = doDice(activity, grade, diceCfg.dcDelta or 0, diceCfg.mode or 'normal', diceCfg.modifier or 0, {
    method = method,
    model = modelName(veh),
    plate = plateOf(veh),
    value = v
  })

  if ok then
    unlockVehicle(veh)
    if method == 'hotwire' then hotwireSuccess(veh) end
    notify(('Success (%s).'):format(method))
  else
    notify(('Failed (%s).'):format(method))
    breakToolOnFail(method)
  end
end

-- Commands
RegisterCommand('carbreak', function() attempt('break_window') end, false)      -- break window
RegisterCommand('carlockpick', function() attempt('lockpick') end, false)      -- lockpick door
RegisterCommand('carslimjim', function() attempt('slimjim') end, false)        -- slimjim adv, no cops chance
RegisterCommand('carlockpickset', function() attempt('lockpick_set') end, false) -- DC -2
RegisterCommand('carelockpick', function() attempt('e_lockpick') end, false)  -- adv + DC -2
RegisterCommand('carhotwire', function() attempt('hotwire') end, false)        -- high cops chance
RegisterCommand('carignitionpick', function() attempt('ignition_pick') end, false) -- same as lockpick

CreateThread(function()
  values = readJson('data/vehicle_values.json')
end)
