fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'ALN42 Vehicle Crime: break/lockpick/slimjim/e-lockpick/hotwire with bg3_dice via aln42_dicebridge'

shared_scripts { 'config.lua' }
server_scripts { 'server.lua' }
client_scripts { 'client.lua' }

files { 'data/vehicle_values.json' }
