local values = {}
local alertedByPlate = {} -- [plate] = true

local function readJson(path)
  local raw = LoadResourceFile(GetCurrentResourceName(), path)
  if not raw or raw == '' then return {} end
  local ok, parsed = pcall(json.decode, raw)
  if not ok or type(parsed) ~= 'table' then return {} end
  return parsed
end

local function normalizePlate(p)
  p = tostring(p or ''):upper()
  p = p:gsub('%s+', '')
  return p
end

local function setAlerted(plate, v)
  plate = normalizePlate(plate)
  if plate == '' then return end
  alertedByPlate[plate] = v == true
end

local function isAlerted(plate)
  plate = normalizePlate(plate)
  return alertedByPlate[plate] == true
end

exports('IsVehicleAlerted', function(plate)
  return isAlerted(plate)
end)

exports('SetVehicleAlerted', function(plate, v)
  setAlerted(plate, v)
end)

exports('GetVehicleValueByModel', function(modelName)
  if not modelName then return Config.FallbackVehicleValue end
  modelName = tostring(modelName):lower()
  return tonumber(values[modelName]) or Config.FallbackVehicleValue
end)

local function gradeFromValue(val)
  val = tonumber(val) or Config.FallbackVehicleValue
  for g = 1, 4 do
    local maxv = Config.ValueGrade[g] and Config.ValueGrade[g].max or 999999999
    if val <= maxv then return g end
  end
  return 2
end

exports('GetGradeForModel', function(modelName)
  local v = exports[GetCurrentResourceName()]:GetVehicleValueByModel(modelName)
  return gradeFromValue(v)
end)

RegisterNetEvent('aln42:vehiclecrime:maybeAlert', function(plate, chance)
  if not Config.MarkAlertedOnAttempt then return end
  local src = source
  if type(plate) ~= 'string' then return end
  chance = tonumber(chance) or 0
  if chance <= 0 then return end
  if math.random() < chance then
    setAlerted(plate, true)
    TriggerClientEvent('aln42:vehiclecrime:toast', src, '^1Police alerted.^7')
  end
end)

AddEventHandler('onResourceStart', function(res)
  if res ~= GetCurrentResourceName() then return end
  values = readJson('data/vehicle_values.json')
end)
