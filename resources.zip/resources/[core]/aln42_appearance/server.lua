local function getChar(src)
  if GetResourceState('aln42_characters') ~= 'started' then return nil end
  return exports['aln42_characters']:GetCharacter(src)
end

local function items()
  if GetResourceState('aln42_items') ~= 'started' then return nil end
  return exports['aln42_items']
end

RegisterNetEvent('aln42:appearance:saveBarber', function(payload)
  local src = source
  local c = getChar(src)
  if not c then return end
  local it = items()
  if not it then return end

  local cost = Config.Prices.barberFlat or 100
  if not it:HasItem(src, Config.CashItem, cost) then
    TriggerClientEvent('aln42:appearance:toast', src, 'Not enough cash for barber.')
    return
  end

  it:TakeItem(src, Config.CashItem, cost)

  c.meta = c.meta or {}
  c.meta.appearance = c.meta.appearance or {}
  c.meta.appearance.barber = payload or {}

  TriggerClientEvent('aln42:appearance:toast', src, ('Barber saved. Paid $%d'):format(cost))
end)

RegisterNetEvent('aln42:appearance:saveOutfit', function(storeType, outfitId, payload, price)
  local src = source
  local c = getChar(src)
  if not c then return end
  local it = items()
  if not it then return end

  price = tonumber(price) or 0
  if price <= 0 then
    TriggerClientEvent('aln42:appearance:toast', src, 'Invalid outfit price.')
    return
  end

  if not it:HasItem(src, Config.CashItem, price) then
    TriggerClientEvent('aln42:appearance:toast', src, 'Not enough cash.')
    return
  end

  it:TakeItem(src, Config.CashItem, price)

  c.meta = c.meta or {}
  c.meta.appearance = c.meta.appearance or {}
  c.meta.appearance.outfit = { store = storeType, id = outfitId, applied = payload }

  TriggerClientEvent('aln42:appearance:toast', src, ('Outfit saved. Paid $%d'):format(price))
end)

-- Client asks for saved appearance on spawn/character load
RegisterNetEvent('aln42:appearance:request', function()
  local src = source
  local c = getChar(src)
  if not c or not c.meta or not c.meta.appearance then
    TriggerClientEvent('aln42:appearance:apply', src, nil)
    return
  end
  TriggerClientEvent('aln42:appearance:apply', src, c.meta.appearance)
end)
