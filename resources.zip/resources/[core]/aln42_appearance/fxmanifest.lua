fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'ALN42 Appearance: barber cosmetics + thrift/clothing outfits, saved to character meta'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'

files { 'data/outfits.json' }
