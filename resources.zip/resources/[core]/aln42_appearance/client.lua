local locations = {}
local outfits = {}

local active = nil -- nearest barber/thrift/clothing location

local function notify(msg)
  print(('[ALN42 Appearance] %s'):format(msg))
  TriggerEvent('chat:addMessage', { args = { '^7ALN42-Look', msg } })
end

RegisterNetEvent('aln42:appearance:toast', function(msg) notify(msg) end)

local function readJson(res, path)
  local raw = LoadResourceFile(res, path)
  if not raw or raw == '' then return {} end
  local ok, parsed = pcall(json.decode, raw)
  return (ok and type(parsed) == 'table') and parsed or {}
end

local function dist3(a,b)
  local dx=a.x-b.x; local dy=a.y-b.y; local dz=a.z-b.z
  return math.sqrt(dx*dx+dy*dy+dz*dz)
end

local function findActive()
  local p = GetEntityCoords(PlayerPedId())
  local p3 = {x=p.x,y=p.y,z=p.z}
  for i=1,#locations do
    local loc = locations[i]
    if loc and loc.coords and Config.Types[loc.type] then
      local d = dist3(p3, loc.coords)
      if d <= (Config.Range or 3.0) then return loc end
    end
  end
  return nil
end

local function applyComponents(components)
  if type(components) ~= 'table' then return end
  local ped = PlayerPedId()
  for _, c in ipairs(components) do
    if c.component and c.drawable then
      SetPedComponentVariation(ped, tonumber(c.component), tonumber(c.drawable), tonumber(c.texture or 0), 2)
    end
  end
end

local function applyBarber(b)
  if type(b) ~= 'table' then return end
  local ped = PlayerPedId()

  -- Hair component (2)
  if b.hairDrawable then
    SetPedComponentVariation(ped, 2, tonumber(b.hairDrawable), tonumber(b.hairTexture or 0), 2)
  end
  if b.hairColor then
    SetPedHairColor(ped, tonumber(b.hairColor), tonumber(b.hairHighlight or b.hairColor))
  end

  -- Beard overlay (1)
  if b.beardIndex then
    SetPedHeadOverlay(ped, 1, tonumber(b.beardIndex), tonumber(b.beardOpacity or 1.0))
    SetPedHeadOverlayColor(ped, 1, 1, tonumber(b.beardColor or 0), tonumber(b.beardColor or 0))
  end
end

RegisterNetEvent('aln42:appearance:apply', function(meta)
  if not meta then return end
  if meta.barber then applyBarber(meta.barber) end
  if meta.outfit and meta.outfit.applied and meta.outfit.applied.components then
    applyComponents(meta.outfit.applied.components)
  end
end)

-- Request saved appearance after spawn
CreateThread(function()
  Wait(2500)
  TriggerServerEvent('aln42:appearance:request')
end)

-- Refresh nearest location
CreateThread(function()
  locations = readJson('aln42_locations', 'data/locations.json')
  outfits = readJson(GetCurrentResourceName(), 'data/outfits.json')

  while true do
    active = findActive()
    Wait(250)
  end
end)

-- BARBER commands
-- /barber hair <drawable> <texture> <color> <highlight>
-- /barber beard <index> <opacity 0-1> <color>
-- /barber save   (charges $100)
RegisterCommand('barber', function(_, args)
  if not active or active.type ~= 'barber' then
    notify('You must be at a barber.')
    return
  end

  local sub = (args[1] or ''):lower()
  local ped = PlayerPedId()

  if sub == 'hair' then
    local drawable = tonumber(args[2] or '')
    if not drawable then notify('Usage: /barber hair <drawable> <texture> <color> <highlight>'); return end
    local texture = tonumber(args[3] or '0') or 0
    local color = tonumber(args[4] or '0') or 0
    local hi = tonumber(args[5] or tostring(color)) or color

    SetPedComponentVariation(ped, 2, drawable, texture, 2)
    SetPedHairColor(ped, color, hi)
    notify('Hair previewed. Use /barber save to pay/apply permanently.')

  elseif sub == 'beard' then
    local idx = tonumber(args[2] or '')
    if idx == nil then notify('Usage: /barber beard <index> <opacity 0-1> <color>'); return end
    local op = tonumber(args[3] or '1.0') or 1.0
    local col = tonumber(args[4] or '0') or 0
    SetPedHeadOverlay(ped, 1, idx, op)
    SetPedHeadOverlayColor(ped, 1, 1, col, col)
    notify('Beard previewed. Use /barber save to pay/apply permanently.')

  elseif sub == 'save' then
    local hd, ht = GetPedDrawableVariation(ped, 2), GetPedTextureVariation(ped, 2)
    local c1, c2 = GetPedHairColor(ped)
    -- beard overlay readback is not clean; store last set values by assuming current visible
    TriggerServerEvent('aln42:appearance:saveBarber', {
      hairDrawable = hd, hairTexture = ht, hairColor = c1, hairHighlight = c2
    })

  else
    notify('Barber:')
    notify('  /barber hair <drawable> <texture> <color> <highlight>')
    notify('  /barber beard <index> <opacity 0-1> <color>')
    notify('  /barber save   (flat $100)')
  end
end, false)

-- OUTFITS
-- /fit list
-- /fit wear <outfitId>
-- /fit save <outfitId>
local function storeKeyForActive()
  if not active then return nil end
  if active.type == 'thrift' then return 'thrift' end
  if active.type == 'clothing' then return 'clothing' end
  return nil
end

local function priceFor(storeKey, base)
  base = tonumber(base) or 0
  if storeKey == 'thrift' then return math.floor(base * (Config.Prices.thriftMult or 0.55)) end
  return math.floor(base * (Config.Prices.clothingMult or 1.0))
end

RegisterCommand('fit', function(_, args)
  local storeKey = storeKeyForActive()
  if not storeKey then
    notify('You must be at a thrift store or clothing store.')
    return
  end

  local sub = (args[1] or 'list'):lower()
  local list = outfits[storeKey] or {}

  if sub == 'list' then
    notify(('Outfits (%s):'):format(storeKey))
    for i=1, math.min(#list, 25) do
      local o = list[i]
      local p = priceFor(storeKey, o.basePrice)
      notify(('%s  id=%s  $%d'):format(o.label, o.id, p))
    end
    notify('Use: /fit wear <id>  then  /fit save <id>')

  elseif sub == 'wear' then
    local id = args[2]
    if not id then notify('Usage: /fit wear <id>'); return end
    for _, o in ipairs(list) do
      if o.id == id then
        applyComponents(o.components)
        notify('Outfit previewed. Use /fit save <id> to buy & save.')
        return
      end
    end
    notify('Outfit id not found.')

  elseif sub == 'save' then
    local id = args[2]
    if not id then notify('Usage: /fit save <id>'); return end
    for _, o in ipairs(list) do
      if o.id == id then
        local price = priceFor(storeKey, o.basePrice)
        TriggerServerEvent('aln42:appearance:saveOutfit', storeKey, id, { components = o.components }, price)
        return
      end
    end
    notify('Outfit id not found.')

  else
    notify('Usage: /fit list | /fit wear <id> | /fit save <id>')
  end
end, false)

-- Intro hook: open appearance “flow” and signal done
RegisterNetEvent('aln42:appearance:open', function(ctx)
  ctx = ctx or {}
  notify('Appearance setup:')
  notify('  Go to a barber: /barber hair ... then /barber save')
  notify('  Go to thrift/clothing: /fit list, /fit wear, /fit save')
  notify('When finished type: /appearance done  (to continue intro)')
end)

RegisterCommand('appearance', function(_, args)
  if (args[1] or ''):lower() == 'done' then
    TriggerEvent('aln42:appearance:done')
  else
    notify('Usage: /appearance done')
  end
end, false)
