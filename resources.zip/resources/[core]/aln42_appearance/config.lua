Config = {}

Config.Enabled = true

Config.CashItem = 'cash'

Config.Prices = {
  barberFlat = 100,
  thriftMult = 0.55,
  clothingMult = 1.00
}

Config.Types = {
  barber = true,
  thrift = true,
  clothing = true
}

Config.Range = 3.0
