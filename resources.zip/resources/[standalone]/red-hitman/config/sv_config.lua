ServerConfig = {}

ServerConfig.MinHitPrice = 5000
ServerConfig.MaxHitPrice = 500000

ServerConfig.ContractExpiry = 120
ServerConfig.ClaimLockDuration = 30

ServerConfig.PlaceHitCooldown = 15
ServerConfig.ClaimCooldown = 15
ServerConfig.AbandonPenalty = 15

ServerConfig.MaxActiveContracts = 1
ServerConfig.MinPlayersOnline = 1
ServerConfig.MaxTotalContracts = 50

ServerConfig.AIContracts = true
ServerConfig.AIMinContracts = 6
ServerConfig.AIMaxContracts = 6
ServerConfig.AIMinReward = 5000
ServerConfig.AIMaxReward = 20000
ServerConfig.AIRefreshInterval = 5

ServerConfig.PlayerWaypoint = true

ServerConfig.RefundPercent = 50

ServerConfig.RestrictedToJob = false
ServerConfig.RestrictedToItem = false

ServerConfig.Debug = false